# Deployment 🚀

This section provides information on how to deploy the Gomat Markup Optimization project, including environment configuration and continuous integration/continuous deployment (CI/CD) setup.

## Deployment Instructions
To deploy the project, follow these steps:

1. **Build the Docker Image**:
   Ensure you have Docker installed and running. Navigate to the project root directory and build the Docker image:
   ```bash
   docker build -t gomat_markup_opt .
   ```

2. **Run the Docker Container**:
   After building the image, you can run the container:
   ```bash
   docker run -p 8000:8000 gomat_markup_opt
   ```
   This command maps port 8000 of the container to port 8000 on your host machine, making the API accessible at `http://localhost:8000`.

3. **Environment Configuration**:
   Ensure that all necessary environment variables are set. You can create a `.env` file in the project root with the required variables. An example file (`.env.example`) is provided in the project root.

4. **MLflow Tracking**:
   If you are using MLflow for tracking experiments, ensure that the `MLFLOW_TRACKING_URI` environment variable is set to point to your MLflow server.

## Continuous Integration/Continuous Deployment (CI/CD)
To set up CI/CD for the project, you can use tools like GitHub Actions, GitLab CI, or any other CI/CD service. Below is a basic outline of steps to include in your CI/CD pipeline:

1. **Run Tests**: Ensure that all tests are executed on each push or pull request.
2. **Build Docker Image**: Automatically build the Docker image after successful tests.
3. **Deploy**: Deploy the application to your production environment after a successful build.

For more detailed instructions on setting up CI/CD, refer to the documentation of the CI/CD tool you are using.
