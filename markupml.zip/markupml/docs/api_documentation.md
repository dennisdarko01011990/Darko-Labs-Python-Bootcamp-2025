# API Documentation 📡

The Gomat Markup Optimization project provides a FastAPI-based API for optimal markup suggestions and health monitoring.
Below are the details of the available endpoints, input/output schemas, and usage examples.

---

## Overview of the API

The API allows users to interact with the markup optimization models, providing endpoints for health checks and markup suggestions.

---

## Endpoints

### 1. Health Check Endpoint

- **URL**: `/health`
- **Method**: `GET`
- **Description**: Checks the health status of the models and the API.
- **Response**:
  - **200 OK**: Returns the health status, version, uptime, and model statuses.
  - **Response Model**:
    ```json
    {
      "status": "HEALTHY",
      "version": "1.0.0",
      "uptime": 120.5,
      "models": [
        {
          "name": "conversion_model",
          "status": "loaded",
          "run_id": "12345"
        },
        {
          "name": "markup_space_model",
          "status": "loaded",
          "run_id": "67890"
        }
      ],
      "timestamp": "2025-07-28T19:45:00Z"
    }
    ```

#### Health Endpoint Schemas

- **HealthResponse**
    - `status`: `"healthy"`, `"degraded"`, or `"error"`
    - `version`: API version
    - `uptime`: Seconds since API started
    - `models`: List of loaded models and their status
    - `timestamp`: ISO timestamp

- **HealthErrorResponse**
    - `status`: `"error"`
    - `version`: API version
    - `error`: Error message
    - `timestamp`: ISO timestamp

---

### 2. Markup Suggestion Endpoint

- **URL**: `/suggest_markups/`
- **Method**: `POST`
- **Description**: Suggests optimal markups for line items based on the provided quote.

#### Input Schema (`Quote`)

The API expects a JSON payload matching the following schema:

```json
{
  "qto": true,
  "request_purpose": "For Install",
  "buyer_region": "Florida",
  "buyer_company_id": "buyer_123",
  "line_items": [
    {
      "item_id": "12345",
      "plant_category": "Trees",
      "product_id": "216",
      "product_size_id": "270",
      "seller_price": 500.0,
      "quantity": 2
    }
  ]
}
```

**Fields:**

- `qto` (`bool`): Whether this is a QTO (quantity take-off) quote.
- `request_purpose` (`str`): Purpose of the request (`"For Install"` or `"For Bid"`).
- `buyer_region` (`str`): Region of the buyer.
- `buyer_company_id` (`str`): Unique identifier for the buyer company.
- `line_items` (`list[LineItem]`): List of line items, each with:
    - `item_id` (`str`)
    - `plant_category` (`str`)
    - `product_id` (`str`)
    - `product_size_id` (`str`)
    - `seller_price` (`float`)
    - `quantity` (`int`)

#### Output Schema (`MarkupSuggestionResponse`)

The main response contains a list of markup suggestions, one for each line item:

```json
{
  "suggestions": [
    {
      "item_id": "12345",
      "suggested_markup_rate": 0.32
    }
  ]
}
```

**Fields:**

- `suggestions` (`list[MarkupSuggestion]`): Each suggestion includes:
    - `item_id` (`str`)
    - `suggested_markup_rate` (`float`)

#### Detailed Output (`MarkupSuggestionDetails`)

For advanced use cases, the API can return detailed calculations for each line item:

```json
{
  "item_id": "12345",
  "min_markup_rate": 0.28,
  "max_markup_rate": 0.36,
  "suggested_markup_rate": 0.32,
  "expected_converted_revenue": 320.0,
  "conversion_probability": 0.65,
  "calculations": [
    {
      "markup_rate": 0.28,
      "conversion_probability": 0.70,
      "reward_score": 0.19,
      "total_expected_converted_revenue": 280.0
    },
    {
      "markup_rate": 0.32,
      "conversion_probability": 0.65,
      "reward_score": 0.208,
      "total_expected_converted_revenue": 320.0
    }
    // ... more candidates
  ]
}
```

**Fields:**

- `item_id` (`str`)
- `min_markup_rate` (`float`)
- `max_markup_rate` (`float`)
- `suggested_markup_rate` (`float`)
- `expected_converted_revenue` (`float`)
- `conversion_probability` (`float`)
- `calculations` (`list[MarkupCalculation]`): For each candidate markup:
    - `markup_rate` (`float`)
    - `conversion_probability` (`float`)
    - `reward_score` (`float`)
    - `total_expected_converted_revenue` (`float`)

---

## Usage Examples

### Health Check Example

To check the health of the API, you can use the following curl command:
```bash
curl -X GET http://localhost:8000/health
```

### Markup Suggestion Example

To get markup suggestions, you can use the following curl command:
```bash
curl -X POST http://localhost:8000/suggest_markups/ -H "Content-Type: application/json" -d '{
  "line_items": [
    {
      "item_id": "12345",
      "plant_category": "Trees",
      "product_id": "216",
      "product_size_id": "270",
      "seller_price": 500.0,
      "quantity": 2
    }
  ],
  "qto": true,
  "request_purpose": "For Install",
  "buyer_region": "Florida",
  "buyer_company_id": "buyer_123"
}'
```

---

For full schema definitions, see [`src/gomat_markup_opt/inference/schemas.py`](../../src/gomat_markup_opt/inference/schemas.py).

For more details on the API, refer
