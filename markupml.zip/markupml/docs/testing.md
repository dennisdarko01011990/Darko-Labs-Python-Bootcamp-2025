# Testing 🧪

This section provides information on the testing framework used in the Gomat Markup Optimization project, how to run tests, and guidelines for writing new tests.

## Testing Framework
The project uses `pytest` as the testing framework. It is a powerful tool for running tests and checking the correctness of the code.

## Running Tests
To run the automated unit test suite, use the following command:
```bash
pytest
```
This command will discover and execute all test files and functions that follow the naming conventions (i.e., files starting with `test_` or ending with `_test.py`).

## Writing New Tests

When writing new tests, follow these guidelines:

1. **Naming Conventions**: Name your test functions with a `test_` prefix to ensure they are discovered by `pytest`.
2. **Organize Tests**: Place your test files in the `tests/` directory, maintaining a structure that mirrors the source code for clarity.
3. **Use Fixtures**: Utilize `pytest` fixtures to set up any necessary context or state for your tests.
4. **Assertions**: Use assertions to verify that the output of your code matches the expected results.

### Example Test
Here is a simple example of a test function:
```python
def test_example_function():
    result = example_function()
    assert result == expected_value
```

For more information on writing tests with `pytest`, refer to the [pytest documentation](https://docs.pytest.org/en/stable/).
