# Development 👨‍💻

This section provides information on setting up the development environment, the code structure, and guidelines for contributing to the Gomat Markup Optimization project.


## Development Setup (Recommended: Makefile)
To set up the development environment, the recommended approach is to use the provided `Makefile` for automation and consistency. Manual steps are also provided as an alternative.

### Using the Makefile
1. **Clone the Repository**:
   ```bash
   git clone https://bitbucket.org/gomaterials/markupml.git
   cd markupml
   ```

2. **Set Up the Conda Environment and Install the Package**:
   ```bash
   make conda-env
   ```
   This will remove any existing `gomat_markup_opt` environment, create a new one, install all dependencies, and install the package in editable mode.

3. **(Optional) Lock Environment for Reproducibility**:
   ```bash
   make conda-lock
   ```

4. **Set Up Pre-commit Hooks**:
   ```bash
   pre-commit install --install-hooks
   ```

### Manual Setup (Alternative)
If you prefer to set up the environment manually:
1. **Create a Virtual Environment**:
   ```bash
   conda env create -f envs/environment.yml
   conda activate gomat_markup_opt
   ```
2. **Install Development Dependencies**:
   ```bash
   conda install -f envs/environment-dev.yml
   ```
3. **Set Up Pre-commit Hooks**:
   ```bash
   pre-commit install --install-hooks
   ```

---

## Common Makefile Commands

- `make conda-env` — Set up or update the Conda environment and install the package.
- `make conda-lock` — Generate a lock file for reproducible environments.


## Code Structure
The project is organized into several modules, each representing different parts of the machine learning model training and inference pipeline. The main components include:

```
src
└───gomat_markup_opt
    └───data                                  # Data loading and preparation.
    └───evaluation                            # Evaluation of the models.
    └───inference                             # Optimal markup suggestion algorithm and API.
    └───models                                # Scikit-learn models and dependencies.
    └───preprocessing                         # Data preprocessing scripts.
    └───training                              # Scripts for training models.
    └───visualization                         # Visualization tools for model evaluation.
└───scripts                                   # Entry scripts for running various tasks.
```

## Contributing
Contributions to the project are welcome! If you have access to the repository, please follow these guidelines:

1. **Create a Feature Branch**: Create a new branch for your feature or bug fix directly in the main repository.
   ```bash
   git checkout -b feature/my-feature
   ```
2. **Make Your Changes**: Implement your changes and ensure they adhere to the project's coding standards.
3. **Run Tests**: Ensure all tests pass before submitting your changes.
4. **Submit a Pull Request**: Push your branch and submit a pull request to the main repository.

**Pre-commit Hooks:**
This project uses [pre-commit](https://pre-commit.com/) to enforce code style, linting, and other quality checks automatically before each commit. Please ensure all pre-commit checks pass before submitting your pull request.

If you need access or have questions, please contact the project maintainers.
