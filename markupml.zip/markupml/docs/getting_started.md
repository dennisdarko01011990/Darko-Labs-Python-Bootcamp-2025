
# Getting Started 🤖

This section will guide you through the prerequisites, installation instructions, and how to quickly get started with the Gomat Markup Optimization project. The recommended way to set up your environment and run common tasks is via the provided `Makefile`.


## Prerequisites

Before you begin, ensure you have the following software installed:

- **Python 3.8 or higher**: The project is built using Python, so make sure you have a compatible version installed.
- **Conda**: For managing virtual environments and dependencies. [Download Conda](https://conda-forge.org/download/).
- **Docker**: For containerization and deployment. [Download Docker](https://docs.docker.com/get-docker/).
- **GNU Make**: For running the provided Makefile. On Windows, you can use [GnuWin](http://gnuwin32.sourceforge.net/packages/make.htm), [Chocolatey](https://community.chocolatey.org/packages/make), or WSL.


## Installation & Setup (Recommended: Makefile)

1. **Clone the Repository**:
   ```bash
   git clone https://bitbucket.org/gomaterials/markupml.git
   cd markupml
   ```

2. **Set Up the Conda Environment** (creates and installs all dependencies):
   ```bash
   make conda-env
   ```
   This will remove any existing `gomat_markup_opt` environment, create a new one, install all dependencies, and install the package in editable mode.

3. **Set Up Environment Variables**:
   Create a `.env` file in the project root and set the necessary environment variables. An example file (`.env.example`) is provided in the project root.

4. **(Optional) Lock Environment for Reproducibility**:
   ```bash
   make conda-lock
   ```
   This generates a lock file for consistent environments across platforms.

---

## Common Makefile Commands

- `make conda-env` — Set up or update the Conda environment and install the package.
- `make conda-lock` — Generate a lock file for reproducible environments.

You can also run the entry scripts manually as shown below, once your environment is activated.


## Quick Start Guide

After setting up your environment, you can run the following entry scripts:

1. **Train All Models**:
   ```bash
   python src/scripts/train_all.py
   ```

2. **Start the Inference API**:
   ```bash
   python src/scripts/start_inference_api.py
   ```

3. **Run Greediness Analysis**:
   ```bash
   python src/scripts/evaluate_greediness.py
   ```

For detailed usage instructions, refer to the [Entry Scripts](entry_scripts.md) section.
