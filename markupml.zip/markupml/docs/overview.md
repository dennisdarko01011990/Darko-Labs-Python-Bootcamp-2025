# Project Overview

![System Overview](pics/overview.png)

---

## System Architecture
---

### Inference Pipeline (left)
- Users or applications send quote requests to the API.
- The API orchestrates two deployed models:

    - **Markup Space Optimizer:** Predicts a reasonable markup interval for each line item.
    - **Conversion Probability Model:** Estimates the likelihood of conversion for each candidate markup.

- The **Optimal Markup Picker** combines these predictions to suggest the best markup for each item, balancing profit and conversion probability.
- The API returns suggestions for each quote line item.

### Model Training & Deployment (right)
- Data scientists or automated triggers initiate training jobs for both models.
- Models are evaluated and, if successful, deployed to the inference environment.
- **Users validate model performance** using evaluation metrics and business impact analysis.
- Metrics are tracked for continuous monitoring and improvement.

---

## Key Components

| Component                      | Description                                                                                 |
|--------------------------------|---------------------------------------------------------------------------------------------|
| **API**                        | FastAPI service that handles requests and orchestrates model inference.                      |
| **Markup Space Optimizer**      | Predicts optimal markup intervals for each quote line item.                                 |
| **Conversion Probability Model**| Predicts the probability that a quote will convert at a given markup.                       |
| **Optimal Markup Picker**       | Searches for the markup that maximizes expected reward for each item.                       |
| **Training Jobs**               | Automated or manual jobs to retrain and evaluate models using new data.                     |
| **Metrics**                     | Tracks model performance and business KPIs for monitoring and retraining decisions.         |

---

## How It Works

1. **User/API sends a quote** to the API endpoint.
2. **API loads deployed models** and prepares features for inference.
3. **Markup Space Optimizer** predicts the markup interval for each line item.
4. **Conversion Probability Model** estimates conversion probability for each candidate markup.
5. **Optimal Markup Picker** selects the markup that maximizes expected reward.
6. **API returns suggested markups** for each item in the quote.
7. **Model retraining** is triggered as needed, with new models evaluated and deployed automatically.
8. **Users validate model results** through evaluation pipelines and performance monitoring to ensure quality and business alignment.

---

## Next Steps

- See [Data Preparation](./data/data_preperation.md) for input requirements.
- See [API Documentation](./api_documentation.md) for endpoint details and usage.
- See [Conversion Probability Model](models/conversion_probability_model.md) for details on the conversion model.
- See [Markup Space Optimizer](models/markup_space_optimizer.md) for details on the markup optimizer.
- See [Markup Finder Pipeline](inference/markup_finder.md) for details on the markup suggestion logic.
- See [Greediness Analysis](evaluation/greediness_analysis.md) for comprehensive system performance evaluation.
- See [Configuration](configuration.md) for environment variables, CLI options, and advanced settings.
