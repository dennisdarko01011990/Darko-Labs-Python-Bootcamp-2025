
# Gomat Markup Optimization Documentation

Welcome to the Gomat Markup Optimization project documentation!

**Gomat Markup Optimization** dynamically suggesting optimal markups on quote line items, balancing profit and conversion probability using machine learning. The platform enables data-driven pricing decisions, continuous model improvement, and transparent business logic for both technical and business stakeholders.

**Quick Start:**

- New users should begin with the [Overview](overview.md) and [Getting Started](getting_started.md) pages.
- For API usage, see [API Documentation](api_documentation.md).
- For configuration, see [Configuration](configuration.md).
