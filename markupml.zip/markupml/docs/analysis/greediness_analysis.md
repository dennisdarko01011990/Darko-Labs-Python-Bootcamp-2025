# Greediness Analysis – Technical Pipeline

## Overview

This document describes the technical implementation of the **Greediness Analysis pipeline**, which processes historical data to generate AI markup suggestions and compare them against actual pricing decisions. It covers the data flow, processing stages, and implementation details so developers can understand the pipeline workflow *without needing to read the code*.

## Quick Reference
- **Pipeline Type:** Retrospective AI markup generation and comparison
- **Input Data:** Historical quote/order data from the last `test_size` months
- **Processing Method:** Parallel processing with `ProcessPoolExecutor` for performance
- **Key Dependencies:** MarkupFinder, MLflow, pandas, matplotlib
- **Entry Point:** Use `src/scripts/evaluate_greediness.py` for command-line execution
- **Implementation:** See `evaluate_greediness()` in `src/gomat_markup_opt/evaluation/greediness.py`

## Input Data Requirements

The greediness analysis requires historical quote and order data with the following essential components:

### Data Sources
- **Quote and Order Data:** CSV files (`Quote_and_Order_Data_*.csv`)
- **Configuration:** Uses `AnalysisConfig` settings for evaluation parameters

### Required Fields
- **Quote Information:** `qto`, `request_purpose`, `buyer_region`, `buyer_company_id`
- **Line Item Details:** `product_id`, `product_size_id`, `plant_category`, `quantity`
- **Pricing Data:** `seller_price`, `total_seller_price`, `markup_rate`
- **Outcome Data:** `target` (quote acceptance status)
- **Temporal Data:** Date fields for filtering evaluation period

## Analysis Pipeline

The analysis pipeline processes historical data through multiple stages to generate AI markup suggestions and compare them against actual historical decisions.

### Pipeline Flowchart

```mermaid
flowchart TD
  subgraph Greediness Analysis Pipeline

    subgraph SG_DP[Data Preparation]
      A[Load Quote/Order Data] --> B[Feature Engineering]
      B --> C[Apply Cutoff Date Filter]
      C --> D[Clean & Validate Data]
    end

    IN1[Historical Quote Data] e1@--> SG_DP
      e1@{ animation: fast }
    IN2[Config Parameters] e2@-->|test_size| SG_DP
      e2@{ animation: fast }

    subgraph SG_QR[Quote Reconstruction]
      E[Convert to Row Dictionaries]
      E --> F[Build Quote Objects]
      F --> G[Create LineItem Objects]
    end

    D e3@--> SG_QR
      e3@{ animation: fast }

    subgraph SG_AI[AI Markup Generation]
      H[Initialize MarkupFinder]
      H --> I[Parallel Processing]
      I --> J[Suggest Markup with Details]
      J --> K[Extract Suggestion Results]
    end

    G e4@--> I
      e4@{ animation: fast }
    IN2 e5@-->|search_space_size, model_versions| H
      e5@{ animation: fast }

    subgraph SG_AGG[Quote-Level Aggregation]
      L[Compute Quote Markup Rates]
      L --> M[Historical vs AI Comparison]
      M --> N[Separate by Quote Outcome]
    end

    K e6@--> SG_AGG
      e6@{ animation: fast }

    subgraph SG_EV[Results Generation]
      O[Calculate Greediness Metrics]
      O --> P[Generate Distribution Plots]
      P --> Q[Log to MLflow]
    end

    N e7@--> SG_EV
      e7@{ animation: fast }

  end

%% data styling
style IN1 fill:#fff9e6,stroke:#806000,stroke-width:2px
style D fill:#fff9e6,stroke:#806000,stroke-width:2px
style G fill:#fff9e6,stroke:#806000,stroke-width:2px
style K fill:#fff9e6,stroke:#806000,stroke-width:2px
style N fill:#fff9e6,stroke:#806000,stroke-width:2px

%% process styling
style A fill:#e6f2ff,stroke:#003d99,stroke-width:2px
style B fill:#e6f2ff,stroke:#003d99,stroke-width:2px
style C fill:#e6f2ff,stroke:#003d99,stroke-width:2px
style E fill:#e6f2ff,stroke:#003d99,stroke-width:2px
style F fill:#e6f2ff,stroke:#003d99,stroke-width:2px
style I fill:#e6f2ff,stroke:#003d99,stroke-width:2px
style J fill:#e6f2ff,stroke:#003d99,stroke-width:2px
style L fill:#e6f2ff,stroke:#003d99,stroke-width:2px
style M fill:#e6f2ff,stroke:#003d99,stroke-width:2px
style O fill:#e6f2ff,stroke:#003d99,stroke-width:2px
style P fill:#e6f2ff,stroke:#003d99,stroke-width:2px
style Q fill:#e6f2ff,stroke:#003d99,stroke-width:2px

%% models styling
style H fill:#e6ffe6,stroke:#009933,stroke-width:2px
```

### Stage-by-Stage Breakdown

#### Data Preparation

- **Load Quote/Order Data:**
    - Read historical CSV files containing quote and order information
    - Apply initial data type conversions and basic validation

- **Feature Engineering:**
    - Calculate derived fields (e.g., `total_seller_price`)
    - Apply the same feature engineering pipeline used for model training
    - Ensure consistency with training data preprocessing

- **Apply Cutoff Date Filter:**
    - Filter data based on configurable `test_size` parameter (e.g., last 1 months)
    - Should ideally match the same time period used for testing during conversion probability model training

- **Clean & Validate Data:**
    - Remove invalid or incomplete records
    - Validate required fields are present
    - Apply data quality checks

- **Outputs:**
    - Clean dataset with all required fields for quote reconstruction and evaluation

#### Quote Reconstruction

- **Purpose:** Transform historical data rows back into the same Quote and LineItem object structure used by the MarkupFinder model during normal operation.

- **Convert to Row Dictionaries:**
    - Transform DataFrame rows into dictionary format for parallel processing
    - Prepare data structure for efficient batch processing

- **Build Quote Objects:**
    - Reconstruct `Quote` objects with historical context including:
        - `qto` flag (quote-to-order status)
        - `request_purpose` (quote purpose classification)
        - `buyer_region` (geographic information)
        - `buyer_company_id` (customer identification)

- **Create LineItem Objects:**
    - Build `LineItem` objects for each quote line with:
        - `plant_category` (product classification)
        - `product_id` and `product_size_id` (product specifications)
        - `seller_price` (calculated from total_seller_price / quantity)
        - `quantity` (units quoted)

- **Outputs:**
    - Properly structured Quote and LineItem objects that can be processed by MarkupFinder

- **Implementation:** See `_process_row()` function in `src/gomat_markup_opt/evaluation/greediness.py`

#### AI Markup Generation

- **Purpose:** Use the MarkupFinder model to generate markup suggestions for each historical quote, simulating what the AI would have recommended at the time.

- **Initialize MarkupFinder:**
    - Load the MarkupFinder model with specified configuration:
        - `search_space_size` (model precision level)
        - `conversion_model_version` (specific model version)
        - `markup_space_model_version` (specific model version)

- **Parallel Processing:**
    - Use `ProcessPoolExecutor` to process quotes in parallel for performance
    - Apply progress tracking with `tqdm` for monitoring
    - Handle exceptions gracefully to avoid pipeline failures

- **Suggest Markup with Details:**
    - Call `suggest_markup_with_details()` for each reconstructed quote
    - Capture comprehensive suggestion information including bounds and probabilities
    - Process each quote independently for parallel efficiency

- **Extract Suggestion Results:**
    - Extract key metrics from suggestions:
        - `suggested_markup_rate` (primary AI recommendation)
        - `min_markup_rate` and `max_markup_rate` (confidence bounds)
        - `expected_converted_revenue` (revenue prediction)
        - `conversion_probability` (success probability)

- **Outputs:**
    - AI-generated markup suggestions for all historical quotes

- **Implementation:** See `MarkupFinder.suggest_markup_with_details()` in markup finder model

#### Quote-Level Aggregation

- **Purpose:** Aggregate line-item level data to quote-level metrics for meaningful business comparison.

- **Compute Quote Markup Rates:**
    - Calculate weighted average markup rates for multi-line quotes using formula:
        ```
        Quote Markup Rate = Σ(markup_rate × total_seller_price) / Σ((1 + markup_rate) × total_seller_price)
        ```
    - Apply to both historical applied rates and AI suggested rates

- **Historical vs AI Comparison:**
    - Create side-by-side comparison of:
        - `quote_applied_markup_rate` (what was actually used)
        - `quote_suggested_markup_rate` (what AI recommends)
        - `difference` (AI suggested - historical applied)

- **Separate by Quote Outcome:**
    - Split analysis by quote results using `target` field:
        - Accepted quotes (`target` = 1)
        - Refused quotes (`target` = 0)

- **Outputs:**
    - Quote-level comparison metrics ready for greediness calculation

#### Results Generation

- **Purpose:** Calculate final greediness metrics, generate visualizations, and log results for tracking and analysis.

- **Calculate Greediness Metrics:**
    - Compute mean greediness for accepted quotes
    - Compute mean greediness for refused quotes
    - Apply statistical aggregation methods

- **Generate Distribution Plots:**
    - Create histogram comparisons of markup rate distributions
    - Separate plots for accepted vs. refused quotes
    - Include both historical and AI suggested distributions
    - Export as PNG files for analysis

- **Log to MLflow:**
    - Log configuration parameters for reproducibility
    - Log greediness metrics for tracking
    - Log visualization figures for analysis
    - Ensure full experiment traceability

- **Outputs:**
    - Comprehensive analysis results with detailed metrics and visualizations

- **Implementation:** See `evaluate_greediness()` in `src/gomat_markup_opt/evaluation/greediness.py`

---

## Configuration Parameters

### Pipeline Settings (`AnalysisConfig`)
- **`test_size`:** Number of months of historical data to evaluate (typically 1-3 months)
- **Time period should match the test period used during model training**

### MarkupFinder Settings (`MarkupFinderConfig`)
- **`search_space_size`:** Precision level for AI markup generation
- **`conversion_model_version`:** Specific model version for reproducible evaluation
- **`markup_space_model_version`:** Specific model version for reproducible evaluation
- **`penalty_factor`:** Aggressiveness parameter affecting AI suggestions

### Processing Settings
- **Parallel Processing:** Uses `ProcessPoolExecutor` for performance optimization
- **Progress Tracking:** `tqdm` integration for monitoring long-running operations
- **Error Handling:** Graceful exception handling to prevent pipeline failures

 > See [Configuration Reference](../configuration.md) for complete parameter details and usage examples.

## Pipeline Execution

### Command-Line Usage
- **Script:** Use `src/scripts/evaluate_greediness.py` for command-line execution
- **Implementation:** See `evaluate_greediness()` in `src/gomat_markup_opt/evaluation/greediness.py`

### Execution Environment
- **Requirements:** Ensure MarkupFinder models are available in MLflow
- **Dependencies:** All required packages (pandas, matplotlib, tqdm, etc.) must be installed
- **Data Access:** Historical quote/order CSV files must be accessible
- **Output:** Results logged to MLflow with artifacts and metrics

---## Implementation References

### Core Components
- **Analysis Function:** `evaluate_greediness()` in `src/gomat_markup_opt/evaluation/greediness.py` - Main pipeline orchestration with MLflow logging
- **Quote Processing:** `_process_row()` in `src/gomat_markup_opt/evaluation/greediness.py` - Quote reconstruction logic
- **Configuration:** `AnalysisConfig` and `MarkupFinderConfig` in `src/gomat_markup_opt/config.py` - All configurable parameters

### Key Dependencies
- **MarkupFinder:** Core AI pricing engine for generating suggestions
- **MLflow:** Experiment tracking and result logging
- **ProcessPoolExecutor:** Parallel processing for performance optimization
- **pandas:** Data manipulation and analysis
- **matplotlib:** Visualization generation

---

## Related Documentation

> - [Greediness Evaluation](../evaluation/greediness_analysis.md) - Metrics, validation criteria, and business interpretation
> - [MarkupFinder Pipeline](../inference/markup_finder.md) - Core AI pricing engine used for markup suggestions
> - [Data Preparation](../data/data_preperation.md) - Complete data loading and preprocessing pipeline
> - [Quote and Order Data](../data/quote_and_order_data.md) - Historical business data structure and schemas
> - [Configuration Reference](../configuration.md) - All system settings and tuning parameters

---
