# Entry Scripts 🎬

This section provides detailed usage instructions for the entry scripts available in the Gomat Markup Optimization project. These scripts are designed to facilitate various tasks such as training models, running analyses, and starting the inference API.

## 1. Train All Models
This script runs the entire training pipeline: it trains the conversion model, then the markup space optimizer, and finally runs an evaluation.

**How to run:**
```bash
python src/scripts/train_all.py
```

**Options:**
```
  -h, --help            show this help message and exit
  --test_size int       Number of months of data to be used for
                        testing. Data will be taken from the end of
                        the dataset. (default: 1)
  --monotonic_cst dict[str,int]
                        Monotonic constraints for the model features
                        (e.g., {'feature_name': 1 or -1}).
  --classifier_params dict[str,Any]
                        Dictionary of parameters to be passed to the
                        classifier during initialization.
  --undersample_ratio float
                        Ratio of negative to positive samples after
                        balancing. (default: 2.0)
  --augment_high_markup_threshold float
                        Markup threshold to identify 'accepted high
                        markups'. (default: 0.5)
  --augment_low_markup_threshold float
                        Markup threshold to identify 'rejected low
                        markups'. (default: 0.5)
  --augment_high_markup_interval tuple[float,float]
                        (min, max) markup for synthetic 'rejected
                        low'. (default: (0.35, 0.8))
  --augment_low_markup_interval tuple[float,float]
                        (min, max) markup for synthetic 'accepted
                        high'. (default: (0.05, 0.3))
  --augment_sampling_percentage float
                        Percentage of samples to be generated for
                        augmentation. (default: 0.5)
  --history_cutoff_date date
                        Cutoff date for historical data used in
                        training. (default: 2022-11-01)
  --random_state {int,null}
                        Random state for reproducibility. (default:
                        null)
  --evaluate_model_performance bool
                        Evaluate model performance after training.
                        (default: False)
```

**Example using command-line arguments:**
```bash
python src/scripts/train_all.py --evaluate-model-performance --random-state 42
```

## 2. Run Greediness Analysis
This script runs an analysis using the trained models to suggest markups for historical data and saves the results.

**How to run:**
```bash
python src/scripts/evaluate_greediness.py [OPTIONS]
```

**Options:**
```
  -h, --help            show this help message and exit
  --test_size int       Number of months of data to be used for the test set in analysis. Data will be taken from the end of the dataset. (default: 3)
  --sample_fraction {float,null}
                        Fraction of data to sample for analysis. If
                        None, use the entire dataset. (default: 1)
  --search_space_size int
                        Number of points in the markup search space.
                        (default: 10)
  --conversion_model_version str
                        Registered version of the conversion model
                        to be used. Use 'latest' for the most recent
                        version. (default: latest)
  --markup_space_model_version str
                        Registered version of the markup model to be
                        used. Use 'latest' for the most recent
                        version. (default: latest)
  --random_state {int,null}
                        Random state for reproducibility. (default:
                        null)
```

**Example:**
```bash
python src/scripts/evaluate_greediness.py --sample_fraction 0.5 --test_size 6
```


## 3. Start Inference API
This script starts the inference API.

**How to run:**
```bash
python src/scripts/start_inference_api.py
```
The API will be available at `http://0.0.0.0:8000` by default. The port can be configured via the `GOMAT_PORT` environment variable.

**Options:**
```
  -h, --help  show this help message and exit
  --port int  Port to run the inference API on. (default: 8000)
```

## 4. Train Conversion Model (Individually)
This script trains only the conversion probability model.

**How to run:**
```bash
python src/scripts/train_conversion_model.py
```

## 5. Train Markup Space Optimizer (Individually)
This script trains only the markup space optimizer.

**How to run:**
```bash
python src/scripts/train_markup_space_optimizer.py
```

For more details on the API, refer to the [API Documentation](api_documentation.md) section.
