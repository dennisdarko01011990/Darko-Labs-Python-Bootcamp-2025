# Conversion Probability Model – Training Pipeline

## Overview

This document describes the end-to-end pipeline for training the **Conversion Probability Model**. It covers the data sources, features, pipeline stages, and outputs so readers can understand the workflow *without needing to read the code*.

## Quick Reference
- **Model Type:** [HistGradientBoostingClassifier](https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.HistGradientBoostingClassifier.html) with [Isotonic Calibration](https://scikit-learn.org/stable/modules/generated/sklearn.calibration.CalibratedClassifierCV.html)
- **Input Features:** 8 features (4 numerical, 4 categorical)
- **Output:** Conversion probability (0.0 to 1.0)
- **Key Dependencies:** scikit-learn, pandas, MLflow
- **Primary Metric:** [Brier Score](https://scikit-learn.org/stable/modules/model_evaluation.html#brier-score-loss) (lower is better)
- **Secondary Metrics:** [ROC AUC](https://scikit-learn.org/stable/modules/model_evaluation.html#roc-metrics), [Average Precision](https://scikit-learn.org/stable/modules/model_evaluation.html#precision-recall-f-measure-metrics), [Log Loss](https://scikit-learn.org/stable/modules/model_evaluation.html#log-loss)

## Feature Reference Table

The following table lists all the features used by the Conversion Probability Model. These features are required as input for both training and inference. Each feature is either numerical or categorical, and together they provide the information needed for the model to estimate the probability that a quote line item will be converted to an order.


| Feature              | Type        | Description                                                      |
|----------------------|------------|------------------------------------------------------------------|
| quantity             | Numerical  | Number of units in the quote line                                |
| total_seller_price   | Numerical  | Total seller price for the item (Seller Price × Quantity)        |
| markup_rate          | Numerical  | Markup percentage ((Buyer Price – Seller Price) / Seller Price)  |
| accepted_proportion  | Numerical  | **Training:** Historical conversion rate for each buyer, **Inference:** Last observed conversion rate for each buyer region                      |
| plant_category       | Categorical| Product category                                                 |
| buyer_region         | Categorical| Buyer’s geographic region                                        |
| qto                  | Categorical| Quote type                                                       |
| request_purpose      | Categorical| Purpose of the quote                                             |

**Target:**

- `conversion` (1 = converted to order, 0 = not converted)

**Output:**

- Probability estimate that each quote line item will be converted to an order

## Training Pipeline
The training pipeline describes the complete process for building the Conversion Probability Model, from raw data ingestion to model evaluation and logging.  The following sections and flowchart provide a step-by-step overview of the data transformations, feature engineering, model training, and evaluation procedures used to develop the final predictive model.

### Pipeline Flowchart

```mermaid
flowchart TD
  subgraph Training Pipeline


    subgraph SG_DP[Data Preparation]
      A[Load & Merge Data] --> B[Feature Engineering]
      B --> C[Clean & Filter Data]
    end

    IN1[Quote & Order Data] e1@--> SG_DP
      e1@{ animation: fast }
    IN2[Quote Lost Data] e2@--> SG_DP
      e2@{ animation: fast }

    IN3[Config Parameters] e02@-->|history_cutoff_date| SG_DP
      e02@{ animation: fast }

    subgraph SG_DS1[Data Splitting]
      D[Split Train/Test]
      D --> E[Test Data]
      D --> F[Train Data]
    end

      C e3@--> SG_DS1
      e3@{ animation: fast }

      IN3[Config Parameters] e02t@-->| test_size| SG_DS1
      e02t@{ animation: fast }

    subgraph SG_AG[Augmentation]
      G[Generate Synthetic Data]
      G --> H[Augmented Data]
    end

      F e4@--> SG_AG
      e4@{ animation: fast }

      IN3[Config Parameters] e02da@-->| random_state augment_high_markup_threshold augment_sampling_percentage augment_low_markup_interval augment_high_markup_interval| SG_AG
      e02da@{ animation: fast }


    subgraph SG_CS[Calibration Split]
      I[Split Train/Calibration]
      I --> J[Calibration Data]
      I --> K[Augmented Train Data]
    end

      H e6@--> SG_CS
      e6@{ animation: fast }

    subgraph SG_B[Balancing]
      L[Undersample Negatives]
      L --> M[Balanced Train Data]
    end

      K e7@--> SG_B
      e7@{ animation: fast }

      IN3[Config Parameters] e02b@-->| random_state undersample_ratio | SG_B
      e02b@{ animation: fast }

      N[Features List]

    subgraph SG_MT[Model Training]
      O[Set Up Classifier Training Pipeline incl: Transformers, Preprocessing, Classifier]
      O --> P[Fit Classifier Pipeline]
      P --> Q[Trained Classifier]
      R[Calibrate Trained Classifier]
      R --> S[Calibrated Classifier]
    end

      N eno@--> O
      eno@{ animation: fast }
      M e8@--> SG_MT
      e8@{ animation: fast }

      IN3[Config Parameters] e02mt@-->| random_state monotonic_cst classifier_params| SG_MT
      e02mt@{ animation: fast }

    subgraph SG_EL[Evaluation and Logging]
      T[Evaluate Calibrated Classifier on Test Data]
      T --> X[Final Model, log Metrics and Plots to MLflow]
    end

      E e5@--> SG_EL
        e5@{ animation: fast }
      J e9@--> R
        e9@{ animation: fast }
      S e10@--> SG_EL
        e10@{ animation: fast }
      Q e11@--> R
        e11@{ animation: fast }

  end

%% data
style IN1 fill:#fff9e6,stroke:#806000,stroke-width:2px
style IN2 fill:#fff9e6,stroke:#806000,stroke-width:2px

style C fill:#fff9e6,stroke:#806000,stroke-width:2px
style E fill:#fff9e6,stroke:#806000,stroke-width:2px
style F fill:#fff9e6,stroke:#806000,stroke-width:2px
style H fill:#fff9e6,stroke:#806000,stroke-width:2px
style J fill:#fff9e6,stroke:#806000,stroke-width:2px
style K fill:#fff9e6,stroke:#806000,stroke-width:2px
style M fill:#fff9e6,stroke:#806000,stroke-width:2px

%% models
style Q fill:#e6ffe6,stroke:#009933,stroke-width:2px
style S fill:#e6ffe6,stroke:#009933,stroke-width:2px

%% configuration and features
style IN3 fill:#f3e6ff,stroke:#6a0d83,stroke-width:2px
style N fill:#f3e6ff,stroke:#6a0d83,stroke-width:2px

style A fill:#e6f2ff,stroke:#003d99,stroke-width:2px
style B fill:#e6f2ff,stroke:#003d99,stroke-width:2px
style D fill:#e6f2ff,stroke:#003d99,stroke-width:2px
style G fill:#e6f2ff,stroke:#003d99,stroke-width:2px
style I fill:#e6f2ff,stroke:#003d99,stroke-width:2px
style L fill:#e6f2ff,stroke:#003d99,stroke-width:2px
style O fill:#e6f2ff,stroke:#003d99,stroke-width:2px
style P fill:#e6f2ff,stroke:#003d99,stroke-width:2px
style R fill:#e6f2ff,stroke:#003d99,stroke-width:2px
style T fill:#e6f2ff,stroke:#003d99,stroke-width:2px
style X fill:#e6f2ff,stroke:#003d99,stroke-width:2px

```


### Stage-by-Stage Breakdown

#### Data Preparation

- **Summary:**

    - All relevant quote and order data is collected, merged, engineered, and cleaned to produce a high-quality dataset for modeling.

    - This includes feature engineering, filtering by region and reason, and removing outliers.

    - Filter and keep only data from the `history_cutoff_date` (see configuration).

- **Outputs:**

    - Cleaned and feature-engineered dataset ready for modeling.

- **Data Cleaning:** See `cleanup_and_filter_quote_and_order_data()` in `src/gomat_markup_opt/preprocessing/cleanup.py`
- **Feature Engineering:** See `engineer_features()` in `src/gomat_markup_opt/preprocessing/feature_engineering.py`

> **Data Preparation Details:** See [Data Preparation for MarkupML Models](../data/data_preperation.md) for comprehensive data loading, cleaning, and feature engineering methodology.

#### Data Splitting

- **Purpose:** Split the data into training, and testing.

    - Split data chronologically by `test_size` (if `1` then last month data is used for testing)

- **Outputs:**
    - Training and test sets


#### Augmentation

- **Purpose:** Enrich the training data and address class imbalance by generating synthetic samples.

- **Generate Synthetic Data**
      - Identify two groups:
          1. **Accepted quotes with high markup** (converted, markup > `augment_high_markup_threshold`)
          2. **Rejected quotes with low markup** (not converted, markup < `augment_low_markup_threshold`)
      - For each group, select a percentage of samples (`augment_sampling_percentage`):
          - For accepted high-markup quotes, assign a random low markup (`augment_low_markup_interval`)
          - For rejected low-markup quotes, assign a random high markup (`augment_high_markup_interval`)
      - Add these synthetic samples to the original dataset to help the model learn from.

- **Outputs:**
    - Augmented training dataset containing both original and synthetic samples

- **Implementation:** See `augment_data()` in `src/gomat_markup_opt/training/data_augmentation.py`

  > *See [Configuration ⚙️](../configuration.md) for details on all configurable parameters used here.*


#### Calibration Split

- **Purpose:** Prepare a calibration set for probability calibration and separate remaining data for balancing.

- **Split Train/Calibration**
    - Split augmented training data chronologically (e.g., last 6 months for calibration)
    - Assign calibration data for model calibration
    - Assign remaining train data for balancing

- **Outputs:**
    - Calibration set
    - Augmented train data

#### Balancing

- **Purpose:** Balance the training data to prevent model bias toward the majority class (i.e., too many negative/non-converted quotes).

- **Undersample Negatives**
    - For each training run, count the number of positive (converted) quotes.
    - Randomly sample negative (not converted) quotes so that the ratio of negatives to positives matches the configured `undersample_ratio` (e.g., 2:1).
    - If there are not enough negatives to meet the ratio, use all available negatives.
    - This ensures the model is trained on a balanced dataset and is not overwhelmed by the majority class.

- **Outputs:**
    - Balanced training dataset with the desired positive:negative ratio.

#### Model Training

- **Purpose:** Build, train, and calibrate the machine learning pipeline for conversion prediction.

- **Select Features**
    - Choose relevant numerical and categorical features for modeling see the feature list table above.

- **Set Up Classifier Training Pipeline**
    - Build a scikit-learn pipeline including:
        - Transformers (e.g., AcceptedProportionTransformer)
            - Needed for serving pipeline to get the `accepted_proportion`
        - Preprocessing (scaling with `MinMaxScaler`, encoding with `OrdinalEncoder`)
        - Core classifier (`HistGradientBoostingClassifier`)


- **Fit Classifier Pipeline**
    - Hyperparameter tuning via grid search (`stratified`, `Brier score`)

- **Trained Classifier**
    - Outputs the fitted classifier
    - Provides the probability estimate that each quote line item will be converted to an order.

- **Calibrate Trained Classifier**
    - Use calibration data to calibrate probability estimates (e.g., isotonic regression)

- **Outputs:**
    - Fitted and calibrated ML model that estimates the probability of conversion for a given (`quantity`, `total_seller_price`, `markup_rate`, `accepted_proportion`, `plant_category`, `buyer_region`, `qto`, `request_purpose`)

- **Implementation:** See `ConversionProbabilityModel.fit()` in `src/gomat_markup_opt/models/conversion_probability_model.py`
- **Calibration:** Isotonic calibration integrated in model pipeline - see `src/gomat_markup_opt/models/conversion_probability_model.py`

#### Evaluation and Logging

- **Purpose:** Evaluate model performance and ensure reproducibility through experiment tracking.

- **Performance Assessment**
    - Evaluate model on holdout test data using comprehensive metrics suite
    - Generate diagnostic visualizations for model validation
    - Results automatically logged to MLflow for experiment comparison

- **Outputs:**
    - Performance metrics and diagnostic plots
    - Complete MLflow experiment tracking with model artifacts

See [Conversion Probability Model Evaluation](../evaluation/conversion_probability_model_evaluation.md) for full details.

## Inference Pipeline
The inference pipeline uses the trained and calibrated Conversion Probability Model to estimate the probability that a new quote line item will be converted to an order.

### Inference Flowchart
```mermaid
flowchart TD
  subgraph INFER[Inference Pipeline]
    A[Inference Data as DataFrame]

    subgraph PRETRAINED[Pretrained Pipeline]
      subgraph PRETRTRANSF[Pretrained Transformers]
        T1[AcceptedProportionTransformer]
        T1 -->|added accepted_proportion| T2[Scaling Numeric Features]
        T2 -->|scaled numerics| T3[Encoding Categorical Features]
      end

        T3 --> TD[Transformed Inference Data]

      subgraph PRETRAMODELS[Pretrained Models]
        C[Classifier:<br/>HistGradientBoostingClassifier]
        C -->|raw probability| D[Probability Calibration:<br/>Isotonic Regression]
      end
    end

    A eat1@--> T1
      eat1@{ animation: fast }

    TD eatdpt@--> PRETRAMODELS
      eatdpt@{ animation: fast }
    D --> OUT1[Final Prediction of Conversion Probability]
  end

  %% Inputs and Outputs
  style A fill:#fff9e6,stroke:#806000,stroke-width:2px
  style TD fill:#fff9e6,stroke:#806000,stroke-width:2px
  style OUT1 fill:#fff9e6,stroke:#806000,stroke-width:2px
  style T1 fill:#e6ffe6,stroke:#009933,stroke-width:2px
  style T2 fill:#e6ffe6,stroke:#009933,stroke-width:2px
  style T3 fill:#e6ffe6,stroke:#009933,stroke-width:2px
  style C fill:#e6ffe6,stroke:#009933,stroke-width:2px
  style D fill:#e6ffe6,stroke:#009933,stroke-width:2px
```


### Stage-by-Stage Breakdown

The inference pipeline uses the trained and calibrated Conversion Probability Model to estimate the probability that a new quote line item will be converted to an order. All preprocessing, feature engineering, and calibration are encapsulated in the deployed model.


#### **Inference Data as DataFrame**
  - DataFrame containing all required raw features except `accepted_proportion` for each quote line item (see Feature Reference Table).

#### **Pretrained Pipeline**

- **Pretrained Transformers**
    - **Purpose:** Preprocess and enrich the inference data so it matches what the trained model expects.

    - **AcceptedProportionTransformer:**

        - **Action:**
            - The `AcceptedProportionTransformer` calculates and fills in the `accepted_proportion` feature for each row in the inference data, based on the buyer's region.

        - **During training:**
            - The transformer "learns" the most recent (last) `accepted_proportion` value for each `buyer_region` from the training data.
            - This mapping is stored internally for later use.

        - **During inference (prediction):**
            - For each row, the transformer fills it using the value for that `buyer_region` learned from the training data (last `accepted_proportion`).
            - If the buyer's region was not seen during training, it defaults to `0.0`.
            - This ensures that every row has a valid `accepted_proportion` value

        - **Output:**
            - Returns a DataFrame identical to the input, but with the `accepted_proportion` column filled in for all rows, using the mapping learned from the training data.


    - **Scaling Numeric Features:**
        - **Action:** Applies scaling to all numerical features using the scaler from the training pipeline.

    - **Encoding Categorical Features:**
        - **Action:** Encodes categorical variables using the trained encoder from the training pipeline.


- **Pretrained Models**

    - **Classifier: HistGradientBoostingClassifier:**

        - **Input:** Transformed inference data.
        - **Action:** Predicts the raw probability of conversion for each line item.
        - **Output:** Raw probability scores.

      - **Probability Calibration: Isotonic Regression:**

        - **Input:** Raw probability from the classifier.
        - **Action:** Calibrates the probability estimates to improve reliability.
        - **Output:** Final, calibrated probability of conversion.


#### **Final Prediction Output**

- The final, calibrated probability that each row in the inference data will be converted to an order.

---

## Implementation References

### Core Components
- **Model Class:** `ConversionProbabilityModel` in `src/gomat_markup_opt/models/conversion_probability_model.py` - HistGradientBoostingClassifier with isotonic calibration
- **Training Script:** `src/gomat_markup_opt/training/train_conversion_model.py` - Complete training pipeline orchestration
- **Entry Script:** `src/scripts/train_conversion_model.py` - Command-line training interface
- **Data Augmentation:** `src/gomat_markup_opt/training/data_augmentation.py` - Synthetic data generation for class balance
- **Feature Engineering:** `src/gomat_markup_opt/preprocessing/feature_engineering.py` - Feature transformation pipeline
- **Custom Transformer:** `AcceptedProportionTransformer` in `src/gomat_markup_opt/models/accepted_proportion_transformer.py` - Historical conversion rate calculation
- **Configuration:** `ConversionProbabilitySettings` in `src/gomat_markup_opt/config.py` - All configurable parameters

### Key Functions
- **Training:** `train()` - Main training orchestration with MLflow logging
- **Data Augmentation:** `augment_data()` - Synthetic minority class generation for class balance
- **Feature Engineering:** `engineer_features()` - Complete feature transformation pipeline
- **Model Training:** HistGradientBoostingClassifier with cross-validation
- **Prediction:** `predict_proba()` - Probability estimation for conversion
- **Calibration:** Isotonic regression for probability calibration
- **Evaluation:** Brier score, ROC-AUC, average precision, log loss

---

> **Related Documentation:**

> - [Model Evaluation](../evaluation/conversion_probability_model_evaluation.md) - Comprehensive performance assessment and metrics
> - [Data Preparation](../data/data_preperation.md)
> - [Configuration Reference](../configuration.md)
> - [Quote and Order Data](../data/quote_and_order_data.md)
> - [Quote Lost Data](../data/quote_lost_data.md)

---
