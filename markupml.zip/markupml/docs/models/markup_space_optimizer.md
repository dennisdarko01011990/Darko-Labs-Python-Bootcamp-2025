# Markup Space Optimizer

## Overview

This document describes the end-to-end pipeline for the **Markup Space Optimizer**, which determines optimal markup intervals for product line items based on historical quote/order data.
It covers the data sources, features, pipeline stages, and outputs so readers can understand the workflow *without needing to read the code*.

## Quick Reference
- **Model Type:** [Quantile-based Interval Estimator](https://numpy.org/doc/stable/reference/generated/numpy.quantile.html)
- **Input Features:** 5+ categorical features (configurable grouping)
- **Output:** Markup intervals (low, high) for each feature group
- **Primary Metric:** Coverage Rate (proportion of actual values within intervals)
- **Secondary Metrics:** Average Interval Width, Group Coverage

## Feature Reference Table

The following table lists all the features used by the Markup Space Optimizer. The specific combination of features used for grouping is configurable.

| Feature              | Type        | Description                                                      |
|----------------------|------------|------------------------------------------------------------------|
| qto                  | Categorical| Quote type                                                       |
| request_purpose      | Categorical| Purpose of the quote                                             |
| buyer_region         | Categorical| Buyer's geographic region                                        |
| product_id           | Categorical| Product identifier                                               |
| product_size_id      | Categorical| Product size identifier                                          |
| plant_category       | Categorical| Product category (optional)                                      |

**Target:**
- `markup_rate` (used to calculate quantile-based intervals)

**Output:**
- Markup intervals (`low`, `high`) for each feature group combination

## Training Pipeline

The training pipeline describes the complete process for building the Markup Space Optimizer, from raw data ingestion to model evaluation and logging. The following sections and flowchart provide a step-by-step overview of the data transformations, feature engineering, and interval estimation procedures.

### Training Pipeline Flowchart

```mermaid
flowchart TD
  subgraph Training Pipeline
    subgraph SG_DP[Data Preparation]
      A[Load & Merge Data] --> B[Feature Engineering]
      B --> C[Clean & Filter Data]
    end

    IN1[Quote & Order Data] e1@--> SG_DP
      e1@{ animation: fast }

    IN2[Config Parameters] e02@-->|data_size_months| SG_DP
      e02@{ animation: fast }

    subgraph SG_IE[Training: Interval Estimation]
      D[Group Data by Features]
      D --> E[Calculate Quantile Intervals]
      E --> F[Apply Constraints & Defaults]
      F --> G[Fitted Interval Model]
    end

    C e3@--> SG_IE
      e3@{ animation: fast }

    IN2[Config Parameters] e02ie@-->|quantile_low quantile_high minimum_range_size min_markup max_markup default_range| SG_IE
      e02ie@{ animation: fast }

    subgraph SG_EL[Evaluation and Logging]
      H[Evaluate Interval Coverage]
      H --> I[Log Metrics and Model to MLflow]
    end

    C e4@--> SG_EL
      e4@{ animation: fast }
    G e5@--> SG_EL
      e5@{ animation: fast }
  end

  %% data
  style IN1 fill:#fff9e6,stroke:#806000,stroke-width:2px
  style C fill:#fff9e6,stroke:#806000,stroke-width:2px
  style G fill:#e6ffe6,stroke:#009933,stroke-width:2px

  %% config
  style IN2 fill:#f3e6ff,stroke:#6a0d83,stroke-width:2px

  %% processes
  style A fill:#e6f2ff,stroke:#003d99,stroke-width:2px
  style B fill:#e6f2ff,stroke:#003d99,stroke-width:2px
  style D fill:#e6f2ff,stroke:#003d99,stroke-width:2px
  style E fill:#e6f2ff,stroke:#003d99,stroke-width:2px
  style F fill:#e6f2ff,stroke:#003d99,stroke-width:2px
  style H fill:#e6f2ff,stroke:#003d99,stroke-width:2px
  style I fill:#e6f2ff,stroke:#003d99,stroke-width:2px
```

---

### Stage-by-Stage Breakdown

#### Data Preparation

**Summary:**

- All relevant quote and order data is collected, merged, engineered, and cleaned to produce a high-quality dataset for modeling.
- This includes feature engineering, converting categorical variables to strings for grouping, filtering by region and reason, and removing outliers.
- Filter and keep only data from the last `data_size_months` (see configuration).

**Outputs:**

- Cleaned and feature-engineered dataset ready for interval estimation.

> **Data Preparation Details:** See [Data Preparation for MarkupML Models](../data/data_preperation.md) for comprehensive data loading, cleaning, and feature engineering methodology.

---

#### Interval Estimation

**Purpose:** Calculate optimal markup intervals for each feature group combination.

- **Group Data by Features:**

    - Group historical data by configured feature combinations (e.g., `qto`, `request_purpose`, `buyer_region`)
    - Each unique combination becomes a separate group for interval calculation

- **Calculate Quantile Intervals:**

    - For each group, compute `quantile_low` and `quantile_high` of markup rates

- **Apply Constraints & Defaults:**

    - Ensure minimum interval width (`minimum_range_size`): If calculated interval width is smaller than the configured minimum, expand the interval symmetrically around the midpoint
    - Clip intervals to global bounds (`min_markup`, `max_markup`)
    - Assign `default_range` to unseen feature combinations

**Outputs:**

- Fitted interval model with markup ranges for each feature group

- **Implementation:** See `MarkupSpaceOptimizer.fit()` in `src/gomat_markup_opt/models/markup_space_optimizer.py`

---

#### Evaluation and Logging

**Purpose:** Assess interval quality and ensure experiment reproducibility.

- **Evaluate Performance:** Calculate coverage rate and interval width metrics to assess model quality
- **Log to MLflow:** Track model, parameters, metrics, and artifacts for experiment reproducibility

**Outputs:**
- Evaluation metrics and tracked MLflow run with final model

> **Detailed Evaluation Methodology:** See [Markup Space Optimizer Evaluation](../evaluation/markup_space_optimizer_evaluation.md) for comprehensive assessment criteria, performance thresholds, and business impact analysis.

## Inference Pipeline

The inference pipeline uses the trained Markup Space Optimizer to predict markup intervals for new feature combinations.

### Inference Pipeline Flowchart

```mermaid
flowchart TD
  subgraph INFER[Inference Pipeline]
    A[Inference Data as DataFrame]

    subgraph PRETRAINED[Pretrained Model]
      B[Extract Feature Group Index]
      B --> C[Lookup Intervals for Groups]
      C --> D[Apply Default for Unseen Groups]
      D --> E[Merge with Original Data]
    end

    A -->|DataFrame| PRETRAINED

    E --> OUT1[Inference Data + Markup Intervals<br/>low, high]
  end

  %% Inputs and Outputs
  style A fill:#fff9e6,stroke:#806000,stroke-width:2px
  style OUT1 fill:#fff9e6,stroke:#806000,stroke-width:2px
  style B fill:#e6ffe6,stroke:#009933,stroke-width:2px
  style C fill:#e6ffe6,stroke:#009933,stroke-width:2px
  style D fill:#e6ffe6,stroke:#009933,stroke-width:2px
  style E fill:#e6ffe6,stroke:#009933,stroke-width:2px
```

### Stage-by-Stage Breakdown

#### **Inference Data as DataFrame**
- DataFrame containing all required grouping features for each item (see Feature Reference Table)

#### **Pretrained Model**

**Purpose:** Generate markup intervals for new feature combinations using the trained model.

- **Group Lookup:** Extract feature groups and retrieve corresponding intervals from training
- **Handle Unseen Groups:** Apply default ranges for new feature combinations not seen during training
- **Merge Results:** Add markup interval predictions to original input data

**Outputs:**
- Enhanced DataFrame with `low` and `high` markup intervals for each row

- **Implementation:** See `MarkupSpaceOptimizer.predict()` in `src/gomat_markup_opt/models/markup_space_optimizer.py`

---

## Usage and Output

* **Input:**

      * DataFrame containing required features (see table below)
      * Configuration parameters for interval estimation

* **Output:**

      * DataFrame with predicted markup intervals (`low`, `high`) for each group

---

## Feature Reference Table

| Feature              | Type        | Description                                                      |
|----------------------|------------|------------------------------------------------------------------|
| qto                  | Categorical| Quote type                                                       |
| request_purpose      | Categorical| Purpose of the quote                                             |
| buyer_region         | Categorical| Buyer’s geographic region                                        |
| product_id           | Categorical| Product identifier                                               |
| product_size_id      | Categorical| Product size identifier                                          |
| ...                  | ...        | Additional groupby features as configured                        |

**Output:**
- `low`, `high` markup interval for each group

---

## Implementation References

### Core Components
- **Model Class:** `MarkupSpaceOptimizer` in `src/gomat_markup_opt/models/markup_space_optimizer.py` - Quantile-based interval estimation model
- **Training Script:** `src/gomat_markup_opt/training/train_markup_space_optimizer.py` - Complete training pipeline orchestration
- **Inference Implementation:** `src/gomat_markup_opt/inference/markup_suggestion.py` - Production inference endpoints
- **Configuration:** `MarkupSpaceOptimizerSettings` in `src/gomat_markup_opt/config.py` - All configurable parameters

### Key Functions
- **Training:** `train()` - Main training orchestration function
- **Interval Estimation:** `fit()` - Quantile-based interval calculation using numpy percentiles
- **Prediction:** `predict()` - Interval lookup for new feature combinations
- **Evaluation:** `_evaluate_model()` - Coverage rate and average interval width metrics

---

## Related Documentation

> - [Model Evaluation](../evaluation/markup_space_optimizer_evaluation.md) - Comprehensive performance assessment and metrics
> - [Data Preparation](../data/data_preperation.md) - Complete data loading and preprocessing pipeline
> - [Conversion Probability Model](conversion_probability_model.md) - Related training pipeline
> - [Configuration Reference](../configuration.md) - All configurable parameters
> - [MarkupFinder Pipeline](../inference/markup_finder.md) - Production inference implementation

---

> **Configuration Reference:**
> For a complete list of all configurable parameters (including grouping, quantiles, and bounds), see [`src/gomat_markup_opt/config.py`](../../src/gomat_markup_opt/config.py)
