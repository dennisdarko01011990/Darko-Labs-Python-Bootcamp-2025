# Markup Space Optimizer – Evaluation

## Overview

Evaluates the **Markup Space Optimizer** that predicts optimal markup intervals for product line items. Ensures intervals effectively capture real markup ranges for business decision-making.

## Key Evaluation Metrics



| Metric | Purpose | Target |
|--------|---------|--------|
| **Coverage Rate** | Validates interval estimation | *To be determined from experiments*|
| **Average Interval Width** | Business usability | *To be determined from experiments* |


### Coverage Rate (Primary Metric)

**Definition:** Proportion of actual markup rates that fall within predicted intervals

**Mathematical Formula:**
```
Coverage Rate = (1/n) × Σ(i=1 to n) I(low_i ≤ markup_rate_i ≤ high_i)
```

Where:

- `n` = total number of line items
- `I()` = indicator function (1 if condition true, 0 if false)
- `low_i` = predicted lower bound for item i
- `high_i` = predicted upper bound for item i
- `markup_rate_i` = actual markup rate for item i

**Target:** Should match quantile settings (e.g., 80% for 0.1-0.9 quantiles)

### Average Interval Width

**Definition:** Mean width of predicted markup intervals across all items

**Mathematical Formula:**
```
Average Interval Width = (1/n) × Σ(i=1 to n) (high_i - low_i)
```

Where:

- `n` = total number of line items
- `high_i - low_i` = interval width for item i



## Configuration & Tracking

**MLflow Integration:**

- Coverage rate, interval width, and model artifacts automatically logged
- Historical comparison and performance monitoring

**Key Settings:**

- `quantile_low`/`quantile_high`: Target coverage (default: 0.1/0.9 = 80%)
- `evaluate_model_performance`: Enable/disable evaluation (default: True)

---

## Related Documentation

> - [Markup Space Optimizer Training](../models/markup_space_optimizer.md) - Complete training pipeline
> - [Configuration Reference](../configuration.md) - All parameters
> - [Markup Finder Pipeline](../inference/markup_finder.md) - Production usage

---
