# Greediness Analysis – Evaluation Metrics

## Overview

Measures whether AI markup suggestions strike the right balance between profitability and competitiveness by comparing AI recommendations against historical pricing decisions.

## Core Metric Definition

**Greediness Score = AI Suggested Markup - Historical Applied Markup**

*Calculated at quote level by aggregating line item suggestions and historical markups*

**Quote-Level Aggregation Formula:**
```
Quote Markup Rate = Σ(markup_rate × total_seller_price) / Σ((1 + markup_rate) × total_seller_price)
```

**Final Greediness Calculation:**
```
Quote Greediness = Quote_AI_Markup_Rate - Quote_Historical_Markup_Rate
```

**Reported Metrics (Average across all quotes):**
```
accepted_quotes_greediness = Average(Quote Greediness) for accepted quotes
refused_quotes_greediness = Average(Quote Greediness) for refused quotes
```

| Score | Meaning | Business Impact |
|-------|---------|-----------------|
| **Positive (+)** | AI more aggressive | Higher markups than historical |
| **Negative (-)** | AI more conservative | Lower markups than historical |
| **Zero (0)** | Historical alignment | AI copies past decisions |

## Distribution Plot Analysis

The evaluation generates histogram plots comparing AI suggested vs. historical markup rate distributions for both accepted and refused quotes.

### Plot Structure
- **X-axis:** Markup Rate (percentage)
- **Y-axis:** Percentage of Quotes (what % of total quotes fall into each markup rate range)
- **Two overlapping histograms:**
    - **Blue bars:** "Actual" (Historical markup rates)
    - **Orange bars:** "Suggested" (AI markup rates)
- **5 bins:** Markup rates grouped into 5 ranges for comparison

**Y-axis Calculation:**
```
For each bin: Height = (Number of quotes in this markup range / Total quotes) × 100%
```
*Example: If 20% shows on Y-axis, it means 20% of all quotes had markup rates in that range*

### How to Read the Plots

**Ideal Patterns:**

- **Accepted Quotes Plot:** AI (orange) bars should be slightly to the right of Historical (blue) bars
    - Shows AI suggesting higher markups to capture missed profit
- **Refused Quotes Plot:** AI (orange) bars should be slightly to the left of Historical (blue) bars
    - Shows AI suggesting lower markups to improve competitiveness

**Warning Signs:**

- **Identical distributions:** AI copying historical decisions exactly
- **AI much higher on both plots:** Overly aggressive across all quote types
- **AI much lower on accepted quotes:** Missing profit opportunities

### Business Interpretation
- **Separation between bars:** Shows how differently AI prices compared to historical decisions
- **Distribution shape:** Reveals consistency of AI recommendations vs. historical variance
- **Bin concentration:** Indicates where most quotes fall in the markup spectrum

## Evaluation Approach

- **Method:** AI generates markup suggestions for each line item, then aggregates to quote level for comparison against historical quote-level decisions
- **Split Analysis:** Separate evaluation for accepted vs. refused quotes

## Performance Targets

### ✅ Ideal Performance
- **Accepted Quotes:** +1% to +3% (capture missed profit)
- **Refused Quotes:** -2% to -3% (improve competitiveness)

### ⚠️ Warning Signs
- **Accepted Quotes > +3%:** Risk of overpricing winnable opportunities
- **Refused Quotes > +2%:** Risk of making losing quotes worse
- **Both near 0%:** AI copying without optimization

### 🚨 Critical Issues
- **Accepted Quotes < -2%:** Missing profit opportunities
- **Both consistently positive:** Overly aggressive across all quotes

## Tracking & Monitoring

**MLflow Metrics:**

- `accepted_quotes_greediness` - Average performance on historically successful quotes
- `refused_quotes_greediness` - Average performance on historically unsuccessful quotes

**Outputs:**

- Distribution comparison plots (PNG artifacts in MLflow)
- Greediness metrics logged to MLflow

---

## Related Documentation

> - [Greediness Analysis Pipeline](../analysis/greediness_analysis.md) - Technical implementation and data processing
> - [MarkupFinder Pipeline](../inference/markup_finder.md) - Core AI pricing engine
> - [Configuration Reference](../configuration.md) - System settings and parameters

---
