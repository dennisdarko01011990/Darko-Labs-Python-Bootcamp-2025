# Conversion Probability Model – Evaluation

## Overview

Evaluates the **Conversion Probability Model** that predicts whether a quote line item will convert to an order. Ensures reliable probability estimates for production markup decisions.

## Key Evaluation Metrics

| Metric | Purpose  | Target |
|--------|---------|--------|
| **Brier Score** | Overall prediction quality| *To be determined from experiments* |
| **ROC AUC** | Ranking ability | *To be determined from experiments* |
| **Average Precision** | Positive class focus | *To be determined from experiments* |
| **Log Loss** | Probability calibration | *To be determined from experiments* |

## Visual Diagnostics

### Calibration Plot
- **Purpose:** Shows if predicted probabilities match actual conversion rates
- **Ideal:** Points follow diagonal line (predicted = actual)
- **Warning Signs:** Points consistently above/below diagonal

### Precision-Recall Curve
- **Purpose:** Trade-off between accuracy and coverage of conversions
- **Ideal:** High curve with large area under curve
- **Business Impact:** Better identification of convertible quotes

## Tracking & Configuration

**MLflow Integration:**

- All metrics and diagnostic plots automatically logged
- Historical comparison and reproducibility

## Related Documentation

> - [Conversion Probability Model Training](../models/conversion_probability_model.md) - Complete training pipeline
> - [Configuration Reference](../configuration.md) - All parameters
> - [Markup Finder Pipeline](../inference/markup_finder.md) - Production usage

---
