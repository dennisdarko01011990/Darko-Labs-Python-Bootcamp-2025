# Markup Finder – Inference Pipeline

## Overview

This document describes the **Markup Finder** inference pipeline, which powers the `/suggest_markups/` endpoint of the Markup Optimization API.
The system combines two trained ML models to generate optimal markup suggestions for incoming quote line items by predicting markup intervals and conversion probabilities.

It covers the main components, workflow, and optimization logic so readers can understand the system *without needing to read the code*.

## Quick Reference
- **Core Class:** `MarkupFinder` in `markup_suggestion.py`
- **Interface:** `/suggest_markups/` endpoint
- **Input Schema:** `Quote` with line items
- **Output Schema:** `MarkupSuggestionResponse` with detailed suggestions
- **Models Used:** Conversion Probability Model + Markup Space Optimizer
- **Optimization Metric:** Reward Score `(markup × conversion_probability - penalty × log(1 + markup))`
- **Fallback Strategy:** Default markup interval [0.17, 0.23] if model prediction fails

## Input and Output

**Input:**
- `Quote` object containing buyer information and line items

**Output:**
- `MarkupSuggestionResponse` containing a list of `MarkupSuggestionDetails` for each line item
- Each suggestion includes optimal markup rate, conversion probability, expected revenue, and detailed calculations

> See [API Documentation](../api_documentation.md) for complete schema details of both input and output formats.

## Inference Pipeline

The inference pipeline orchestrates the markup optimization process by combining two trained models to generate optimal markup suggestions. The following flowchart and breakdown describe the complete workflow from API request to response.

### Inference Pipeline Flowchart

```mermaid
flowchart TD

  subgraph REQUEST[Request Processing]
    A1[Receive Request:<br/>Quote with Line Items] --> A2[Parse & Validate Input:<br/>Quote Schema]
  end

  subgraph MODEL_LOADING[Trained Models]
    B2[Load Markup Space Optimizer<br/>from MLflow] --> B1[Load Conversion Probability Model<br/>from MLflow]
  end

    C1[Prepare Line Items DataFrame<br/>Extract & Transform Features]

  subgraph OPTIMIZATION[Markup Optimization Pipeline]
    C2[Predict Markup Interval<br/>low, high per Line Item]
    C3[Generate Candidate Markup Grid<br/>search_space_size points]
    C4[Batch Predict Conversion Probability<br/>for All Candidates]
    C5[Compute Reward Score<br/>markup × conversion - penalty × log1p markup]
    C6[Calculate Expected Revenue<br/>quantity × markup_amount × conversion_prob]
    C7[Select Optimal Markup<br/>Highest Reward Score]
  end

    C8[Suggestion Details:<br/>Optimal Markup + All Calculations]

  subgraph RESPONSE[Response]
    D1[Return MarkupSuggestionResponse<br/>List of MarkupSuggestionDetails]
  end

  %% Flow connections
  A2 --> C1
  C2 -->|Infrance data| B2
  B2 -->|markup intervals| C2
  C4 -->|Infrance data| B1
  B1 -->|markup suggestions| C4
  C1 --> OPTIMIZATION
  C2 --> C3
  C3 --> C4
  C4 --> C5
  C5 --> C6
  C6 --> C7
  C7 --> C8
  C8 --> D1

  %% Styling
  %% Orange data nodes

  style C1 fill:#fff9e6,stroke:#806000,stroke-width:2px
  style C8 fill:#fff9e6,stroke:#806000,stroke-width:2px

  %% Green model nodes
  style B1 fill:#e6ffe6,stroke:#009933,stroke-width:2px
  style B2 fill:#e6ffe6,stroke:#009933,stroke-width:2px

  %% Light green model-related process nodes
  style C2 fill:#f0fff0,stroke:#009933,stroke-width:2px
  style C4 fill:#f0fff0,stroke:#009933,stroke-width:2px

  %% Blue process nodes
  style A1 fill:#e6f2ff,stroke:#003d99,stroke-width:2px
  style A2 fill:#e6f2ff,stroke:#003d99,stroke-width:2px
  style C3 fill:#e6f2ff,stroke:#003d99,stroke-width:2px
  style C5 fill:#e6f2ff,stroke:#003d99,stroke-width:2px
  style C6 fill:#e6f2ff,stroke:#003d99,stroke-width:2px
  style C7 fill:#e6f2ff,stroke:#003d99,stroke-width:2px
  style D1 fill:#e6f2ff,stroke:#003d99,stroke-width:2px
```

### Stage-by-Stage Breakdown

#### Request Processing

- **Receive & Validate Request:**
    - **Purpose:** Accept and validate incoming markup suggestion requests.
    - **Input:** `Quote` payload containing buyer information and line items.
    - **Validation:** Pydantic models automatically parse and validate data types, required fields, and constraints.
    - **Error Handling:** Returns validation errors with detailed field-level error messages.

#### Model Initialization (Pre-loaded at Startup)

- **Load Models from MLflow:**
    - **Purpose:** Initialize both required ML models for the optimization process.
    - **Models Loaded:**
        - **Conversion Probability Model:** Predicts likelihood of quote-to-order conversion (see [Conversion Probability Model](../models/conversion_probability_model.md))
        - **Markup Space Optimizer:** Predicts reasonable markup intervals for line items (see [Markup Space Optimizer](../models/markup_space_optimizer.md))
    - **Configuration:** Model versions specified in `MarkupFinderConfig` (`conversion_model_version`, `markup_space_model_version`)
    - **Fallback:** System fails if models cannot be loaded

#### Data Preparation

- **Prepare Line Items DataFrame:**
    - **Purpose:** Transform input quote data into the format expected by ML models.
    - **Process:** Extract features from quote and line items, calculate derived fields (e.g., `total_seller_price`)
    - **Output:** Structured DataFrame with all required features for each line item

#### Markup Optimization Pipeline

- **Prepare Line Items DataFrame:**
    - **Purpose:** Transform input quote data into the format expected by ML models.
    - **Process:** Extract features from quote and line items, calculate derived fields (e.g., `total_seller_price`)
    - **Output:** Structured DataFrame with all required features for each line item

- **Predict Markup Interval:**
    - **Purpose:** Determine reasonable markup bounds for each line item using historical data patterns.
    - **Model:** Markup Space Optimizer predicts `[low, high]` markup interval
    - **Fallback Strategy:** If prediction fails, uses default interval `[0.17, 0.23]` (17% to 23% markup)
    - **Output:** Markup boundaries for search space definition

- **Generate Candidate Markup Grid:**
    - **Purpose:** Create discrete markup options within the predicted interval for optimization.
    - **Method:** Generate `search_space_size` evenly spaced points between `low` and `high` bounds
    - **Configuration:** Grid size controlled by `search_space_size` in `MarkupFinderConfig`
    - **Output:** Array of candidate markup rates for evaluation

- **Batch Predict Conversion Probability:**
    - **Purpose:** Estimate conversion likelihood for each markup candidate efficiently.
    - **Process:**
        - Create batch DataFrame with one row per candidate markup
        - Calculate `buyer_price = seller_price × (1 + markup_rate)` for each candidate
        - Use Conversion Probability Model to predict conversion probability for entire batch
    - **Optimization:** Batch processing improves performance over individual predictions
    - **Output:** Conversion probability for each markup candidate

- **Compute Reward Score:**
    - **Purpose:** Balance markup profitability against conversion likelihood using configurable penalty.
    - **Formula:** `reward_score = markup_rate × conversion_probability - penalty_factor × log(1 + markup_rate)`
    - **Components:**
        - **Revenue Component:** `markup_rate × conversion_probability` (expected markup return)
        - **Penalty Component:** `penalty_factor × log(1 + markup_rate)` (discourage excessive markups)
    - **Configuration:** `penalty_factor` in `MarkupFinderConfig` controls aggressiveness
    - **Output:** Reward score for each candidate markup

- **Calculate Expected Revenue:**
    - **Purpose:** Estimate actual monetary return for business decision-making.
    - **Formula:** `expected_revenue = quantity × (seller_price × markup_rate) × conversion_probability`
    - **Output:** Expected converted revenue for each candidate

- **Select Optimal Markup:**
    - **Purpose:** Choose the markup that maximizes the reward score.
    - **Method:** Find candidate with highest reward score across all options
    - **Output:** Single optimal markup rate with associated metrics

#### Response Generation

- **Suggestion Details:**
    - **Purpose:** Create detailed markup suggestion with all calculation data.
    - **Output:**
        - Optimal markup rate and conversion probability
        - Search space boundaries (min/max markup)
        - Expected revenue calculation
        - All candidate evaluations with scores

- **Return MarkupSuggestionResponse:**
    - **Purpose:** Provide structured response containing optimization results for all line items.
    - **Content:** List of `MarkupSuggestionDetails` objects, one per line item
    - **Format:** Structured response matching `MarkupSuggestionResponse` schema
    - **Transparency:** Includes complete calculation details for audit and analysis

---

## Reward Score Optimization

The Markup Finder uses a reward score to balance markup profitability against conversion likelihood:

**Reward Score Formula:**
`reward_score = markup_rate × conversion_probability - penalty_factor × log(1 + markup_rate)`

**Components:**

- **Revenue Component:** `markup_rate × conversion_probability` (expected markup return)
- **Penalty Component:** `penalty_factor × log(1 + markup_rate)` (discourage excessive markups)

**Behavior:**

- **Higher `penalty_factor`:** More conservative markup suggestions (lower markups preferred)
- **Lower `penalty_factor`:** More aggressive markup suggestions (higher markups allowed)

> See [Configuration Reference](../configuration.md) for all configurable parameters including `penalty_factor` and `search_space_size`.

---

## Implementation References

### Core Components and Key Methods
- **Main Class:** `MarkupFinder` in `src/gomat_markup_opt/inference/markup_suggestion.py` - Orchestrates the complete markup optimization pipeline
- **Markup Optimization:** `suggest_markup_with_details()` - Complete optimization pipeline for quote processing
- **Configuration:** `MarkupFinderConfig` in `src/gomat_markup_opt/config.py` - All configurable parameters

> **Related Documentation:**

> - [API Documentation](../api_documentation.md) - Complete API reference and usage examples
> - [Conversion Probability Model](../models/conversion_probability_model.md) - Training pipeline for conversion prediction
> - [Markup Space Optimizer](../models/markup_space_optimizer.md) - Training pipeline for markup interval estimation
> - [Model Evaluation](../evaluation/conversion_probability_model_evaluation.md) - Conversion model performance assessment
> - [Model Evaluation](../evaluation/markup_space_optimizer_evaluation.md) - Markup optimizer performance assessment
> - [Configuration Reference](../configuration.md) - All system configuration parameters

---
