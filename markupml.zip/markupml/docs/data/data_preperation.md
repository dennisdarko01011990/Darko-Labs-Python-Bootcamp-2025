# Data Preparation for MarkupML Models

This page describes the unified data preparation process used for both the [**Conversion Probability Model**](../models/conversion_probability_model.md) and the [**Markup Space Optimizer**](../models/markup_space_optimizer.md).
It covers the steps for collecting, merging, engineering, and cleaning the quote and order data to ensure high-quality input for

---

## Data Preparation Workflow

### 1. Load & Merge Data

- **Input Sources:**
    - [Raw quote and order data](./quote_and_order_data.md)
    - [Quote lost data (reasons for lost quotes)](./quote_lost_data.md)
- **Steps:**
    - Load datasets from source files or databases
    - Standardize and rename columns for consistency
    - Merge datasets into a unified DataFrame

---


### 2. Feature Engineering

- **Purpose:** Apply feature engineering steps to create all derived features required for modeling, in alignment with the codebase.
- **Steps:**
    1. **Create Target Variable (if applicable):**
        - If a target column is specified, create it based on the `status` column:
            - `Order Waiting for Pickup or Delivery`, `Order Complete`, `Planning Delivery` → 1 (converted)
            - `Quote Returned` → 0 (not converted)
        - Any rows with unmapped statuses are dropped.
        - The original `status` column is dropped after mapping.
    2. **Calculate Accepted Proportion:**
        - For each quote, compute the rolling conversion rate (`accepted_proportion`) for each `buyer_company_id` up to the current quote, based on the target variable.
        - This is calculated as the proportion of previously accepted quotes (cumulative sum of the target variable) divided by the number of previous quotes for that buyer. For the first quote, the value is set to 0.
    3. **Create Derived Features:**
        - `total_seller_price`: `quantity` × `seller_price`
        - `markup_rate`: (`buyer_price` – `seller_price`) / `seller_price`
        - `markup_amount`: `seller_price` × `markup_rate`
        - `total_markup_amount`: `quantity` × `markup_amount`

<!-- **Reference Implementation:** See `engineer_features` and `calculate_accepted_proportion` in [`src/gomat_markup_opt/preprocessing/feature_engineering.py`](../../src/gomat_markup_opt/preprocessing/feature_engineering.py). -->

---

### 3. Clean & Filter Data

- **Purpose:** Remove invalid, irrelevant, or outlier data to improve model quality.
- **Steps (in order):**
    1. **Remove rows with non-positive seller prices:**
        - Only keep rows where `seller_price` > 0.
    2. **Parse and validate order dates:**
        - Convert `order_date` to datetime; remove rows with invalid or missing dates.
    3. **Remove rows with missing delivery zip code:**
        - Only keep rows where `delivery_zip_code` is present.
    4. **Filter by date range:**
        - If `data_size_months` is provided, keep only records from the last N months (relative to today).
        - If `cutoff_date` is provided, keep only records with `order_date` after this date (YYYY-MM-DD).
        - If both are provided, `data_size_months` takes precedence.
    5. **Filter to include only specific buyer regions:**
        - Florida, Texas, New York, Georgia, South Carolina, California, Tennessee, Louisiana, North Carolina, Mississippi, Maryland, New Jersey, Kentucky
    6. **Filter lost quotes to relevant reasons:**
        - Only keep rows where `lost_reason` is either missing or in the following list:
            - Bad Fit Buyer - Not Competitive Pricing; Substitutions Not Approved
            - Bad Fit Buyer - Not Competitive Pricing
            - Good Fit Buyer - Not Competitive Pricing; Other
            - Good Fit Buyer - Not Competitive Pricing; Substitutions Not Approved
            - Good Fit Buyer - Not Competitive Pricing; Used their existing suppliers
            - Good Fit Buyer - Not Competitive Pricing
            - Other; Good Fit Buyer - Not Competitive Pricing
            - Other; Used their existing suppliers
            - Used their existing suppliers; Bad Fit Buyer - Not Competitive Pricing
            - Used their existing suppliers; Good Fit Buyer - Not Competitive Pricing
            - Used their existing suppliers; Other
            - Used their existing suppliers
            - Customer Lost Bid; Good Fit Buyer - Not Competitive Pricing
            - Pictures not approved; Good Fit Buyer - Not Competitive Pricing
            - Substitutions Not Approved; Bad Fit Buyer - Not Competitive Pricing
    7. **Remove outliers (if enough data):**
        - If the dataset has 1000 or more rows, remove rows with `markup_rate` outside the 5th–95th percentile range.
        - If fewer than 1000 rows, skip outlier removal.

---

## Outputs

- **Unified, cleaned, and feature-engineered dataset** ready for use in both the Conversion Probability Model and Markup Space Optimizer pipelines.

---

## References

- [Conversion Probability Model Data Preparation](../models/conversion_probability_model.md)
- [Markup Space Optimizer Data Preparation](../models/markup_space_optimizer.md)


---
> **Configuration Reference:**
> For a complete list of all configurable parameters (including history_cutoff_date), see [Configuration ⚙️](../configuration.md).
---
