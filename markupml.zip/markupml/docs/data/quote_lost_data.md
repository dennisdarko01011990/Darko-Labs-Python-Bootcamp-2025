# Quote Lost Data

This document describes the Quote Lost Data used in the Gomat Markup Optimization project, including its structure, key columns, and role in the modeling process.

## Overview

Quote Lost Data contains information about quotes that were lost, including reasons for the loss. This data is crucial for understanding why certain quotes did not convert into orders and is used to enhance the training dataset for the Conversion Probability Model.

## Data Source

The data is typically loaded from CSV files named in the pattern `Quote Lost Export-*.csv`, for example, `Quote Lost Export-JUL 072025.csv`.

## Key Columns

| Mapped Column Name      | Raw Data Column Name         | Description                                      |
|------------------------|-----------------------------|--------------------------------------------------|
| `record_id`            | `Record ID`                 | Unique record identifier                         |
| `deal_name`            | `Deal Name`                 | Name of the deal                                 |
| `order_number`         | `Quote/Order #`             | Identifier linking the lost quote to the main dataset |
| `lost_reason`          | `Quote Lost Reason`         | The reason why the quote was lost                |
| `lost_reason_comment`  | `Quote Lost Reason Comment` | Additional comments on the lost reason           |
| `deal_stage`           | `Deal Stage`                | Stage of the deal                                |
| `region`               | `State/Region`              | Geographical region                              |

### Relevant Lost Reasons

- "Bad Fit Buyer - Not Competitive Pricing; Substitutions Not Approved"
- "Bad Fit Buyer - Not Competitive Pricing"
- "Good Fit Buyer - Not Competitive Pricing; Other"
- "Good Fit Buyer - Not Competitive Pricing; Substitutions Not Approved"
- "Good Fit Buyer - Not Competitive Pricing; Used their existing suppliers"
- "Good Fit Buyer - Not Competitive Pricing"
- "Other; Good Fit Buyer - Not Competitive Pricing"
- "Other; Used their existing suppliers"
- "Used their existing suppliers; Bad Fit Buyer - Not Competitive Pricing"
- "Used their existing suppliers; Good Fit Buyer - Not Competitive Pricing"
- "Used their existing suppliers; Other"
- "Used their existing suppliers"
- "Customer Lost Bid; Good Fit Buyer - Not Competitive Pricing"
- "Pictures not approved; Good Fit Buyer - Not Competitive Pricing"
- "Substitutions Not Approved; Bad Fit Buyer - Not Competitive Pricing"

## Role in Modeling

The Quote Lost Data is merged with the main quote/order data to provide additional context on lost opportunities. This merged dataset forms the master data used for training the Conversion Probability Model.

For more details, refer to the data loading and preparation scripts in `src/gomat_markup_opt/data/preparation.py`.
