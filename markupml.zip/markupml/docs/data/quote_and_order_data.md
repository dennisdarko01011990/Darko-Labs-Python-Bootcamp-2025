# Quote and Order Data

This document describes the Quote and Order Data used in the Gomat Markup Optimization project, including its structure, key columns, and role in the modeling process.

## Overview

Quote and Order Data contains detailed information about sales quotes and orders at the line item level. This data is the primary source for training the Conversion Probability Model and other components.

## Data Source

The data is typically loaded from CSV files named in the pattern `Quote_and_Order_Data_*.csv`, for example, `Quote_and_Order_Data_20250708.csv`.

## Key Columns

| Mapped Column Name         | Raw Data Column Name           | Description                                 |
|---------------------------|-------------------------------|---------------------------------------------|
| `item_id`                 | `item_id`                      | Unique identifier for the line item         |
| `type`                    | `Type`                         | Type of the record (quote/order)            |
| `request_purpose`         | `Request_Purpose`              | Purpose of the request                      |
| `qto`                     | `qto`                          | Quantity take-off indicator                 |
| `order_number`            | `Quote_Order_Number`           | Unique identifier for the quote/order       |
| `category_id`             | `category_id`                  | Category identifier                         |
| `plant_category`          | `Plant_Category`               | Category of the plant or product            |
| `product_id`              | `product_id`                   | Product identifier                          |
| `latin_name`              | `Latin_Name`                   | Latin name of the product                   |
| `common_name`             | `Common_Name`                  | Common name of the product                  |
| `product_size_id`         | `product_size_id`              | Product size identifier                     |
| `size`                    | `Size`                         | Size of the product                         |
| `product_spec_id`         | `product_spec_id`              | Product specification identifier            |
| `specs`                   | `Specs`                        | Product specifications                      |
| `quantity`                | `QTY`                          | Number of units quoted                      |
| `seller_price`            | `Seller_Price`                 | Price offered by the seller                 |
| `buyer_price`             | `Buyer_Price`                  | Price expected or offered by the buyer      |
| `seller_company_id`       | `seller_company_id`            | Seller company identifier                   |
| `supplier_name`           | `Supplier_Name`                | Name of the supplier                        |
| `buyer_company_id`        | `buyer_company_id`             | Buyer company identifier                    |
| `buyer_name`              | `Buyer_Name`                   | Name of the buyer                           |
| `delivery_address`        | `Delivery_Address`             | Delivery address                            |
| `delivery_address_region` | `Delivery_Address_Region`      | Delivery address region                     |
| `delivery_zip_code`       | `Delivery_Address_Zip_Code`    | Delivery address zip code                   |
| `buyer_region`            | `Buyer_Company_Region`         | Geographical region of the buyer            |
| `supplier_address`        | `Supplier_Address`             | Supplier address                            |
| `supplier_zip_code`       | `Supplier_Zip_Code`            | Supplier zip code                           |
| `status`                  | `Quote_Order_Status`           | Status of the quote/order                   |
| `last_publish_date`       | `Quote_Order_Last_Publish_Date`| Last publish date of the quote/order        |
| `last_publish_month`      | `Quote_Order_Last_Publish_Month`| Last publish month of the quote/order     |
| `last_publish_year`       | `Quote_Order_Last_Publish_Year`| Last publish year of the quote/order        |
| `order_date`              | `Quote_Order_Created_Date`     | Creation date of the quote/order            |
| `order_date_month`        | `Quote_Order_Created_Month`    | Creation month of the quote/order           |
| `order_date_year`         | `Quote_Order_Created_Year`     | Creation year of the quote/order            |
| `approx_job_date`         | `approx_job_date`              | Approximate job date                        |
| `delivery_date`           | `Delivery_Date_orders`         | Delivery date for orders                    |
| `timeline`                | `Timeline`                     | Timeline for the order/quote                |
| `timeline_month`          | `Timeline_Month`               | Timeline month                              |
| `timeline_year`           | `Timeline_Year`                | Timeline year                               |
| `delivery_method`         | `Delivery_method`              | Delivery method                             |

## Role in Modeling

This dataset is used as the master data for training the Conversion Probability Model and the Markup Space Optimizer. It is cleaned, filtered, and augmented before being used in model training.

For more details, refer to the data loading and preparation scripts in `src/gomat_markup_opt/data/preparation.py`.
