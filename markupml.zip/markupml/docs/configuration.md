# Configuration ⚙️

This project uses [Pydantic](https://docs.pydantic.dev/) for robust configuration management.
All configuration classes are defined in [`src/gomat_markup_opt/config.py`](../src/gomat_markup_opt/config.py).
Settings are loaded in the following order of precedence:

1. Command-line arguments (where applicable)
2. Environment variables (e.g., `GOMAT_RANDOM_STATE`)
3. Values from a `.env` file in the project root
4. Default values defined in the settings classes

---

## Configuration Classes

### 1. `ConversionModelTrainingSettings`
Settings for training the Conversion Probability Model.

| Variable                       | Type                | Default         | Description                                                                 |
|--------------------------------|---------------------|-----------------|-----------------------------------------------------------------------------|
| `test_size`                    | `int`               | `1`             | Months of data for testing (from end of dataset)                            |
| `monotonic_cst`                | `dict[str, int]`    | `{"markup_rate": -1, "accepted_proportion": 1}` | Monotonic constraints for model features                                    |
| `classifier_params`            | `dict[str, Any]`    | `{}`            | Parameters for classifier initialization                                    |
| `undersample_ratio`            | `float`             | `2.0`           | Ratio of negative to positive samples after balancing                       |
| `augment_high_markup_threshold`| `float`             | `0.5`           | Markup threshold for "accepted high markups"                                |
| `augment_low_markup_threshold` | `float`             | `0.20`          | Markup threshold for "rejected low markups"                                 |
| `augment_high_markup_interval` | `tuple[float, float]`| `(0.60, 0.80)`  | Range for synthetic "rejected low" markups                                  |
| `augment_low_markup_interval`  | `tuple[float, float]`| `(0.20, 0.30)`  | Range for synthetic "accepted high" markups                                 |
| `augment_sampling_percentage`  | `float`             | `0.0`           | Percentage of samples to generate for augmentation                          |
| `history_cutoff_date`          | `date`              | `2022-11-01`    | Cutoff date for historical training data                                    |
| `random_state`                 | `int \| None`       | `None`          | Random state for reproducibility                                            |
| `evaluate_model_performance`   | `bool`              | `True`          | Evaluate model performance after training                                   |

---

### 2. `MarkupSpaceOptimizerSettings`
Settings for training the Markup Space Optimizer.

| Variable              | Type                | Default         | Description                                      |
|-----------------------|---------------------|-----------------|--------------------------------------------------|
| `default_range`       | `tuple[float, float]`| `(0.3, 0.36)`   | Default markup range for optimizer                |
| `quantile_low`        | `float`             | `0.1`           | Lower quantile for markup range                   |
| `quantile_high`       | `float`             | `0.9`           | Upper quantile for markup range                   |
| `min_markup`          | `float`             | `0.11`          | Minimum allowable markup                          |
| `max_markup`          | `float`             | `0.8`           | Maximum allowable markup                          |
| `minimum_range_size`  | `float \| None`     | `0.06`          | Minimum size of markup range                      |
| `data_size_months`    | `int`               | `24`            | Months of historical data for training            |
| `evaluate_model_performance` | `bool`        | `True`          | Evaluate model performance after training         |

---

### 3. `MarkupFinderConfig`
Settings for markup suggestion logic.

| Variable                  | Type      | Default   | Description                                                        |
|---------------------------|-----------|-----------|--------------------------------------------------------------------|
| `search_space_size`       | `int`     | `100`     | Number of points in markup search space                            |
| `conversion_model_version`| `str`     | `latest`  | Registered version of conversion model to use                      |
| `markup_space_model_version`| `str`   | `latest`  | Registered version of markup model to use                          |
| `penalty_factor`          | `float`   | `0.0`     | Factor to adjust greediness of markup suggestion (higher = safer)  |

---

### 4. `AnalysisConfig`
Settings for the analysis module.

| Variable                  | Type      | Default   | Description                                                        |
|---------------------------|-----------|-----------|--------------------------------------------------------------------|
| `test_size`               | `int`     | `1`       | Months of data to use (from end of dataset)                        |
| `sample_fraction`         | `float \| None` | `1`   | Fraction of data to sample for analysis                            |
| `search_space_size`       | `int`     | `10`      | Number of points in markup search space                            |
| `conversion_model_version`| `str`     | `latest`  | Registered version of conversion model to use                      |
| `markup_space_model_version`| `str`   | `latest`  | Registered version of markup model to use                          |
| `random_state`            | `int \| None` | `None` | Random state for reproducibility                                   |

---

### 5. `InferenceAPISettings`
Settings for the Inference API.

| Variable   | Type  | Default | Description                      |
|------------|-------|---------|----------------------------------|
| `port`     | `int` | `8000`  | Port to run the inference API on |

---

## How to Use

- All configuration classes inherit from `BaseSettings` and support environment variable overrides.
- You can set values via CLI, environment variables, or `.env` files.
- For full details, see [`src/gomat_markup_opt/config.py`](../src/gomat_markup_opt/config.py).

---

**Tip:**
Use environment variables with the prefix `GOMAT_` (e.g., `GOMAT_TEST_SIZE`) to override defaults
