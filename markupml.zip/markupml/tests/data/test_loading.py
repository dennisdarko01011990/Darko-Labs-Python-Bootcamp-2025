import os

import pandas as pd
import pytest

from gomat_markup_opt.data import loading

DUMMY_CSV_CONTENT = "col1,col2\n1,a\n2,b"
TARGET_CSV_CONTENT = "col1,col2,col3\n1,a,x\n2,b,x\n3,c,x"


@pytest.fixture(autouse=True)
def data_dir(tmp_path_factory):
    # Create a temporary directory for the test files. Cleanup happens automatically
    # when the fixture goes out of scope
    tmpdir = tmp_path_factory.mktemp("data")
    os.environ["DATA_DIR"] = str(tmpdir)
    yield tmpdir


def create_file(file_path, target=False):
    """Helper function to create a file with the given content."""
    with open(file_path, "w") as f:
        if target:
            f.write(TARGET_CSV_CONTENT)
        else:
            f.write(DUMMY_CSV_CONTENT)


def is_target(loaded):
    """Check if the loaded file is the target file."""
    assert isinstance(loaded, pd.DataFrame)
    assert len(loaded.columns) == 3
    return True


def test_load_inventory_data_loads_latest(data_dir):
    create_file(data_dir / "GoMaterials_Historical_Inventory_20230101.csv")
    create_file(data_dir / "GoMaterials_Historical_Inventory_20230102.csv")
    create_file(data_dir / "GoMaterials_Historical_Inventory_20230103.csv", target=True)

    result = loading.load_inventory_data()

    assert is_target(result)


def test_load_inventory_data_loads_specific_date(data_dir):
    specific_date = "20230101"
    create_file(data_dir / f"GoMaterials_Historical_Inventory_{specific_date}.csv", target=True)

    create_file(data_dir / "GoMaterials_Historical_Inventory_20221231.csv")
    create_file(data_dir / "GoMaterials_Historical_Inventory_20230102.csv")

    result = loading.load_inventory_data(date_str=specific_date)
    assert is_target(result)


def test_load_supplier_zip_data_loads_correct_file(data_dir):
    file_path = data_dir / "supplier_name_zip_code.csv"
    create_file(file_path, target=True)

    result = loading.load_supplier_zip_data()

    assert is_target(result)


def test_load_supplier_zip_data_raises_error_if_file_missing(data_dir):
    file_path = data_dir / "supplier_name_zip_code.csv"
    assert not file_path.exists()
    with pytest.raises(FileNotFoundError, match="Supplier zip code data file not found"):
        loading.load_supplier_zip_data()


def test_load_quote_order_data_loads_latest(data_dir):
    create_file(data_dir / "Quote_and_Order_Data_2023_01_01.csv")
    create_file(data_dir / "Quote_and_Order_Data_2023_01_02.csv")
    create_file(data_dir / "Quote_and_Order_Data_2023_01_03.csv", target=True)

    result = loading.load_quote_order_data()

    assert is_target(result)


def test_load_quote_order_data_loads_specific_date(data_dir):
    specific_date = "2023_01_01"
    create_file(data_dir / f"Quote_and_Order_Data_{specific_date}.csv", target=True)

    create_file(data_dir / "Quote_and_Order_Data_2022_12_31.csv")
    create_file(data_dir / "Quote_and_Order_Data_2023_01_02.csv")

    result = loading.load_quote_order_data(date_str=specific_date)
    assert is_target(result)


def test_load_quote_lost_export_loads_latest(data_dir):
    create_file(data_dir / "Quote Lost Export-20230101.csv")
    create_file(data_dir / "Quote Lost Export-20230102.csv")
    create_file(data_dir / "Quote Lost Export-20230103.csv", target=True)

    result = loading.load_quote_lost_export()

    assert is_target(result)


def test_load_quote_lost_export_loads_specific_date(data_dir):
    specific_date = "20230101"
    create_file(data_dir / f"Quote Lost Export-{specific_date}.csv", target=True)

    create_file(data_dir / "Quote Lost Export-20221231.csv")
    create_file(data_dir / "Quote Lost Export-20230102.csv")

    result = loading.load_quote_lost_export(date_str=specific_date)
    assert is_target(result)


def test_load_data_raises_error_for_missing_specific_date(data_dir):
    """Verify load_data raises FileNotFoundError for a missing specific date file."""
    specific_date = "20240101"
    pattern_latest = "Test_Data_*.csv"
    pattern_specific = "Test_Data_{date_str}.csv"
    data_type_name = "Test Data"
    specific_filename = pattern_specific.format(date_str=specific_date)

    # Ensure the specific file does not exist
    assert not (data_dir / specific_filename).exists()
    # Create some other files to ensure it doesn't accidentally load latest
    create_file(data_dir / "Test_Data_20231231.csv")

    with pytest.raises(FileNotFoundError, match=f"{data_type_name} for date {specific_date} not found"):
        loading.load_data(
            pattern_latest=pattern_latest,
            pattern_specific_format=pattern_specific,
            date_str=specific_date,
            data_type_name=data_type_name,
        )


def test_load_data_raises_error_if_no_files_exist_for_latest(data_dir):
    """Verify load_data raises FileNotFoundError when loading latest and no files match."""
    pattern_latest = "NonExistent_Data_*.csv"
    pattern_specific = "NonExistent_Data_{date_str}.csv"
    data_type_name = "NonExistent Data"

    # Ensure no files match the pattern
    assert not list(data_dir.glob(pattern_latest))

    with pytest.raises(FileNotFoundError, match="No files matching pattern"):
        loading.load_data(
            pattern_latest=pattern_latest,
            pattern_specific_format=pattern_specific,
            date_str=None,  # Requesting latest
            data_type_name=data_type_name,
        )


def test_load_data_raises_value_error_if_date_str_but_no_specific_pattern(data_dir):
    """Verify load_data raises ValueError if date loading is attempted but not supported."""
    pattern_latest = "Some_Data_*.csv"
    data_type_name = "Unsupported Date Data"
    date_str = "20240101"

    with pytest.raises(ValueError, match=f"Specific date loading not supported for {data_type_name}"):
        loading.load_data(
            pattern_latest=pattern_latest,
            pattern_specific_format=None,  # Indicate specific date loading is not supported
            date_str=date_str,
            data_type_name=data_type_name,
        )
