import numpy as np
import pandas as pd

from gomat_markup_opt.preprocessing.feature_engineering import engineer_features


def make_quote_df(
    statuses=None, buyer_prices=None, seller_prices=None, quantities=None, buyer_company_ids=None, order_dates=None
):
    n = len(statuses)
    return pd.DataFrame(
        {
            "status": statuses or ["Order Complete"] * n,
            "buyer_price": buyer_prices or [100.0] * n,
            "seller_price": seller_prices or [80.0] * n,
            "quantity": quantities or [2] * n,
            "buyer_company_id": buyer_company_ids or [1] * n,
            "order_date": order_dates or pd.date_range("2024-01-01", periods=n),
        }
    )


def test_engineered_features():
    df = make_quote_df(
        statuses=["Order Complete", "Quote Returned", "Planning Delivery", "Order Waiting for Pickup or Delivery"],
        buyer_prices=[110, 110, 110, 110],
        seller_prices=[100, 100, 100, 100],
        quantities=[1, 2, 3, 4],
        buyer_company_ids=[1, 1, 2, 2],
        order_dates=["2024-01-01", "2024-01-02", "2024-01-01", "2024-01-02"],
    )
    result = engineer_features(df, target_column="target")

    assert "target" in result.columns
    assert set(result["target"]) == {0, 1}
    assert "accepted_proportion" in result.columns
    assert "total_seller_price" in result.columns
    assert "markup_rate" in result.columns
    assert np.allclose(result["total_seller_price"], [100, 200, 300, 400])
    assert np.allclose(result["markup_rate"], (result["buyer_price"] - result["seller_price"]) / result["seller_price"])
    assert "status" not in result.columns


def test_target_column_none():
    df = make_quote_df(statuses=["Order Complete"] * 10)
    result = engineer_features(df, target_column=None)
    assert "target" not in result.columns
    assert "accepted_proportion" not in result.columns


def test_unmapped_status_removed():
    df = make_quote_df(order_dates=["2024-01-01", "2024-01-02"], statuses=["Order Complete", "Unknown Status"])
    result = engineer_features(df, target_column="target")
    assert result.shape[0] == 1
    assert "2024-01-02" not in result["order_date"].values
