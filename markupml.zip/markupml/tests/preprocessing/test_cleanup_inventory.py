import pandas as pd

from gomat_markup_opt.preprocessing.cleanup import cleanup_and_filter_inventory_data


def test_cleanup_inventory_removes_ontario_quebec():
    df = pd.DataFrame({"supplier_region": ["Ontario", "Quebec", "Florida"], "price": [10, 20, 30]})
    result = cleanup_and_filter_inventory_data(df)
    assert set(result["supplier_region"]) == {"Florida"}


def test_cleanup_inventory_removes_non_numeric_price():
    df = pd.DataFrame({"supplier_region": ["Florida", "Florida"], "price": [10, "Call for Price"]})
    result = cleanup_and_filter_inventory_data(df)
    assert result["price"].dtype.kind in "fi"  # Float or integer
    assert len(result) == 1


def test_cleanup_inventory_removes_zero_or_negative_price():
    df = pd.DataFrame({"supplier_region": ["Florida", "Florida", "Florida"], "price": [10, 0, -5]})
    result = cleanup_and_filter_inventory_data(df)
    assert (result["price"] > 0).all()
    assert len(result) == 1
