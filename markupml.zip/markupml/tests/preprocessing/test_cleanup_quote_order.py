import pandas as pd

from gomat_markup_opt.preprocessing.cleanup import cleanup_and_filter_quote_and_order_data


def test_cleanup_removes_zero_seller_price():
    df = pd.DataFrame(
        {
            "order_number": [1, 2],
            "seller_price": [0, 10],
            "order_date": ["2023-01-01", "2023-01-01"],
            "status": ["Order Complete", "Order Complete"],
            "buyer_region": ["Florida", "Florida"],
            "delivery_zip_code": ["12345", "12346"],
            "lost_reason": [None, None],
            "markup_rate": [0.1, 0.2],
        }
    )
    result = cleanup_and_filter_quote_and_order_data(df)
    assert (result["seller_price"] > 0).all()


def test_cleanup_filters_older_order_date():
    df = pd.DataFrame(
        {
            "order_number": [1, 2],
            "seller_price": [10, 10],
            "order_date": ["2022-10-01", "2023-01-01"],
            "status": ["Order Complete", "Order Complete"],
            "buyer_region": ["Florida", "Florida"],
            "delivery_zip_code": ["12345", "12346"],
            "lost_reason": [None, None],
            "markup_rate": [0.1, 0.2],
        }
    )
    result = cleanup_and_filter_quote_and_order_data(df, cutoff_date="2022-11-01")
    assert result.shape[0] == 1
    assert (result["order_date"] > "2022-11-01").all()


def test_cleanup_filters_last_n_months():
    yesterday = (pd.Timestamp.today() - pd.DateOffset(days=1)).strftime("%Y-%m-%d")
    two_months_ago = (pd.Timestamp.today() - pd.DateOffset(months=2)).strftime("%Y-%m-%d")
    df = pd.DataFrame(
        {
            "order_number": [1, 2, 3, 4],
            "seller_price": [10, 10, 10, 10],
            "order_date": ["2022-10-01", "2023-01-01", yesterday, two_months_ago],
            "status": ["Order Complete", "Order Complete", "Order Complete", "Order Complete"],
            "buyer_region": ["Florida", "Florida", "Florida", "Florida"],
            "delivery_zip_code": ["12345", "12346", "12347", "12348"],
            "lost_reason": [None, None, None, None],
            "markup_rate": [0.1, 0.2, 0.3, 0.4],
        }
    )
    result = cleanup_and_filter_quote_and_order_data(df, data_size_months=1)
    assert result.shape[0] == 1
    assert (result["order_date"] > (pd.Timestamp.today() - pd.DateOffset(months=1))).all()


def test_cleanup_filters_buyer_region():
    df = pd.DataFrame(
        {
            "order_number": [1, 2, 3, 4],
            "seller_price": [10, 10, 10, 10],
            "order_date": ["2023-01-01", "2023-01-01", "2023-01-01", "2023-01-01"],
            "status": ["Order Complete", "Order Complete", "Order Complete", "Order Complete"],
            "buyer_region": ["Florida", "Ontario", "Alaska", "Unknown region"],
            "delivery_zip_code": ["12345", "12346", "12347", "12348"],
            "lost_reason": [None, None, None, None],
            "markup_rate": [0.1, 0.2, 0.3, 0.4],
        }
    )
    result = cleanup_and_filter_quote_and_order_data(df)
    assert set(result["buyer_region"]) == {"Florida"}


def test_cleanup_removes_unwanted_lost_reasons():
    df = pd.DataFrame(
        {
            "order_number": [1, 2],
            "seller_price": [10, 10],
            "order_date": ["2023-01-01", "2023-01-01"],
            "status": ["Order Complete", "Order Complete"],
            "buyer_region": ["Florida", "Florida"],
            "delivery_zip_code": ["12345", "12346"],
            "lost_reason": ["Bad Fit Buyer - Not Competitive Pricing", "bad reason"],
            "markup_rate": [0.1, 0.2],
        }
    )
    result = cleanup_and_filter_quote_and_order_data(df)
    assert "lost_reason" in result.columns
    assert result.shape[0] == 1
    assert result.iloc[0]["order_number"] == 1
    assert result.iloc[0]["lost_reason"] == "Bad Fit Buyer - Not Competitive Pricing"


def test_cleanup_removes_nan_zip_code():
    df = pd.DataFrame(
        {
            "order_number": [1, 2, 3],
            "seller_price": [10, 10, 10],
            "order_date": ["2023-01-01", "2023-01-01", "2023-01-01"],
            "status": ["Order Complete", "Order Complete", "Order Complete"],
            "buyer_region": ["Florida", "Florida", "Florida"],
            "delivery_zip_code": ["12345", None, "12347"],
            "lost_reason": [None, None, None],
            "markup_rate": [0.1, 0.2, 0.3],
        }
    )
    result = cleanup_and_filter_quote_and_order_data(df)
    assert result.shape[0] == 2
    assert result["delivery_zip_code"].isnull().sum() == 0


def test_cleanup_removes_outliers_in_markup_rate_if_enough_data():
    nb_rows = 1000
    # 50 near-zero markups, 50 near-1 markups, rest uniformly distributed
    markups = [0.01] * 50 + [0.99] * 50 + list(pd.Series([0.1, 0.2, 0.3, 0.4, 0.5]).sample(nb_rows - 100, replace=True))
    df = pd.DataFrame(
        {
            "order_number": range(nb_rows),
            "seller_price": [10] * nb_rows,
            "order_date": ["2023-01-01"] * nb_rows,
            "status": ["Order Complete"] * nb_rows,
            "buyer_region": ["Florida"] * nb_rows,
            "delivery_zip_code": ["12345"] * nb_rows,
            "lost_reason": [None] * nb_rows,
            "markup_rate": markups,
        }
    )
    result = cleanup_and_filter_quote_and_order_data(df)
    # Check that the outliers were removed
    assert result.shape[0] < nb_rows
    assert result["markup_rate"].quantile(0.05) > 0.01
    assert result["markup_rate"].quantile(0.95) < 0.99
