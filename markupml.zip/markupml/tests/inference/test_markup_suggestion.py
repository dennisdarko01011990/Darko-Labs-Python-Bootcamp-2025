from unittest.mock import MagicMock

import numpy as np
import pandas as pd
import pytest

from gomat_markup_opt.config import MarkupFinderConfig
from gomat_markup_opt.inference.markup_suggestion import MarkupFinder
from gomat_markup_opt.inference.schemas import MarkupSuggestionDetails

# Number of markups in the search space and mocked model outputs
NUM_MARKUPS = 5

class DummyItem:
    def __init__(self, item_id, product_id, product_size_id, seller_price, quantity, plant_category):
        self.item_id = item_id
        self.product_id = product_id
        self.product_size_id = product_size_id
        self.seller_price = seller_price
        self.quantity = quantity
        self.plant_category = plant_category

class DummyQuote:
    def __init__(self):
        self.qto = True
        self.request_purpose = "test"
        self.buyer_region = "region"
        self.buyer_company_id = 1
        self.line_items = [
            DummyItem(
                item_id="1",
                product_id=101,
                product_size_id=5,
                seller_price=100.0,
                quantity=2,
                plant_category="A"
            )
        ]

def get_mocked_models():
    dummy_conversion_model = MagicMock()
    # Generate decreasing values for class 1 probability
    # For example: [1.0, 0.8, 0.6, 0.4, 0.2] for NUM_MARKUPS=5
    class1_probs = np.linspace(1.0, 1.0 / NUM_MARKUPS, NUM_MARKUPS)
    class0_probs = 1.0 - class1_probs
    predict_proba_vals = np.stack([class0_probs, class1_probs], axis=1)
    dummy_conversion_model.predict_proba.return_value = predict_proba_vals
    dummy_markup_space_model = MagicMock()
    dummy_markup_space_model.predict.return_value = pd.DataFrame({"low": [0.2], "high": [0.5]})
    return dummy_conversion_model, dummy_markup_space_model

@pytest.fixture
def patch_models(monkeypatch):
    dummy_conversion_model, dummy_markup_space_model = get_mocked_models()
    load_model_mock = MagicMock(side_effect=[dummy_conversion_model, dummy_markup_space_model])
    monkeypatch.setattr("mlflow.sklearn.load_model", load_model_mock)
    return load_model_mock

@pytest.fixture
def markup_finder(patch_models):
    config = MarkupFinderConfig(
        search_space_size=NUM_MARKUPS
        )
    return MarkupFinder(config)

@pytest.fixture
def quote_fixture():
    return DummyQuote()

@pytest.fixture
def finder_penalty_low(monkeypatch, quote_fixture):
    dummy_conversion_model, dummy_markup_space_model = get_mocked_models()
    monkeypatch.setattr(
        "mlflow.sklearn.load_model", 
        MagicMock(side_effect=[dummy_conversion_model, dummy_markup_space_model])
        )
    config = MarkupFinderConfig(
        search_space_size=NUM_MARKUPS,
        penalty_factor=0.0,
    )
    return MarkupFinder(config)

@pytest.fixture
def finder_penalty_high(monkeypatch, quote_fixture):
    dummy_conversion_model, dummy_markup_space_model = get_mocked_models()
    monkeypatch.setattr(
        "mlflow.sklearn.load_model", 
        MagicMock(side_effect=[dummy_conversion_model, dummy_markup_space_model])
        )
    config = MarkupFinderConfig(
        search_space_size=NUM_MARKUPS,
        penalty_factor=5.0,
    )
    return MarkupFinder(config)

def test_suggest_markup_with_details_returns_list(markup_finder, quote_fixture):
    """Test that suggest_markup_with_details returns a list of results with the expected length."""
    results = markup_finder.suggest_markup_with_details(quote_fixture)
    assert isinstance(results, list)
    assert len(results) == 1

def test_markup_suggestion_details_fields(markup_finder, quote_fixture):
    """Test that the MarkupSuggestionDetails fields are correct and calculations length matches NUM_MARKUPS."""
    details = markup_finder.suggest_markup_with_details(quote_fixture)[0]
    assert isinstance(details, MarkupSuggestionDetails)
    assert details.min_markup_rate == 0.2
    assert details.max_markup_rate == 0.5
    assert len(details.calculations) == NUM_MARKUPS

def test_penalty_factor_affects_suggested_markup(finder_penalty_low, finder_penalty_high, quote_fixture):
    """Test that a higher penalty_factor lowers the suggested markup value."""
    details_low = finder_penalty_low.suggest_markup_with_details(quote_fixture)[0]
    details_high = finder_penalty_high.suggest_markup_with_details(quote_fixture)[0]
    assert details_high.suggested_markup_rate <= details_low.suggested_markup_rate
