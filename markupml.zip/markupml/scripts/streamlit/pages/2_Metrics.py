import streamlit as st
import mlflow
import pandas as pd
from mlflow.exceptions import MlflowException

MLFLOW_MODEL_NAME = "conversion-probability-model"
MLFLOW_MODEL_URI = f"models:/{MLFLOW_MODEL_NAME}/latest"

st.title("📊 Model Metrics & Artifacts")

try:
    latest_model = mlflow.search_runs(order_by=["start_time DESC"], max_results=1)
    selected_run_id = latest_model.iloc[0]["run_id"] if not latest_model.empty else None

    if selected_run_id:
        st.divider()
        st.subheader(f"Details for Run: `{selected_run_id}`")

        try:
            run_data = mlflow.get_run(selected_run_id)

            # --- Display Parameters ---
            st.write("**Parameters:**")
            if run_data.data.params:
                params_df = pd.DataFrame.from_dict(run_data.data.params, orient="index", columns=["Value"])
                st.dataframe(params_df)
            else:
                st.write("No parameters logged for this run.")

            # --- Display Metrics ---
            st.write("**Metrics:**")
            if run_data.data.metrics:
                metrics_df = pd.DataFrame.from_dict(run_data.data.metrics, orient="index", columns=["Value"])
                st.dataframe(metrics_df)
            else:
                st.write("No metrics logged for this run.")

            # --- Display Artifacts ---
            with st.expander("**Artifacts:**", expanded=False):
                try:
                    artifact_uri = run_data.info.artifact_uri + "/evaluation_plots"
                    st.image(
                        mlflow.artifacts.load_image(artifact_uri + "/calibration_curve.png"),
                        caption="Calibration Curve",
                        use_container_width=True,
                    )

                    st.image(
                        mlflow.artifacts.load_image(artifact_uri + "/precision_recall_curve.png"),
                        caption="ROC Curve",
                        use_container_width=True,
                    )

                except MlflowException as artifact_e:
                    st.error(
                        f"Could not list artifacts for run {selected_run_id}. Artifact URI might be inaccessible or invalid: {artifact_e}"
                    )
                except Exception as artifact_e:
                    st.error(f"An error occurred while listing artifacts for run {selected_run_id}: {artifact_e}")

            # --- Display buyer accepted proportion ---
            with st.expander("**Buyer Accepted Proportion:**", expanded=False):
                try:
                    buyer_conversion_dict = mlflow.artifacts.load_dict(
                        run_data.info.artifact_uri + "/accepted_proportion_by_buyer.json"
                    )
                    buyer_conversion_df = pd.DataFrame.from_dict(
                        buyer_conversion_dict, orient="index", columns=["accepted_proportion"]
                    )
                    buyer_conversion_df.reset_index(inplace=True)
                    buyer_conversion_df.rename(columns={"index": "buyer_company_id"}, inplace=True)
                    st.dataframe(buyer_conversion_df)
                except FileNotFoundError:
                    st.error("Buyer accepted proportion file not found in artifacts.")
                except Exception as e:
                    st.error(f"An error occurred while loadin buyer acceptedproportion data: {e}")

        except MlflowException as e:
            st.error(f"Error fetching details for run {selected_run_id} from MLflow: {e}")
        except Exception as e:
            st.error(f"An unexpected error occurred while fetching run details: {e}")

except MlflowException as e:
    st.error(f"Error connecting to or interacting with MLflow: {e}")
    st.info(
        "Ensure the MLflow tracking server is running and accessible, or that the local `mlruns` directory is correctly configured."
    )
except Exception as e:
    st.error(f"An unexpected error occurred: {e}")
