import streamlit as st
import pandas as pd
import numpy as np
import mlflow

from gomat_markup_opt.logging_config import setup_logging

# Constants from demo script
MLFLOW_MODEL_NAME = "conversion-probability-model"
MLFLOW_MODEL_URI = f"models:/{MLFLOW_MODEL_NAME}/latest"
MIN_MARKUP = 0.0
MAX_MARKUP = 100.0
NUMBER_OF_PREDICTIONS = 20

setup_logging()

st.title("🔍 Model Inference")

st.sidebar.header("⚙️ Inference Configuration")

# --- Inference Configuration ---
inf_quantity = st.sidebar.number_input("Quantity", value=1, min_value=1)
inf_seller_total = st.sidebar.number_input("Seller Total ($)", value=50.0, min_value=0.0, step=1.0)
inf_plant_category = st.sidebar.selectbox(
    "Plant Category", ["Trees", "Shrubs", "Flowers", "Other"], index=0
)  # Example categories
inf_buyer_region = st.sidebar.selectbox(
    "Buyer Region", ["Florida", "California", "Texas", "New York", "Other"], index=0
)  # Example regions
inf_qto = st.sidebar.selectbox("QTO", ["Yes", "No"], index=1)
inf_markup_range = st.sidebar.slider("Markup Range (%) for Plot", MIN_MARKUP, MAX_MARKUP, (MIN_MARKUP, MAX_MARKUP), 1.0)
inf_num_points = st.sidebar.slider("Number of Points for Plot", 10, 100, NUMBER_OF_PREDICTIONS, 5)
inf_accepted_proportion = st.sidebar.number_input(
    "Buyer Accepted Proportion (%)",
    value=50.0,
    min_value=0.0,
    max_value=100.0,
    step=1.0,
    help="Percentage of buyers who accepted the quote.",
)
inf_request_purpose = st.sidebar.selectbox("Request Purpose", ["For Install", "For Bid"], index=0)


# --- Inference Execution ---
st.divider()
st.header("Inference Results")


# Load model function (cached for efficiency)
@st.cache_resource
def load_model(model_uri):
    try:
        # Add a message while loading
        with st.spinner(f"Loading model '{MLFLOW_MODEL_NAME}' from {model_uri}..."):
            model = mlflow.sklearn.load_model(model_uri)
        st.success(f"Model '{MLFLOW_MODEL_NAME}' (latest) loaded successfully.")
        return model
    except Exception as e:
        st.error(f"Error loading model from {model_uri}: {e}")
        return None


model = load_model(MLFLOW_MODEL_URI)

if model:
    # Generate data based on sidebar inputs
    markups_inf = np.linspace(inf_markup_range[0], inf_markup_range[1], inf_num_points)
    inference_data_list = [
        [
            inf_quantity,
            inf_seller_total,
            round(markup, 2),
            inf_plant_category,
            inf_buyer_region,
            inf_qto,
            inf_accepted_proportion * 0.01,
            inf_request_purpose,
        ]
        for markup in markups_inf
    ]
    columns = [
        "quantity",
        "total_seller_price",
        "markup_rate",
        "plant_category",
        "buyer_region",
        "qto",
        "accepted_proportion",
        "request_purpose",
    ]
    inference_df = pd.DataFrame(inference_data_list, columns=columns)

    st.subheader("Inference Input Data (Generated)")
    st.dataframe(inference_df.head())

    try:
        # Make predictions
        with st.spinner("Running predictions..."):
            predictions = model.predict(inference_df)
            proba = model.predict_proba(inference_df)

        # Display results
        results_df = inference_df.copy()
        results_df["Predicted Conversion"] = np.where(predictions == 1, "Yes", "No")
        # Ensure proba has 2 columns before accessing index 1
        if proba.shape[1] >= 2:
            results_df["Conversion Probability"] = proba[:, 1].round(3)
        else:
            # Handle cases where predict_proba might only return one column
            results_df["Conversion Probability"] = proba[:, 0].round(3)  # Or assign a default/error value
            st.warning("Probability array shape unexpected. Displaying probability of the first class.")

        st.subheader("Prediction Results")
        st.dataframe(results_df)

        st.subheader("Conversion Probability vs. Markup")
        chart_data = results_df[["markup_rate", "Conversion Probability"]].set_index("markup_rate")
        st.line_chart(chart_data)

    except Exception as e:
        st.error(f"❌ Inference failed: {e}")
else:
    st.warning("Model could not be loaded. Cannot perform inference.")
