import io
import json
import logging
import queue
import threading
import streamlit as st
import time

from gomat_markup_opt.training.train_conversion_model import train
from gomat_markup_opt.logging_config import setup_logging

setup_logging()

st.title("🏋️ Model Training")

st.sidebar.header("⚙️ Training Configuration")
random_state = st.sidebar.number_input("Random State", value=42, step=1)
test_size = st.sidebar.slider("Test Set Size", 0.1, 0.5, 0.2, 0.05)
classifier_params_json = st.sidebar.text_area("Classifier Params (JSON)", "{}")
try:
    classifier_params = json.loads(classifier_params_json)
except json.JSONDecodeError:
    st.sidebar.error("Invalid JSON for Classifier Params")
    classifier_params = {}

train_button = st.button("🚀 Train Model")


# --- Training Execution ---
if train_button:
    st.info("Starting model training...")
    progress_bar = st.progress(0)
    status_text = st.empty()

    # Create a log container
    log_container = st.empty()
    log_output = io.StringIO()

    # Create a custom log handler to capture logs
    class QueueHandler(logging.Handler):
        def __init__(self, log_queue):
            super().__init__()
            self.log_queue = log_queue

        def emit(self, record):
            log_entry = self.format(record)
            self.log_queue.put(log_entry)

    log_queue = queue.Queue()

    queue_handler = QueueHandler(log_queue)
    queue_handler.setFormatter(logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s"))

    root_logger = logging.getLogger()
    root_logger.addHandler(queue_handler)

    log_display = st.empty()

    config = {
        "test_size": test_size,
        "random_state": random_state,
        "monotonic_cst": {"markup_rate": -1},  # Keep as per original script for now
        "classifier_params": classifier_params,
    }

    training_thread = threading.Thread(target=train, args=(config,), daemon=True)
    training_thread.start()

    # --- Live Log Display Loop ---
    all_logs = ""
    training_exception = None
    while training_thread.is_alive():
        # Drain queue
        while not log_queue.empty():
            try:
                log_entry = log_queue.get(block=False)
                all_logs += log_entry + "\n"
            except queue.Empty:
                break

        # Update display
        log_display.code(all_logs)

        time.sleep(0.2)  # Pause to prevent busy-waiting & allow UI refresh

    training_thread.join(timeout=1.0)  # Ensure thread finishes

    # Final log drain after thread completion
    while not log_queue.empty():
        try:
            log_entry = log_queue.get(block=False)
            all_logs += log_entry + "\n"
        except queue.Empty:
            break
    log_display.code(all_logs)  # Display final logs

    st.success("✅ Training process finished.")
    progress_bar.progress(100)

    # Cleanup
    root_logger.removeHandler(queue_handler)
