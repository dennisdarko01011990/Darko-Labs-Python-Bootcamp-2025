import streamlit as st

st.set_page_config(
    page_title="Gomat Markup Optimization",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.title("📈 Gomat Conversion Probability Model")

st.markdown(
    """
    Use the sidebar to navigate between the different sections:
    - **Training:** Train the conversion probability model.
    - **Metrics:** View model performance metrics.
    - **Inference:** Use the trained model to predict conversion probabilities.
    """
)
