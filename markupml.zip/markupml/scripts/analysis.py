import argparse
import cProfile
import pstats
from concurrent.futures import ProcessPoolExecutor

import pandas as pd
from tqdm import tqdm

from gomat_markup_opt.config import MarkupFinderConfig
from gomat_markup_opt.data.preparation import load_and_prepare_quote_order_data
from gomat_markup_opt.inference.markup_suggestion import MarkupFinder
from gomat_markup_opt.inference.schemas import LineItem, Quote
from gomat_markup_opt.preprocessing.cleanup import cleanup_and_filter_quote_and_order_data
from gomat_markup_opt.preprocessing.feature_engineering import engineer_features


TEST_SIZE_MONTHS = 3

finder = MarkupFinder(MarkupFinderConfig(search_space_size=10))


def process_row(row_dict):
    quote = Quote(
        qto=row_dict["qto"] == "Yes",
        request_purpose=row_dict["request_purpose"],
        buyer_region=row_dict["buyer_region"],
        buyer_company_id=str(row_dict["buyer_company_id"]),
        line_items=[
            LineItem(
                item_id="1",
                plant_category=row_dict["plant_category"],
                product_id=str(row_dict["product_id"]),
                product_size_id=str(row_dict["product_size_id"]),
                seller_price=(row_dict["total_seller_price"] / row_dict["quantity"]),
                # seller_price_relative_to_market=row_dict["seller_price_relative_to_market"],
                quantity=row_dict["quantity"],
            )
        ],
    )

    suggested_markups = finder.suggest_markup_with_details(quote)

    if suggested_markups:
        sm = suggested_markups[0]
        return (sm.suggested_markup_rate, sm.min_markup_rate, sm.max_markup_rate, sm.expected_converted_revenue, sm.conversion_probability)
    else:
        return (0.0, 0.0, 0.0, 0.0, 0.0)


def main(sample_fraction: float | None = None, test_size: int = TEST_SIZE_MONTHS):
    if sample_fraction is not None and (sample_fraction <= 0 or sample_fraction > 1):
        raise ValueError("Sample fraction must be between 0 and 1.")

    prepared_quote_order_data = load_and_prepare_quote_order_data()
    engineered_data = engineer_features(prepared_quote_order_data, "target")
    cleaned_quote_data = cleanup_and_filter_quote_and_order_data(engineered_data, data_size_months=test_size)

    cleaned_quote_data.drop(columns=["accepted_proportion"], inplace=True, errors="ignore")
    data = cleaned_quote_data.copy()

    data = data.sample(frac=sample_fraction) if sample_fraction else data

    if len(data) == 0:
        raise ValueError("No data available after filtering and sampling.")

    data = data.reset_index(drop=True)

    row_dicts = data.to_dict(orient="records")

    with ProcessPoolExecutor() as executor:
        results = list(
            tqdm(
                executor.map(process_row, row_dicts),
                total=len(row_dicts),
                desc="Processing rows",
                unit="row",
            )
        )

    # Assemble results
    columns = ["suggested_markup_rate", "min_markup_rate", "max_markup_rate", "expected_converted_revenue", "conversion_probability"]
    results_df = pd.DataFrame(results, columns=columns)
    data[columns] = results_df

    data.to_parquet("data/analysis_result.parquet")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run analysis with profiling.")
    parser.add_argument("--profile", action="store_true", help="Enable profiling.")
    parser.add_argument("--sample", default=1.0, type=float, help="Fraction of data to sample for analysis (default: 1.0).")
    parser.add_argument(
        "--test_size", default=TEST_SIZE_MONTHS, type=int, help=f"Number of months for test set (default: {TEST_SIZE_MONTHS})."
    )

    args = parser.parse_args()

    if args.profile:
        with cProfile.Profile() as pr:
            main(args.sample, args.test_size)

        stats = pstats.Stats(pr)
        stats.sort_stats("cumulative")
        stats.print_stats(20)
    else:
        main(args.sample, args.test_size)
