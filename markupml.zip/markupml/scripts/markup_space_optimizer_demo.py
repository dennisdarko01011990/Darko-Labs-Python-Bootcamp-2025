#!/usr/bin/env python

"""
Demo script for loading and querying the Markup Space Optimizer model directly using MLflow.
This script loads the latest version of the model and runs predictions on sample data.
The model predicts a lower and higher bound for markups based on item properties.
"""

import mlflow
import pandas as pd

# Define the model name in MLflow Model Registry
MLFLOW_MODEL_NAME = "markup-space-optimizer"
MLFLOW_MODEL_URI = f"models:/{MLFLOW_MODEL_NAME}/latest"

# Sample data for testing the model
sample_df = pd.DataFrame(
    [
        # qto, request_purpose, buyer_region, product_id, product_size_id
        ["Yes", "For Install", "Florida", "7366", "200"],
        ["Yes", "For Install", "Tennessee", "5189", "51"],
        ["Yes", "For Install", "South Carolina", "7315", "193"],
        ["No", "For Install", "Louisiana", "4508", "112"],
        ["No", "For Install", "New York", "167", "582"],
        ["Yes", "For Install", "Unknown place", "7366", "200"],
        ["Yes", "For Install", "Texas", "10033", "252"],
    ],
    columns=["qto", "request_purpose", "buyer_region", "product_id", "product_size_id"],
)


def load_latest_model(model_uri=MLFLOW_MODEL_URI):
    """Load the latest version of the specified model from MLflow."""
    print(f"Loading model from: {model_uri}")
    try:
        model = mlflow.sklearn.load_model(model_uri)
        print("Model loaded successfully.")
        return model
    except Exception as e:
        print(f"Error loading model: {e}")
        raise


def display_results(predictions_df):
    """Display the input data and corresponding predicted markup ranges."""
    print("\nInput Data with Predicted Markup Ranges:")
    print("----------------------------------------")
    # The predictions_df contains the original input features
    # plus 'low' and 'high' columns for the predicted markup bounds.
    print(predictions_df.to_string())


def main():
    print("Markup Space Optimizer Model Demo (Direct Loading)")
    print("================================================")

    try:
        model = load_latest_model()

        print("\nRunning predictions with sample data...")
        predictions_df = model.predict(sample_df)

        display_results(predictions_df)

    except Exception as e:
        # Error is already printed in load_latest_model if it occurs there.
        # This will catch errors during predict or display_results.
        if "Error loading model" not in str(e):  # Avoid double printing load errors
            print(f"\nAn error occurred during the demo: {e}")


if __name__ == "__main__":
    main()
