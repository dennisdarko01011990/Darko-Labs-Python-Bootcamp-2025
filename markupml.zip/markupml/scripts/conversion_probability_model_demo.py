#!/usr/bin/env python

"""
Demo script for loading and querying the conversion probability model directly using MLflow.
This script loads the latest version of the model and runs predictions on sample data.
"""

import mlflow
import numpy as np
import pandas as pd

# Define the model name in MLflow Model Registry
MLFLOW_MODEL_NAME = "conversion-probability-model"
MLFLOW_MODEL_URI = f"models:/{MLFLOW_MODEL_NAME}/latest"

MIN_MARKUP = 0
MAX_MARKUP = 30.0
NUMBER_OF_PREDICTIONS = 20

markups = np.linspace(MIN_MARKUP, MAX_MARKUP, NUMBER_OF_PREDICTIONS)

# Prepare sample data as a Pandas DataFrame, which is the expected input format for mlflow.pyfunc
sample_data_list = [
    [
        1,
        50.0,
        round(markup, 2),
        "Trees",
        "Florida",
        "No",
    ]
    for markup in markups
]

columns = [
    "quantity",
    "total_seller_price",
    "markup_rate",
    "plant_category",
    "buyer_region",
    "qto",
]

sample_df = pd.DataFrame(sample_data_list, columns=columns)


def load_latest_model(model_uri=MLFLOW_MODEL_URI):
    """Load the latest version of the specified model from MLflow."""
    print(f"Loading model from: {model_uri}")
    try:
        model = mlflow.sklearn.load_model(model_uri)
        print("Model loaded successfully.")
        return model
    except Exception as e:
        print(f"Error loading model: {e}")
        raise


def display_results(input_df, predictions, proba):
    """Display the input data and corresponding predictions in a readable format."""
    df = input_df.copy()
    df["predicted_conversion"] = np.where(predictions == 1, "Yes", "No")

    df["predicted_conversion_proba"] = proba[:, 1]  # Probability of class 1 (conversion)
    df["predicted_conversion_proba"] = df["predicted_conversion_proba"].round(2)

    print("\nInput Data with Predictions:")
    print("---------------------------")
    print(df)
    print("\nNote: Prediction value indicates conversion likelihood (e.g., probability or class).")


def main():
    print("Markup Optimization Model Demo (Direct Loading)")
    print("=============================================")

    try:
        # Load the model
        model = load_latest_model()

        # Make predictions
        print("\nRunning predictions with sample data...")
        predictions = model.predict(sample_df)
        proba = model.predict_proba(sample_df)

        # Display results
        display_results(sample_df, predictions, proba)

    except Exception as e:
        print(f"\nAn error occurred: {e}")


if __name__ == "__main__":
    main()
