#!/usr/bin/env python

"""
Demo script for querying the conversion probability model served with MLflow.
This script sends sample data to a locally served MLflow model and displays the results.
"""

import json

import numpy as np
import pandas as pd
import requests

MLFLOW_SERVER_URL = "http://localhost:5009/invocations"

MIN_MARKUP = 0
MAX_MARKUP = 60.0
NUMBER_OF_PREDICTIONS = 20

markups = np.linspace(MIN_MARKUP, MAX_MARKUP, NUMBER_OF_PREDICTIONS)

sample_data = {
    "dataframe_split": {
        "columns": [
            "quantity",
            "total_seller_price",
            "markup_rate",
            "plant_category",
            "buyer_region",
            "qto",
        ],
        "data": [
            [
                5,
                550.0,
                round(markup, 2),
                "Trees",
                "New York",
                "No",
            ]
            for markup in markups
        ],
    }
}


def query_mlflow_model(data, server_url=MLFLOW_SERVER_URL):
    """Send a prediction request to the MLflow server and return the results."""
    headers = {"Content-Type": "application/json"}
    response = requests.post(server_url, data=json.dumps(data), headers=headers)

    if response.status_code != 200:
        raise Exception(f"Request failed with status code {response.status_code}: {response.text}")

    return response.json()["predictions"]


def display_results(input_data, predictions):
    """Display the input data and corresponding predictions in a readable format."""
    df = pd.DataFrame(input_data["dataframe_split"]["data"], columns=input_data["dataframe_split"]["columns"])

    df["predicted_conversion"] = predictions

    print("\nInput Data with Predictions:")
    print("---------------------------")
    print(df)
    print("\nNote: 1 = likely to convert, 0 = not likely to convert")


def main():
    print("Markup Optimization Model Demo")
    print("==============================")
    print("Querying conversion probability model at:", MLFLOW_SERVER_URL)

    print("\nQuerying with sample data from serving example...")
    try:
        predictions = query_mlflow_model(sample_data)
        display_results(sample_data, predictions)
    except Exception as e:
        print(f"Error with sample data: {e}")


if __name__ == "__main__":
    main()
