import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
import pandas as pd
import numpy as np

item_analysis_result = pd.read_parquet("data/analysis_result.parquet")

def compute_quote_markup_rate(df, markup_rate_col):
    return (df[markup_rate_col] * df["total_seller_price"]).sum() / ((1+df[markup_rate_col]) * df["total_seller_price"]).sum()


quote_applied_markup_rate = item_analysis_result.groupby("order_number").apply(
    compute_quote_markup_rate,
    markup_rate_col="markup_rate"
    ).round(2)

quote_suggested_markup_rate = item_analysis_result.groupby("order_number").apply(
    compute_quote_markup_rate,
    markup_rate_col="suggested_markup_rate"
    ).round(2)

all_markups = pd.concat(
    [
        quote_applied_markup_rate,
        quote_suggested_markup_rate
    ], axis=1
)
all_markups.columns = ["quote_applied_markup_rate", "quote_suggested_markup_rate"]


plt.figure(figsize=(10, 6))
plt.xlabel("Markup Rate")
plt.ylabel("Frequency (% of Total)")
plt.title("Suggested vs Actual Markup Rate Distribution")


plt.hist(
    all_markups,
    bins=5,
    alpha=0.75,
    density=False,
    weights=np.ones(len(all_markups)*2).reshape(-1,2) / len(all_markups),
    label=["Actual", "Suggested"]
)

plt.gca().yaxis.set_major_formatter(PercentFormatter(1))
plt.legend()
plt.tight_layout()
plt.show()
