import logging
import os 

import uvicorn
import mlflow

from gomat_markup_opt.config import InferenceAPISettings
from gomat_markup_opt.inference.api import build_app
from dotenv import load_dotenv

logger = logging.getLogger(__name__)


def setup_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    # Reduce Azure ML and MLflow logging
    logging.getLogger("azure").setLevel(logging.WARNING)
    logging.getLogger("mlflow").setLevel(logging.WARNING)
    logging.getLogger("azureml").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("requests").setLevel(logging.WARNING)


def main() -> None:
    load_dotenv()
    setup_logging()

    mlflow.set_tracking_uri(os.environ.get("MLFLOW_TRACKING_URI"))
        
    config = InferenceAPISettings()

    try:
        logger.info(f"Starting the inference API on port {config.port}...")
        logger.debug(f"📖 API Documentation: http://localhost:{config.port}/docs")
        logger.debug(f"🔍 Health Check: http://localhost:{config.port}/health")
        
        app = build_app()
        uvicorn.run(app, port=config.port, host="0.0.0.0", log_config=None)
    except Exception:
        logger.exception("An error occurred while starting the API")
        raise


if __name__ == "__main__":
    main()
