
import mlflow
import os
from dotenv import load_dotenv

from gomat_markup_opt.logging_config import setup_logging
from gomat_markup_opt.training.train_conversion_model import train


def main():
    load_dotenv()
    mlflow.set_tracking_uri(os.environ.get("MLFLOW_TRACKING_URI"))
    setup_logging()
    mlflow.set_experiment("Conversion Model")
    train()


if __name__ == "__main__":
    main()
