import os

import mlflow
from dotenv import load_dotenv

from gomat_markup_opt.evaluation.greediness import evaluate_greediness
from gomat_markup_opt.logging_config import setup_logging
from gomat_markup_opt.training.train_conversion_model import train as train_conversion_model
from gomat_markup_opt.training.train_markup_space_optimizer import train as train_markup_space_optimizer


def main():
    load_dotenv()
    mlflow.set_tracking_uri(os.environ.get("MLFLOW_TRACKING_URI"))
    setup_logging()

    mlflow.set_experiment("Markup Suggestion (all)")
    with mlflow.start_run():

        train_conversion_model()

        train_markup_space_optimizer()

        evaluate_greediness()


if __name__ == "__main__":
    main()
