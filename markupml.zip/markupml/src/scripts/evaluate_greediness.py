import os

import mlflow
from dotenv import load_dotenv

from gomat_markup_opt.evaluation.greediness import evaluate_greediness
from gomat_markup_opt.logging_config import setup_logging


def main():
    load_dotenv()
    mlflow.set_tracking_uri(os.environ.get("MLFLOW_TRACKING_URI"))
    setup_logging()
    mlflow.set_experiment("Greediness Evaluation")
    evaluate_greediness()


if __name__ == "__main__":
    main()
