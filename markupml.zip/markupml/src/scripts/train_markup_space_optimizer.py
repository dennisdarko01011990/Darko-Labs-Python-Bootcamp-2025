
import mlflow

from gomat_markup_opt.logging_config import setup_logging
from gomat_markup_opt.training.train_markup_space_optimizer import train
from dotenv import load_dotenv
import os


def main():
    load_dotenv()
    mlflow.set_tracking_uri(os.environ.get("MLFLOW_TRACKING_URI"))
    setup_logging()
    mlflow.set_experiment("Markup Space Optimizer")
    train()


if __name__ == "__main__":
    main()
