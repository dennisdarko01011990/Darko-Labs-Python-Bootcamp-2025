import logging
import sys

LOGGING_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def setup_logging(level: int = logging.INFO) -> None:
    root_logger = logging.getLogger()

    # Avoid adding handlers multiple times if this function is called again
    if not root_logger.handlers:
        root_logger.setLevel(level)

        console_handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter(LOGGING_FORMAT, datefmt=DATE_FORMAT)
        console_handler.setFormatter(formatter)
        console_handler.setLevel(level)

        root_logger.addHandler(console_handler)
