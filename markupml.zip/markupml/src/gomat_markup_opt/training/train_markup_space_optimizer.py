import logging

import mlflow
import mlflow.sklearn

from gomat_markup_opt.config import MarkupSpaceOptimizerSettings
from gomat_markup_opt.preprocessing.feature_engineering import engineer_features

from ..data.preparation import load_and_prepare_quote_order_data
from ..models.markup_space_optimizer import MarkupSpaceOptimizer
from ..preprocessing.cleanup import cleanup_and_filter_quote_and_order_data

logger = logging.getLogger(__name__)


def _evaluate_model(data: dict) -> dict:
    in_interval = (data["markup_rate"] >= data["low"]) & (data["markup_rate"] <= data["high"])
    coverage_rate = in_interval.mean()
    average_interval_width = (data["high"] - data["low"]).mean()

    return {
        "coverage_rate": round(coverage_rate, 4),
        "average_interval_width": round(average_interval_width, 4),
    }


def train(config: MarkupSpaceOptimizerSettings | None = None) -> None:
    """
    Orchestrates the model training process.

    Args:
        config (MarkupSpaceOptimizerSettings | None): Configuration object containing various parameters for training.
    """
    if config is None:
        config = MarkupSpaceOptimizerSettings()

    logger.info("Starting training process ...")

    logger.info("--- Preparing Data ---")
    prepared_quote_order_data = load_and_prepare_quote_order_data()
    engineered_data = engineer_features(prepared_quote_order_data, target_column=None)

    logger.info("--- Cleaning Prepared Data ---")
    cleaned_data = cleanup_and_filter_quote_and_order_data(engineered_data, data_size_months=config.data_size_months)

    groupby_features = ["qto", "request_purpose", "buyer_region", "product_id", "product_size_id"]

    cleaned_data[groupby_features] = cleaned_data[groupby_features].astype(str)

    logger.info(f"Using configuration: {config}")

    config_dict = config.model_dump()
    model = MarkupSpaceOptimizer(
        groupby_features=groupby_features,
        **config_dict,
    )

    logger.info("--- Fitting Model ---")
    model.fit(X=cleaned_data)
    logger.info("Model fitting complete.")

    logger.info("--- Logging to MLflow ---")
    with mlflow.start_run(run_name="markup_space_optimizer", nested=True) as run:
        logger.info(f"MLflow run ID: {run.info.run_id}")
        logger.info(f"MLflow experiment ID: {run.info.experiment_id}")
        logger.info(f"MLflow tracking URI: {mlflow.get_tracking_uri()}")

        params_to_log = {
            "groupby_features": groupby_features,
            **config_dict,
        }
        mlflow.log_params(params_to_log)
        logger.info(f"Logged parameters: {params_to_log}")

        mlflow.sklearn.log_model(
            sk_model=model,
            artifact_path="markup_space_optimizer",
            input_example=cleaned_data.head(),
            registered_model_name="markup-space-optimizer",
        )
        logger.info("Logged model pipeline using mlflow.sklearn.")

        if config.evaluate_model_performance:
            logger.info("--- Evaluating Model ---")
            predictions = model.predict(X=cleaned_data)
            evaluated_data = cleaned_data.copy()
            evaluated_data[["low", "high"]] = predictions[["low", "high"]]
            metrics = _evaluate_model(evaluated_data)
            logger.info(f"Model evaluation metrics: {metrics}")
            for name, value in metrics.items():
                logger.info(f"{name}: {value:.4f}")

            logger.info("Logging evaluation metrics to MLflow.")
            mlflow.log_metrics(metrics)

            logger.info("Model performance evaluation complete.")

    logger.info("Training process finished. Run logged to MLflow.")
