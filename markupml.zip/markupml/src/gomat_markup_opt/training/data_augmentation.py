import logging

import numpy as np
import pandas as pd

from gomat_markup_opt.config import ConversionModelTrainingSettings

logger = logging.getLogger(__name__)


def generate_synthetic_data(
    data: pd.DataFrame,
    target_column: str,
    markup_column: str,
    config: ConversionModelTrainingSettings,
) -> pd.DataFrame:
    """
    Generates synthetic data by creating new markup scenarios from existing data.

    Args:
        data (pd.DataFrame): Input data containing features and target.
        target_column (str): The name of the target column.
        markup_column (str): The name of the markup column.
        config (ConversionModelTrainingSettings): Configuration object containing various parameters for training.

    Returns:
        pd.DataFrame: Original data with added synthetic samples.
    """
    if markup_column not in data.columns:
        logger.warning(f"'{markup_column}' not found in columns. Skipping synthetic data generation.")
        return data

    accepted_high_markups_mask = (data[markup_column] > config.augment_high_markup_threshold) & (
        data[target_column] == 1
    )
    rejected_low_markups_mask = (data[markup_column] < config.augment_low_markup_threshold) & (data[target_column] == 0)

    accepted_high_markups = data[accepted_high_markups_mask]
    rejected_low_markups = data[rejected_low_markups_mask]

    logger.info(f"Accepted high markups: {len(accepted_high_markups)}")
    logger.info(f"Rejected low markups: {len(rejected_low_markups)}")


    n_synthetic_1 = int(len(accepted_high_markups) * config.augment_sampling_percentage)
    n_synthetic_2 = int(len(rejected_low_markups) * config.augment_sampling_percentage)

    # Start with original data
    synthetic_data_list = [data]

    if n_synthetic_1 > 0:
        synthetic_data_1 = accepted_high_markups.sample(n=n_synthetic_1, random_state=config.random_state)
        # Assign low markup to previously accepted high markup quotes
        synthetic_data_1[markup_column] = np.random.uniform(
            low=config.augment_low_markup_interval[0],
            high=config.augment_low_markup_interval[1],
            size=len(synthetic_data_1),
        ).round(2)
        synthetic_data_list.append(synthetic_data_1)
        logger.info(f"Generated {len(synthetic_data_1)} synthetic samples (Accepted High -> Low Markup)")

    if n_synthetic_2 > 0:
        synthetic_data_2 = rejected_low_markups.sample(n=n_synthetic_2, random_state=config.random_state)
        # Assign high markup to previously rejected low markup quotes
        synthetic_data_2[markup_column] = np.random.uniform(
            low=config.augment_high_markup_interval[0],
            high=config.augment_high_markup_interval[1],
            size=len(synthetic_data_2),
        ).round(2)
        synthetic_data_list.append(synthetic_data_2)
        logger.info(f"Generated {len(synthetic_data_2)} synthetic samples (Rejected Low -> High Markup)")

    augmented_data = pd.concat(synthetic_data_list, ignore_index=True)

    logger.info(f"Shape after augmentation: {augmented_data.shape}")

    return augmented_data
