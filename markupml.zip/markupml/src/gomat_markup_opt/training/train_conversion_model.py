import logging

import matplotlib.pyplot as plt
import mlflow
import mlflow.sklearn
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, brier_score_loss, log_loss, roc_auc_score

from gomat_markup_opt.config import ConversionModelTrainingSettings

from ..data.preparation import load_and_prepare_quote_order_data
from ..models.conversion_probability_model import ConversionProbabilityModel
from ..preprocessing.cleanup import (
    cleanup_and_filter_quote_and_order_data,
)
from ..preprocessing.feature_engineering import engineer_features
from ..visualization.conversion_model_evaluation_plots import (
    generate_calibration_curve_figure,
    generate_precision_recall_figure,
)
from .data_augmentation import generate_synthetic_data

logger = logging.getLogger(__name__)

TARGET_COLUMN = "target"
MARKUP_COLUMN = "markup_rate"
MODEL_NUMERICAL_FEATURES = [
    "quantity",
    "total_seller_price",
    "markup_rate",
    # "seller_price_relative_to_market",
    "accepted_proportion",
]
MODEL_CATEGORICAL_FEATURES = [
    "plant_category",
    "buyer_region",
    "qto",
    "request_purpose",
]


def _balance_data(
    train_data: pd.DataFrame, target_column: str, config: ConversionModelTrainingSettings
) -> pd.DataFrame:
    """
    Applies data balancing (undersampling) to balance the dataset.

    Args:
        train_data (pd.DataFrame): Training data containing features and target.
        target_column (str): The name of the target column.
        config (ConversionModelTrainingSettings): Configuration object containing various parameters for training.

    Returns:
        pd.DataFrame: Balanced dataset.
    """
    logger.info("Target distribution before balancing: %s", train_data[target_column].value_counts(normalize=True))

    accepted_quotes = train_data[train_data[target_column] == 1]
    refused_quotes = train_data[train_data[target_column] == 0]

    n_accepted = len(accepted_quotes)
    n_refused_target = int(n_accepted * config.undersample_ratio)

    if len(refused_quotes) > n_refused_target:
        refused_quotes_sampled = refused_quotes.sample(n=n_refused_target, random_state=config.random_state)
        balanced_data = pd.concat([accepted_quotes, refused_quotes_sampled], ignore_index=True)
        logger.info(f"Undersampled refused quotes from {len(refused_quotes)} to {n_refused_target}")
    else:
        # Not enough refused quotes to undersample, use all
        balanced_data = pd.concat([accepted_quotes, refused_quotes], ignore_index=True)
        logger.warning("Not enough refused quotes to meet undersample ratio. Using all refused quotes.")

    logger.info("Target distribution after balancing: %s", balanced_data[target_column].value_counts(normalize=True))
    logger.info(f"Shape after balancing: {balanced_data.shape}")

    return balanced_data


def _evaluate_model(y_true: pd.Series, y_proba: np.ndarray) -> dict:
    """Calculates and returns various performance metrics."""

    # Ensure probabilities are clipped to avoid log_loss issues with 0 or 1
    y_proba_clipped = np.clip(y_proba, 1e-15, 1 - 1e-15)

    metrics = {
        "brier_score": brier_score_loss(y_true, y_proba_clipped),
        "log_loss": log_loss(y_true, y_proba_clipped),
        "roc_auc": roc_auc_score(y_true, y_proba_clipped),
        "average_precision": average_precision_score(y_true, y_proba_clipped),
    }
    return metrics


def _log_precision_recall_plot(model: ConversionProbabilityModel, X_test: pd.DataFrame, y_test: pd.Series) -> None:
    """Generates, logs, and closes the precision-recall plot."""
    try:
        pr_fig = generate_precision_recall_figure(model, X_test, y_test)
        mlflow.log_figure(pr_fig, "evaluation_plots/precision_recall_curve.png")
        plt.close(pr_fig)
        logger.info("Logged precision_recall_curve.png")
    except Exception as e:
        logger.error(f"Failed to generate/log Precision-Recall plot: {e}")


def _log_calibration_curve_plot(model: ConversionProbabilityModel, X_test: pd.DataFrame, y_test: pd.Series) -> None:
    """Generates, logs, and closes the calibration curve plot."""
    try:
        cal_fig = generate_calibration_curve_figure(model, X_test, y_test)
        mlflow.log_figure(cal_fig, "evaluation_plots/calibration_curve.png")
        plt.close(cal_fig)
        logger.info("Logged calibration_curve.png")
    except Exception as e:
        logger.error(f"Failed to generate/log Calibration Curve plot: {e}")


def _split_dataset(data: pd.DataFrame, size_in_month: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Splits the data into two sets based on a specified number of months. This is useful for
    creating a training and testing set or training and calibration set. The first set contains
    all data before the cutoff date, and the second set contains data from the cutoff date onwards.

    Args:
        data (pd.DataFrame): DataFrame containing the data to be split.
        size_in_month (int): Number of months to include in the second set. If <= 0, an empty second set is returned.

    Returns:
        tuple[pd.DataFrame, pd.DataFrame]: Two sets of features (X).
    """
    if size_in_month <= 0:
        mask = np.zeros(len(data), dtype=bool)
        logger.info("Size in months is less than or equal to 0. No second set will be created.")
    else:
        max_date = data["order_date"].max()
        cutoff_date = max_date - pd.DateOffset(months=size_in_month)
        mask = data["order_date"] >= cutoff_date
        logger.debug(f"Cutoff date: {cutoff_date}")

    X_first, X_second = data[~mask], data[mask]

    logger.debug(f"First set shape: {X_first.shape}, Second set shape: {X_second.shape}")

    return X_first, X_second


def _separate_features_and_target(data: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
    X = data.drop(columns=[TARGET_COLUMN])
    y = data[TARGET_COLUMN]

    return X, y


def train(config: ConversionModelTrainingSettings | None = None) -> None:
    """
    Orchestrates the model training process.

    Args:
        config (ConversionModelTrainingSettings | None): Configuration object containing various parameters for training
    """
    if config is None:
        config = ConversionModelTrainingSettings()

    logger.info("--- Preparing Data ---")
    prepared_quote_order_data = load_and_prepare_quote_order_data()
    engineered_data = engineer_features(prepared_quote_order_data, target_column=TARGET_COLUMN)

    logger.info("--- Cleaning Prepared Data ---")
    cleaned_data = cleanup_and_filter_quote_and_order_data(engineered_data, cutoff_date=config.history_cutoff_date)

    if TARGET_COLUMN not in cleaned_data.columns:
        raise ValueError(f"Target column '{TARGET_COLUMN}' not found after feature engineering.")

    if config.evaluate_model_performance:
        logger.info("--- Splitting Data ---")
        train_data, test_data = _split_dataset(cleaned_data, size_in_month=config.test_size)
        logger.info(f"Test data size: {test_data.shape}")
    else:
        train_data = cleaned_data

    logger.info(f"Train data size: {train_data.shape}")
    augmented_data = generate_synthetic_data(train_data, TARGET_COLUMN, MARKUP_COLUMN, config)
    logger.info(f"Augmented data size: {augmented_data.shape}")

    # Split the data into training and calibration sets
    train_data, calib_data = _split_dataset(data=augmented_data, size_in_month=6)
    logger.info(f"Calibration data size: {calib_data.shape}")

    balanced_train_data = _balance_data(train_data, TARGET_COLUMN, config)

    X_train, y_train = _separate_features_and_target(balanced_train_data)
    X_calib, y_calib = _separate_features_and_target(calib_data)

    logger.info("--- Instantiating Model ---")
    model_num_features = [f for f in MODEL_NUMERICAL_FEATURES if f in augmented_data.columns]
    model_cat_features = [f for f in MODEL_CATEGORICAL_FEATURES if f in augmented_data.columns]

    model = ConversionProbabilityModel(
        numerical_features=model_num_features,
        categorical_features=model_cat_features,
        random_state=config.random_state,
        monotonic_cst=config.monotonic_cst,
        classifier_params=config.classifier_params,
    )
    logger.info(f"Model instantiated with num_features={model_num_features}, cat_features={model_cat_features}")

    logger.info("--- Fitting Model ---")
    model.fit(X_train, y_train, X_calib, y_calib)

    logger.info("Model fitting complete.")

    logger.info("--- Logging to MLflow ---")
    with mlflow.start_run(run_name="conversion_probability_model", nested=True) as run:
        logger.info(f"MLflow run ID: {run.info.run_id}")
        logger.info(f"MLflow experiment ID: {run.info.experiment_id}")
        logger.info(f"MLflow tracking URI: {mlflow.get_tracking_uri()}")

        params_to_log = {
            "num_numerical_features": len(model_num_features),
            "num_categorical_features": len(model_cat_features),
            **config.model_dump(),
            "random_state": config.random_state,
            **model.best_params_,
        }

        mlflow.log_params(params_to_log)
        logger.info(f"Logged parameters: {list(params_to_log.keys())}")

        mlflow.sklearn.log_model(
            sk_model=model.calibrated_model_,
            artifact_path="conversion_model",
            input_example=X_train.head(),
            registered_model_name="conversion-probability-model",
        )
        logger.info("Logged model pipeline using mlflow.sklearn.")

        if config.evaluate_model_performance:
            logger.info("--- Evaluating Model ---")

            X_test, y_test = _separate_features_and_target(test_data)

            probabilities_test = model.predict_proba(X_test)[:, 1]  # P(class=1)

            performance_metrics = _evaluate_model(y_test, probabilities_test)

            logger.info("Performance Metrics on Test Set:")
            for name, value in performance_metrics.items():
                logger.info(f"  {name}: {value:.4f}")

            logger.info("Logging performance metrics to MLflow...")
            mlflow.log_metrics(performance_metrics)

            logger.info("Generating and logging evaluation plots...")
            _log_precision_recall_plot(model, X_test, y_test)
            _log_calibration_curve_plot(model, X_test, y_test)

    logger.info("Training process finished. Run logged to MLflow.")
