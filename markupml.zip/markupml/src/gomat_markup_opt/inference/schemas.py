from enum import StrEnum

from pydantic import BaseModel


class LineItem(BaseModel):
    item_id: str
    plant_category: str
    product_id: str
    product_size_id: str
    seller_price: float
    # seller_price_relative_to_market: float
    quantity: int


class RequestPurpose(StrEnum):
    INSTALL = "For Install"
    BID = "For Bid"


class Quote(BaseModel):
    qto: bool
    request_purpose: RequestPurpose
    buyer_region: str
    buyer_company_id: str
    line_items: list[LineItem]

    model_config = {
        "json_schema_extra": {
            "example": {
                "qto": "true",
                "request_purpose": "For Install",
                "buyer_region": "Florida",
                "buyer_company_id": "buyer_123",
                "line_items": [
                    {
                        "item_id": "12345",
                        "plant_category": "Trees",
                        "product_id": "216",
                        "product_size_id": "270",
                        "seller_price": 500.0,
                        "quantity": 2,
                    }
                ],
            }
        }
    }


class MarkupSuggestion(BaseModel):
    item_id: str
    suggested_markup_rate: float


class MarkupCalculation(BaseModel):
    markup_rate: float
    conversion_probability: float
    reward_score: float
    total_expected_converted_revenue: float


class MarkupSuggestionDetails(MarkupSuggestion):
    min_markup_rate: float
    max_markup_rate: float
    expected_converted_revenue: float
    conversion_probability: float
    calculations: list[MarkupCalculation]


class MarkupSuggestionResponse(BaseModel):
    suggestions: list[MarkupSuggestion]


# Health endpoint schemas
class HealthStatus(StrEnum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    ERROR = "error"


class ModelInfo(BaseModel):
    name: str
    status: str
    run_id: str


class HealthResponse(BaseModel):
    status: HealthStatus
    version: str
    uptime: float
    models: list[ModelInfo]
    timestamp: str


class HealthErrorResponse(BaseModel):
    status: HealthStatus
    version: str
    error: str
    timestamp: str
