from fastapi import FastAPI, HTTPException
from fastapi.responses import RedirectResponse
import time
from datetime import datetime, timezone
from typing import Union
import mlflow

from gomat_markup_opt.config import MarkupFinderConfig

from .markup_suggestion import MarkupFinder
from .schemas import (
    MarkupSuggestionResponse, 
    Quote, 
    HealthResponse, 
    HealthErrorResponse, 
    HealthStatus,
    ModelInfo
)

try:
    from importlib.metadata import version
    __version__ = version("gomat_markup_opt")
except ImportError:
    __version__ = "dev"


def build_app() -> FastAPI:
    app = FastAPI(
        title="Markup Optimization API",
        version=__version__
    )

    config = MarkupFinderConfig()
    startup_time = time.time()
    markup_finder: MarkupFinder = MarkupFinder(config)

    @app.get("/", include_in_schema=False)
    async def docs_redirect() -> RedirectResponse:
        return RedirectResponse(url="/docs")
    
    @app.get("/health", response_model=Union[HealthResponse, HealthErrorResponse])
    async def health():
        try:
            # Check each model individually for granular status reporting
            conversion_model_ok = (
                hasattr(markup_finder, 'conversion_model') and 
                markup_finder.conversion_model is not None
            )
            markup_space_model_ok = (
                hasattr(markup_finder, 'markup_space_model') and 
                markup_finder.markup_space_model is not None
            )
            
            models = [
                ModelInfo(
                    name="conversion_model",
                    status="loaded" if conversion_model_ok else "not_loaded",
                    run_id=getattr(markup_finder, 'conversion_run_id', None) if conversion_model_ok else None
                ),
                ModelInfo(
                    name="markup_space_model",
                    status="loaded" if markup_space_model_ok else "not_loaded",
                    run_id=getattr(markup_finder, 'markup_space_run_id', None) if markup_space_model_ok else None
                )
            ]
            
            # Derive overall status from the models list
            loaded_models = [model for model in models if model.status == "loaded"]
            
            if len(loaded_models) == len(models):
                overall_status = HealthStatus.HEALTHY
            else:
                overall_status = HealthStatus.ERROR
            
            return HealthResponse(
                status=overall_status,
                version=__version__,
                uptime=round(time.time() - startup_time, 1),
                models=models,
                timestamp=datetime.now(timezone.utc).isoformat()
            )
            
        except Exception as e:
            return HealthErrorResponse(
                status=HealthStatus.ERROR,
                version=__version__,
                error=str(e),
                timestamp=datetime.now(timezone.utc).isoformat()
            )

    @app.post("/suggest_markups/", response_model=MarkupSuggestionResponse)
    async def suggest_markups_endpoint(quote: Quote) -> MarkupSuggestionResponse:
        markup_suggestions = markup_finder.suggest_markup_with_details(quote)
        return MarkupSuggestionResponse(suggestions=markup_suggestions)

    return app
