import logging

import mlflow
import mlflow.sklearn
import numpy as np
import pandas as pd

from ..config import MarkupFinderConfig
from .schemas import MarkupCalculation, MarkupSuggestionDetails, Quote


class MarkupFinder:
    """
    Suggests optimal markups for line items using ML models.
    """

    fallback_markup_rate: float
    num_points: int
    logger = logging.getLogger(__name__)

    def __init__(self, config: MarkupFinderConfig) -> None:
        """
        Initializes the MarkupFinder by loading MLflow models.
        """
        self.num_points = config.search_space_size
        self.penalty_factor = config.penalty_factor

        # Store run IDs for health endpoint
        self.conversion_run_id = None
        self.markup_space_run_id = None

        try:
            conversion_model_uri = f"models:/conversion-probability-model/{config.conversion_model_version}"
            self.conversion_model = mlflow.sklearn.load_model(conversion_model_uri)
            self.logger.info(f"Loaded conversion model from {conversion_model_uri}")

            try:
                model_info = mlflow.models.get_model_info(conversion_model_uri)
                if model_info.model_uri.startswith('runs:/'):
                    self.conversion_run_id = model_info.model_uri.split('/')[1]
            except Exception:
                pass

        except Exception as e:
            self.logger.error(f"Error loading conversion model: {e}")
            raise

        try:
            markup_space_model_uri = f"models:/markup-space-optimizer/{config.markup_space_model_version}"
            self.markup_space_model = mlflow.sklearn.load_model(markup_space_model_uri)
            self.logger.info(f"Loaded markup space model from {markup_space_model_uri}")

            try:
                model_info = mlflow.models.get_model_info(markup_space_model_uri)
                if model_info.model_uri.startswith('runs:/'):
                    self.markup_space_run_id = model_info.model_uri.split('/')[1]
            except Exception:
                pass

        except Exception as e:
            self.logger.error(f"Error loading models: {e}")
            raise

    def _define_search_space(self, line_item: pd.Series) -> list[float]:
        """
        Defines the search space for markups for a given line item.
        Uses the markup_space_model to predict [min_markup, max_markup].
        """
        min_markup_default = 0.17
        max_markup_default = 0.23

        try:
            predicted_bounds = self.markup_space_model.predict(line_item.to_frame().T)
            min_markup, max_markup = float(predicted_bounds["low"][0]), float(predicted_bounds["high"][0])

            self.logger.debug(
                f"Item {line_item['item_id']}: ML predicted bounds [{min_markup:.3f}, {max_markup:.3f}]"
            )
        except Exception as e:
            self.logger.warning(
                f"Error using markup_space_model for search space on item {line_item['product_id']}, "
                f"falling back to default. Error: {e}"
            )
            min_markup, max_markup = min_markup_default, max_markup_default

        return np.linspace(min_markup, max_markup, self.num_points).tolist()
    
    def _compute_reward_score(self, markup_values:pd.Series, conversion_probabilities:pd.Series) -> pd.Series:
        """
        Computes the reward score for each markup value based on the conversion probabilities.
        The reward score is calculated as:
            Reward Score = Markup_rate * Conversion Probability - penalty_factor * log(1 + Markup)
        where penalty_factor is a configurable parameter that adjusts the aggressiveness of the markup suggestion.
        """
        reward_scores = markup_values * conversion_probabilities - self.penalty_factor * np.log1p(markup_values)
        return reward_scores

    def _find_optimal_markup_with_details(self, line_item: pd.Series) -> MarkupSuggestionDetails:
        """
        Finds the optimal markup for a single line item and returns detailed calculations. The optimal markup
        is the one that maximizes the reward score.
        """
        search_space = self._define_search_space(line_item)
        n = len(search_space)

        batch_df = pd.DataFrame([line_item] * n)
        batch_df = batch_df.reset_index(drop=True)
        batch_df["markup_rate"] = search_space
        batch_df["buyer_price"] = batch_df["seller_price"] * (1 + batch_df["markup_rate"])

        try:
            probabilities = self.conversion_model.predict_proba(batch_df)[:, 1]
        except Exception as e:
            self.logger.error(f"Error in batch predict_proba: {e}")
            probabilities = np.zeros(n)

        reward_scores = self._compute_reward_score(batch_df["markup_rate"], probabilities)
        markup_amounts = batch_df["seller_price"] * batch_df["markup_rate"]
        expected_converted_revenues = markup_amounts * probabilities
        total_expected_converted_revenues = batch_df["quantity"] * expected_converted_revenues

        calculations = [
            MarkupCalculation(
                markup_rate=markup,
                conversion_probability=prob,
                reward_score=score,
                total_expected_converted_revenue=total_expected_rev,
            )
            for markup, prob, score, total_expected_rev in zip(
                search_space, probabilities, reward_scores, total_expected_converted_revenues, strict=True
                )
        ]

        best_candidate = max(calculations, key=lambda x: x.reward_score)
                
        return MarkupSuggestionDetails(
            item_id=line_item["item_id"],
            min_markup_rate=search_space[0],
            max_markup_rate=search_space[-1],
            suggested_markup_rate=best_candidate.markup_rate,
            expected_converted_revenue=best_candidate.total_expected_converted_revenue,
            conversion_probability=best_candidate.conversion_probability,
            calculations=calculations,
        )

    def _prepare_line_items(self, quote: Quote) -> pd.DataFrame:
        prepared_items = pd.DataFrame(
            [
                {
                    "item_id": item.item_id,
                    "qto": "Yes" if quote.qto else "No",
                    "request_purpose": quote.request_purpose,
                    "buyer_region": quote.buyer_region,
                    "buyer_company_id": quote.buyer_company_id,
                    "product_id": item.product_id,
                    "product_size_id": item.product_size_id,
                    "seller_price": item.seller_price,
                    # "seller_price_relative_to_market": item.seller_price_relative_to_market,
                    "total_seller_price": item.seller_price * item.quantity,
                    "quantity": item.quantity,
                    "plant_category": item.plant_category,
                }
                for item in quote.line_items
            ]
        )
        return prepared_items

    def suggest_markup_with_details(self, quote: Quote) -> list[MarkupSuggestionDetails]:
        """
        Suggests markups for all line items in the quote with detailed calculations.
        """
        prepared_items = self._prepare_line_items(quote)

        return [self._find_optimal_markup_with_details(row) for _, row in prepared_items.iterrows()]
