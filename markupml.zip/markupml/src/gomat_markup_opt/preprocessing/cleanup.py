import logging
from datetime import date

import pandas as pd

logger = logging.getLogger(__name__)

TOP_REGIONS = [
    "Florida",
    "Texas",
    "New York",
    "Georgia",
    "South Carolina",
    "California",
    "Tennessee",
    "Louisiana",
    "North Carolina",
    "Mississippi",
    "Maryland",
    "New Jersey",
    "Kentucky",
]

RELEVANT_LOST_REASONS = [
    "Bad Fit Buyer - Not Competitive Pricing; Substitutions Not Approved",
    "Bad Fit Buyer - Not Competitive Pricing",
    "Good Fit Buyer - Not Competitive Pricing; Other",
    "Good Fit Buyer - Not Competitive Pricing; Substitutions Not Approved",
    "Good Fit Buyer - Not Competitive Pricing; Used their existing suppliers",
    "Good Fit Buyer - Not Competitive Pricing",
    "Other; Good Fit Buyer - Not Competitive Pricing",
    "Other; Used their existing suppliers",
    "Used their existing suppliers; Bad Fit Buyer - Not Competitive Pricing",
    "Used their existing suppliers; Good Fit Buyer - Not Competitive Pricing",
    "Used their existing suppliers; Other",
    "Used their existing suppliers",
    "Customer Lost Bid; Good Fit Buyer - Not Competitive Pricing",
    "Pictures not approved; Good Fit Buyer - Not Competitive Pricing",
    "Substitutions Not Approved; Bad Fit Buyer - Not Competitive Pricing",
]


def cleanup_and_filter_quote_and_order_data(
    quote_order_data: pd.DataFrame,
    data_size_months: int | None = None,
    cutoff_date: str | None = None,
) -> pd.DataFrame:
    logger.info("--- Cleaning and Filtering Quote/Order Data ---")
    original_row_count = len(quote_order_data)
    quote_order_data = quote_order_data.copy()

    # Remove rows with non-positive seller_price
    before = len(quote_order_data)
    quote_order_data = quote_order_data[quote_order_data["seller_price"] > 0]
    logger.info(
        f"Removed {before - len(quote_order_data)} rows with non-positive seller_price "
        f"(remaining: {len(quote_order_data)})"
    )

    # Parse order_date and remove invalid
    quote_order_data["order_date"] = pd.to_datetime(quote_order_data["order_date"], errors="coerce")
    before = len(quote_order_data)
    quote_order_data = quote_order_data[quote_order_data["order_date"].notna()]
    logger.info(
        f"Removed {before - len(quote_order_data)} rows with invalid order_date "
        f"(remaining: {len(quote_order_data)})"
    )

    # Remove rows with missing delivery_zip_code
    before = len(quote_order_data)
    quote_order_data = quote_order_data[quote_order_data["delivery_zip_code"].notna()]
    logger.info(
        f"Removed {before - len(quote_order_data)} rows with missing delivery_zip_code "
        f"(remaining: {len(quote_order_data)})"
    )

    # Filter by cutoff date or data_size_months
    if cutoff_date is not None or data_size_months is not None:
        if data_size_months is not None:
            cutoff_ts = pd.to_datetime(date.today()) - pd.DateOffset(months=data_size_months)
            logger.info(f"Filtering to last {data_size_months} months (cutoff: {cutoff_ts.date()})")
        else:
            cutoff_ts = pd.to_datetime(cutoff_date)
            logger.info(f"Filtering to data after cutoff date: {cutoff_ts.date()}")
        before = len(quote_order_data)
        quote_order_data = quote_order_data[quote_order_data["order_date"] > cutoff_ts]
        logger.info(
            f"Removed {before - len(quote_order_data)} rows outside date range " f"(remaining: {len(quote_order_data)})"
        )

    # Filter by top regions
    before = len(quote_order_data)
    quote_order_data = quote_order_data[quote_order_data["buyer_region"].isin(TOP_REGIONS)]
    logger.info(
        f"Removed {before - len(quote_order_data)} rows outside top regions " f"(remaining: {len(quote_order_data)})"
    )

    # Filter by relevant lost reasons
    before = len(quote_order_data)
    quote_order_data = quote_order_data[
        quote_order_data["lost_reason"].isna() | quote_order_data["lost_reason"].isin(RELEVANT_LOST_REASONS)
    ]
    logger.info(
        f"Removed {before - len(quote_order_data)} rows with irrelevant lost_reason "
        f"(remaining: {len(quote_order_data)})"
    )

    # Remove outliers if enough data
    if len(quote_order_data) >= 1000:
        logger.info(f"Running outlier removal on {len(quote_order_data)} rows.")
        quote_order_data = remove_markup_rate_outliers(quote_order_data)
    else:
        logger.info("Skipping outlier removal for small dataset (<= 1000 rows)")

    quote_order_data["markup_rate"] = quote_order_data["markup_rate"].round(4)

    logger.info(
        f"Final row count after cleaning/filtering: {len(quote_order_data)} " f"(started with {original_row_count})"
    )
    return quote_order_data


def remove_markup_rate_outliers(quote_order_data: pd.DataFrame) -> pd.DataFrame:
    q_low = quote_order_data["markup_rate"].quantile(0.05)
    q_high = quote_order_data["markup_rate"].quantile(0.95)

    logger.info(f"The median markup is {quote_order_data['markup_rate'].median():.2f}")
    logger.info(f"Removing rows with markup_rate outside {q_low:.2f} and {q_high:.2f} (5th and 95th percentiles)")

    initial_rows = len(quote_order_data)

    quote_order_data = quote_order_data[
        (quote_order_data["markup_rate"] >= q_low) & (quote_order_data["markup_rate"] <= q_high)
    ]

    removed_rows = initial_rows - len(quote_order_data)
    logger.info(f"Removed {removed_rows} outlier rows ({removed_rows / initial_rows:.2%})")

    return quote_order_data


def cleanup_and_filter_inventory_data(inventory_data: pd.DataFrame) -> pd.DataFrame:
    inventory_data = inventory_data.copy()

    inventory_data = inventory_data[~inventory_data["supplier_region"].isin(["Ontario", "Quebec"])]

    # Remove any row where price is not a number (e.g. 'Call for Price')
    inventory_data["price"] = pd.to_numeric(inventory_data["price"], errors="coerce")
    inventory_data = inventory_data[inventory_data["price"].notna()]

    # Remove negative prices or zero prices, as they are not valid
    inventory_data = inventory_data[inventory_data["price"] > 0]

    return inventory_data
