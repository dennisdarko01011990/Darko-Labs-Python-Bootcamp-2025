import logging

import line_profiler
import pandas as pd

profiler = line_profiler.LineProfiler()

logger = logging.getLogger(__name__)

DISTANCE_THRESHOLD_MILES = 248.5  # Approx. 400 KM
LOOKBACK_DAYS = 90


def calculate_median_price(quote_data: pd.DataFrame, inventory_data: pd.DataFrame) -> pd.DataFrame:
    """
    Calculates and merges the median price for each quote item based on inventory data. Adds the 'median_price'
    column to the quote_data DataFrame.
    """
    logger.info("Calculating median price for quote items...")
    quote_data = quote_data.copy()
    inventory_data = inventory_data.copy()

    quote_data["lookup_key"] = (
        quote_data["product_id"].astype(str)
        + "_"
        + quote_data["product_size_id"].astype(str)
        + "_"
        + quote_data["buyer_region"].astype(str)
    )
    inventory_data["lookup_key"] = (
        inventory_data["product_id"].astype(str)
        + "_"
        + inventory_data["product_size_id"].astype(str)
        + "_"
        + inventory_data["supplier_region"].astype(str)
    )

    min_date = quote_data["order_date"].min() - pd.Timedelta(days=LOOKBACK_DAYS)
    max_date = quote_data["order_date"].max()
    inventory_data = inventory_data[inventory_data["updated_date"].between(min_date, max_date)]

    state_medians = (
        inventory_data.groupby("lookup_key")
        .agg({"price": "median"})
        .rename(columns={"price": "median_price_state"})
        .reset_index()
    )

    quote_data = quote_data.merge(
        state_medians,
        on="lookup_key",
        how="left",
    )

    quote_data["median_price"] = quote_data["median_price_state"].fillna(quote_data["seller_price"])
    quote_data.drop(columns=["median_price_state"], inplace=True)

    logger.info("Calculated 'median_price'")
    return quote_data
