import logging

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


def engineer_features(
    quote_data: pd.DataFrame,
    target_column: str | None,
) -> pd.DataFrame:
    """
    Applies feature engineering steps after initial cleanup.
    Calculates derived features like seller_total, markup, and the target variable.
    Selects the final set of features required for the model.

    Args:
        quote_data: DataFrame containing quote/order data.
        target_column: Name of the target variable column to create. None if not needed.

    Returns:
        DataFrame with engineered features and selected columns.
    """
    logger.info("--- Engineering Features ---")
    original_row_count = len(quote_data)
    quote_data = quote_data.copy()

    # Create target variable based on quote status, if applicable
    if target_column is None:
        logger.info("Target column is None, skipping target variable creation.")
    else:
        status_mapping = {
            "Order Waiting for Pickup or Delivery": 1,
            "Order Complete": 1,
            "Planning Delivery": 1,
            "Quote Returned": 0,
        }
        unmapped = set(quote_data["status"].unique()) - set(status_mapping.keys())
        if unmapped:
            number_of_rows = quote_data["status"].isin(unmapped).sum()
            logger.warning(f"Unmapped quote statuses: {unmapped}. {number_of_rows} rows will be dropped.")

            quote_data = quote_data[quote_data["status"].isin(status_mapping.keys())]

        quote_data[target_column] = quote_data["status"].map(status_mapping)
        quote_data.drop(columns=["status"], inplace=True)

        quote_data["accepted_proportion"] = calculate_accepted_proportion(quote_data, target_column)

    # Calculate derived features
    quote_data["total_seller_price"] = quote_data["quantity"] * quote_data["seller_price"]
    quote_data["markup_rate"] = (quote_data["buyer_price"] - quote_data["seller_price"]) / quote_data["seller_price"]
    quote_data["markup_amount"] = quote_data["seller_price"] * quote_data["markup_rate"]
    quote_data["total_markup_amount"] = quote_data["quantity"] * quote_data["markup_amount"]

    logger.info(f"Columns in engineered data: {quote_data.columns.tolist()}")
    logger.info(f"Final row count after feature engineering: {len(quote_data)} (started with {original_row_count})")

    return quote_data


def calculate_accepted_proportion(quote_data: pd.DataFrame, target_column: str) -> pd.Series:
    """
    Calculate the accepted quote proportion for each quote based on the buyer company ID and order date.
    The conversion probability is the cumulative sum of the target variable divided by the cumulative count of quotes
    prior to the current quote for each buyer company ID.
    """
    sorted_quote_data = quote_data.sort_values(["buyer_company_id", "order_date"])
    g = sorted_quote_data.groupby("buyer_company_id")[target_column]

    previous_accepted = g.cumsum().shift(1, fill_value=0)
    previous_count = g.cumcount()

    accepted_proportion = (previous_accepted / previous_count.replace(0, np.nan)).round(2).fillna(0)

    return accepted_proportion
