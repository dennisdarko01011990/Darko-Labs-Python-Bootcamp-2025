import logging
from concurrent.futures import ProcessPoolExecutor

import matplotlib.pyplot as plt
import mlflow
import numpy as np
import pandas as pd
from matplotlib.figure import Figure
from matplotlib.ticker import PercentFormatter
from tqdm import tqdm

from gomat_markup_opt.config import AnalysisConfig, MarkupFinderConfig
from gomat_markup_opt.data.preparation import load_and_prepare_quote_order_data
from gomat_markup_opt.inference.markup_suggestion import MarkupFinder
from gomat_markup_opt.inference.schemas import LineItem, Quote
from gomat_markup_opt.preprocessing.cleanup import cleanup_and_filter_quote_and_order_data
from gomat_markup_opt.preprocessing.feature_engineering import engineer_features

logger = logging.getLogger(__name__)


def _get_data(test_size: int) -> pd.DataFrame:
    """
    Load and prepare the quote/order data, applying feature engineering and cleanup steps.
    Then it filters prepared date by the test size.
    """
    prepared_quote_order_data = load_and_prepare_quote_order_data()
    engineered_data = engineer_features(prepared_quote_order_data, "target")
    cutoff_dt = engineered_data["order_date"].max() - pd.DateOffset(months=test_size)
    cleaned_quote_data = cleanup_and_filter_quote_and_order_data(engineered_data, cutoff_date=cutoff_dt)
    if cleaned_quote_data.empty:
        raise ValueError("No data available. Check the test size or the data preparation steps.")

    cleaned_quote_data.drop(columns=["accepted_proportion"], inplace=True, errors="ignore")
    data = cleaned_quote_data.copy()

    return data.reset_index(drop=True)


def _process_row(finder: MarkupFinder, row_dict: dict[str, float | str]) -> tuple[float, float, float, float, float]:
    """
    Process a single row of data to suggest markup rates and calculate expected revenue.
    This function constructs a Quote object from the row data, uses the MarkupFinder to suggest markups,
    and returns the suggested markup rates and expected revenue.
    """

    quote = Quote(
        qto=row_dict["qto"] == "Yes",
        request_purpose=row_dict["request_purpose"],
        buyer_region=row_dict["buyer_region"],
        buyer_company_id=str(row_dict["buyer_company_id"]),
        line_items=[
            LineItem(
                item_id="1",
                plant_category=row_dict["plant_category"],
                product_id=str(row_dict["product_id"]),
                product_size_id=str(row_dict["product_size_id"]),
                seller_price=(row_dict["total_seller_price"] / row_dict["quantity"]),
                quantity=row_dict["quantity"],
            )
        ],
    )

    suggested_markups = finder.suggest_markup_with_details(quote)

    if suggested_markups:
        sm = suggested_markups[0]
        return (
            sm.suggested_markup_rate,
            sm.min_markup_rate,
            sm.max_markup_rate,
            sm.expected_converted_revenue,
            sm.conversion_probability,
        )
    else:
        return (0.0, 0.0, 0.0, 0.0, 0.0)


def _plot_markup_rate_distribution(markups: pd.DataFrame, title: str) -> Figure:
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.set_xlabel("Markup Rate")
    ax.set_ylabel("Frequency (% of Total)")
    ax.set_title(title)

    if not markups.empty:
        ax.hist(
            markups[["quote_applied_markup_rate", "quote_suggested_markup_rate"]],
            bins=5,
            alpha=0.75,
            density=False,
            weights=(np.ones(len(markups) * 2).reshape(-1, 2) / len(markups) if len(markups) > 0 else None),
            label=["Actual", "Suggested"],
        )
        ax.yaxis.set_major_formatter(PercentFormatter(1))
        ax.legend()
    else:
        ax.text(0.5, 0.5, "No quotes available", ha="center", va="center")

    fig.tight_layout()
    return fig


def evaluate_greediness(config: AnalysisConfig | None = None) -> None:
    """
    Evaluate the greediness of markup suggestions the model would have made compared to the actual markup
    that was applied in the past. Calculates separate metrics for accepted and refused quotes.
    """
    config = AnalysisConfig() if config is None else config

    markup_finder_config = MarkupFinderConfig(
        search_space_size=config.search_space_size,
        conversion_model_version=config.conversion_model_version,
        markup_space_model_version=config.markup_space_model_version,
    )

    finder = MarkupFinder(config=markup_finder_config)

    data = _get_data(test_size=config.test_size)

    if data.empty:
        raise ValueError(
            f"No data available for the last {config.test_size} months. "
            "Check the test_size or the data preparation steps."
        )

    row_dicts = data.to_dict(orient="records")

    with ProcessPoolExecutor() as executor:
        results = list(
            tqdm(
                executor.map(_process_row, [finder] * len(row_dicts), row_dicts),
                total=len(row_dicts),
                desc="Processing rows",
                unit="row",
            )
        )

    # Assemble results
    columns = [
        "suggested_markup_rate",
        "min_markup_rate",
        "max_markup_rate",
        "expected_converted_revenue",
        "conversion_probability",
    ]

    results_df = pd.DataFrame(results, columns=columns)
    data[columns] = results_df

    def compute_quote_markup_rate(df, markup_rate_col):
        return (df[markup_rate_col] * df["total_seller_price"]).sum() / (
            (1 + df[markup_rate_col]) * df["total_seller_price"]
        ).sum()

    quote_applied_markup_rate = (
        data.groupby("order_number").apply(compute_quote_markup_rate, markup_rate_col="markup_rate").round(4)
    )

    quote_suggested_markup_rate = (
        data.groupby("order_number").apply(compute_quote_markup_rate, markup_rate_col="suggested_markup_rate").round(4)
    )

    all_markups = pd.concat([quote_applied_markup_rate, quote_suggested_markup_rate], axis=1)
    all_markups.columns = ["quote_applied_markup_rate", "quote_suggested_markup_rate"]

    all_markups["difference"] = all_markups["quote_suggested_markup_rate"] - all_markups["quote_applied_markup_rate"]

    # Get target values from original data to identify accepted/refused quotes
    order_targets = data.groupby("order_number")["target"].first()
    all_markups = all_markups.join(order_targets, on="order_number")
    all_markups = all_markups.reset_index()

    accepted_markups = all_markups[all_markups["target"] == 1]
    refused_markups = all_markups[all_markups["target"] == 0]

    with mlflow.start_run(run_name="greediness", nested=True) as run:
        logger.info(f"MLflow run ID: {run.info.run_id}")
        logger.info(f"MLflow experiment ID: {run.info.experiment_id}")
        logger.info(f"MLflow tracking URI: {mlflow.get_tracking_uri()}")

        mlflow.log_params(
            {
                "sample_fraction": config.sample_fraction,
                "test_size": config.test_size,
                "random_state": config.random_state,
                "search_space_size": config.search_space_size,
                "conversion_model_version": config.conversion_model_version,
                "markup_space_model_version": config.markup_space_model_version,
            }
        )

        if not accepted_markups.empty:
            accepted_mean_difference = float(accepted_markups["difference"].mean())
            mlflow.log_metric("accepted_quotes_greediness", accepted_mean_difference)
            logger.info(f"Accepted quotes greediness: {accepted_mean_difference:.4f}")
        else:
            logger.warning("No accepted quotes available for evaluation")

        if not refused_markups.empty:
            refused_mean_difference = float(refused_markups["difference"].mean())
            mlflow.log_metric("refused_quotes_greediness", refused_mean_difference)
            logger.info(f"Refused quotes greediness: {refused_mean_difference:.4f}")
        else:
            logger.warning("No refused quotes available for evaluation")

        accepted_fig = _plot_markup_rate_distribution(
            pd.DataFrame(accepted_markups), "Accepted Quotes: Suggested vs Actual Markup Rate Distribution"
        )
        mlflow.log_figure(accepted_fig, "accepted_quotes_greediness.png")
        plt.close(accepted_fig)

        refused_fig = _plot_markup_rate_distribution(
            pd.DataFrame(refused_markups), "Refused Quotes: Suggested vs Actual Markup Rate Distribution"
        )
        mlflow.log_figure(refused_fig, "refused_quotes_greediness.png")
        plt.close(refused_fig)
