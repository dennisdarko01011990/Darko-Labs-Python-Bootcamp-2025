import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import PercentFormatter
from sklearn.calibration import CalibrationDisplay
from sklearn.metrics import PrecisionRecallDisplay

from ..models.conversion_probability_model import ConversionProbabilityModel


def generate_precision_recall_figure(
    model: ConversionProbabilityModel, X_test: np.ndarray, y_test: np.ndarray
) -> plt.Figure:
    """
    Generates the Precision-Recall curve figure for a given pipeline.

    Args:
        model: The fitted ConversionProbabilityModel.
        X_test: Test features.
        y_test: True labels for the test set.

    Returns:
        matplotlib.figure.Figure: The figure object containing the plot.
    """
    fig, ax = plt.subplots(figsize=(8, 6))
    PrecisionRecallDisplay.from_estimator(
        model.calibrated_model_, X_test, y_test, name="Classifier", plot_chance_level=False, ax=ax
    )
    ax.set_title("Precision-Recall Curve")
    return fig


def generate_calibration_curve_figure(
    model: ConversionProbabilityModel,
    X_test: np.ndarray,
    y_test: np.ndarray,
    n_bins: int = 10,
    strategy: str = "uniform",
) -> plt.Figure:
    """
    Generates the Calibration Curve figure and a histogram of predicted probabilities.

    Args:
        model: The fitted ConversionProbabilityModel.
        X_test: Test features.
        y_test: True labels for the test set.
        n_bins (int): Number of bins for calibration curve and histogram.
        strategy (str): Strategy for binning ('uniform' or 'quantile').

    Returns:
        matplotlib.figure.Figure: The figure object containing the plots.
    """
    fig = plt.figure(figsize=(10, 10))

    # Calibration curve subplot
    ax_calibration_curve = fig.add_subplot(2, 1, 1)

    display = CalibrationDisplay.from_estimator(
        model.calibrated_model_,
        X_test,
        y_test,
        n_bins=n_bins,
        name="Classifier",
        ax=ax_calibration_curve,
        strategy=strategy,
    )
    ax_calibration_curve.set_title("Calibration Curve", fontsize=16)
    ax_calibration_curve.tick_params(axis="both", which="major", labelsize=12)
    ax_calibration_curve.legend(fontsize=12)
    ax_calibration_curve.set_xlabel("Mean Predicted Probability", fontsize=14)
    ax_calibration_curve.set_ylabel("Fraction of Positives", fontsize=14)

    # Histogram subplot
    ax_hist = fig.add_subplot(2, 1, 2)

    y_prob = display.y_prob

    ax_hist.hist(
        y_prob,
        range=(0, 1),
        bins=n_bins,
        label="Classifier",
        weights=np.ones_like(y_prob) / len(y_prob),
        color=display.line_.get_color(),
    )
    ax_hist.set_title("Histogram of Predicted Probabilities", fontsize=16)
    ax_hist.set_xlabel("Predicted Probability", fontsize=14)
    ax_hist.set_ylabel("Proportion", fontsize=14)
    ax_hist.tick_params(axis="both", which="major", labelsize=12)
    ax_hist.yaxis.set_major_formatter(PercentFormatter(1))
    ax_hist.legend(fontsize=12)

    plt.tight_layout()
    return fig
