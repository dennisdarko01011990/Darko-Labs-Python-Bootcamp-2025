import os
from pathlib import Path

import pandas as pd
from dotenv import load_dotenv


def _get_data_dir() -> Path:
    env_path = Path(__file__).parent.parent.parent / ".env"
    if env_path.exists():
        load_dotenv(dotenv_path=env_path)
    else:
        load_dotenv()

    data_dir = Path(os.getenv("DATA_DIR", "data"))

    if not data_dir.exists():
        raise FileNotFoundError(f"Data directory not found at {data_dir}")

    return data_dir


def _get_latest_file(pattern: str) -> Path:
    data_dir = _get_data_dir()
    files = list(data_dir.glob(pattern))

    if not files:
        raise FileNotFoundError(f"No files matching pattern '{pattern}' found in {data_dir}")

    # Sort the files in reverse order to get the latest file, assuming the naming convention includes date
    # For example, if the files are named like 'file_YYYYMMDD.csv', sorting by name will give the latest date first
    files.sort(reverse=True)

    return files[0]


def load_data(
    pattern_latest: str,
    pattern_specific_format: str | None,
    date_str: str | None,
    data_type_name: str,
) -> pd.DataFrame:
    """
    Generic function to load data from a CSV file, handling latest file or specific date.

    Args:
        pattern_latest: Glob pattern for finding the latest file.
        pattern_specific_format: f-string compatible format for a specific date file.
        date_str: Optional date string.
        data_type_name: Descriptive name for the data type for error messages.

    Returns:
        pd.DataFrame: Loaded data.

    Raises:
        FileNotFoundError: If the specified file or latest file is not found.
        ValueError: If date_str is provided but pattern_specific_format is None.
        OSError: If there's an error reading the CSV file.
    """
    data_dir = _get_data_dir()
    file_path: Path

    if date_str:
        if pattern_specific_format is None:
            raise ValueError(f"Specific date loading not supported for {data_type_name}")
        specific_filename = pattern_specific_format.format(date_str=date_str)
        file_path = data_dir / specific_filename
        if not file_path.exists():
            raise FileNotFoundError(f"{data_type_name} for date {date_str} not found at {file_path}")
    else:
        file_path = _get_latest_file(pattern_latest)

    try:
        # Try UTF-8 first, then fall back to other encodings
        try:
            df = pd.read_csv(file_path, on_bad_lines="error")
        except UnicodeDecodeError:
            # Try with latin-1 encoding for files with special characters
            df = pd.read_csv(file_path, encoding="latin-1", on_bad_lines="error")
    except Exception as e:
        raise OSError(f"Error reading {data_type_name} file at {file_path}: {e}") from e

    return df


def load_inventory_data(date_str: str | None = None) -> pd.DataFrame:
    """
    Load the inventory data from CSV.
    """
    return load_data(
        pattern_latest="GoMaterials_Historical_Inventory_*.csv",
        pattern_specific_format="GoMaterials_Historical_Inventory_{date_str}.csv",
        date_str=date_str,
        data_type_name="Inventory data",
    )


def load_supplier_zip_data() -> pd.DataFrame:
    """
    Load the supplier zip code data from CSV.
    """
    data_dir = _get_data_dir()
    file_path = data_dir / "supplier_name_zip_code.csv"

    if not file_path.exists():
        raise FileNotFoundError("Supplier zip code data file not found")

    df = pd.read_csv(file_path, encoding="latin1", on_bad_lines="warn")

    return df


def load_quote_order_data(date_str: str | None = None) -> pd.DataFrame:
    """
    Load the quote and order data from CSV.
    """
    return load_data(
        pattern_latest="Quote_and_Order_Data_*.csv",
        pattern_specific_format="Quote_and_Order_Data_{date_str}.csv",
        date_str=date_str,
        data_type_name="Quote and order data",
    )


def load_quote_lost_export(date_str: str | None = None) -> pd.DataFrame:
    """
    Load the quote lost export data from CSV.
    """
    return load_data(
        pattern_latest="Quote Lost Export-*.csv",
        pattern_specific_format="Quote Lost Export-{date_str}.csv",
        date_str=date_str,
        data_type_name="Quote lost export data",
    )
