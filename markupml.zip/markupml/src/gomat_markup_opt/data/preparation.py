import logging

import pandas as pd
import zipcodes

from .loading import load_inventory_data, load_quote_lost_export, load_quote_order_data, load_supplier_zip_data

logger = logging.getLogger(__name__)


def _get_lat_long_from_zip_code(zip_code: str | int | None) -> dict | None:
    """Retrieves latitude and longitude for a given zip code."""

    MISSING_ZIP_CODES_COORDINATES = {
        "8344": {"lat": 39.55, "long": -75.02},
        "8313": {"lat": 39.52, "long": -75.22},
        "8527": {"lat": 40.12, "long": -74.30},
        "7726": {"lat": 40.28, "long": -74.34},
        "8343": {"lat": 39.64, "long": -75.15},
        "8302": {"lat": 39.37, "long": -75.16},
    }

    if pd.isna(zip_code):
        return None
    try:
        # Ensure zip_code is treated as string for lookup
        zip_code_str = str(int(zip_code)) if isinstance(zip_code, int | float) else str(zip_code)
        matched_area = zipcodes.matching(zip_code_str)
        if matched_area:
            return {"lat": float(matched_area[0]["lat"]), "long": float(matched_area[0]["long"])}
    except (IndexError, ValueError, TypeError):
        if str(zip_code) in MISSING_ZIP_CODES_COORDINATES:
            return MISSING_ZIP_CODES_COORDINATES[str(zip_code)]

    return None


def _add_coordinates(data: pd.DataFrame, zip_code_column: str) -> pd.DataFrame:
    """Adds latitude and longitude columns based on zip codes."""

    unique_zip_codes = data[zip_code_column].unique()
    zip_code_to_coords = {}
    for zip_code in unique_zip_codes:
        zip_code_to_coords[zip_code] = _get_lat_long_from_zip_code(zip_code)

    coordinates = data[zip_code_column].map(zip_code_to_coords)

    data["latitude"] = coordinates.apply(lambda x: x["lat"] if x else None)
    data["longitude"] = coordinates.apply(lambda x: x["long"] if x else None)

    return data


def load_and_prepare_quote_order_data(date_str: str | None = None) -> pd.DataFrame:
    """Loads the raw quote/order data and renames columns."""

    column_mapping = {
        "item_id": "item_id",
        "Type": "type",
        "Request_Purpose": "request_purpose",
        "qto": "qto",
        "Quote_Order_Number": "order_number",
        "category_id": "category_id",
        "Plant_Category": "plant_category",
        "product_id": "product_id",
        "Latin_Name": "latin_name",
        "Common_Name": "common_name",
        "product_size_id": "product_size_id",
        "Size": "size",
        "product_spec_id": "product_spec_id",
        "Specs": "specs",
        "QTY": "quantity",
        "Seller_Price": "seller_price",
        "Buyer_Price": "buyer_price",
        "seller_company_id": "seller_company_id",
        "Supplier_Name": "supplier_name",
        "buyer_company_id": "buyer_company_id",
        "Buyer_Name": "buyer_name",
        "Delivery_Address": "delivery_address",
        "Delivery_Address_Region": "delivery_address_region",
        "Delivery_Address_Zip_Code": "delivery_zip_code",
        "Buyer_Company_Region": "buyer_region",
        "Supplier_Address": "supplier_address",
        "Supplier_Zip_Code": "supplier_zip_code",
        "Quote_Order_Status": "status",
        "Quote_Order_Last_Publish_Date": "last_publish_date",
        "Quote_Order_Last_Publish_Month": "last_publish_month",
        "Quote_Order_Last_Publish_Year": "last_publish_year",
        "Quote_Order_Created_Date": "order_date",
        "Quote_Order_Created_Month": "order_date_month",
        "Quote_Order_Created_Year": "order_date_year",
        "approx_job_date": "approx_job_date",
        "Delivery_Date_orders": "delivery_date",
        "Timeline": "timeline",
        "Timeline_Month": "timeline_month",
        "Timeline_Year": "timeline_year",
        "Delivery_method": "delivery_method",
    }

    logger.info("Loading raw quote/order data...")
    raw_df = load_quote_order_data(date_str)
    logger.info(f"Raw quote/order data shape: {raw_df.shape}")

    # Select only columns present in the mapping keys to avoid errors if source changes
    cols_to_rename = [col for col in column_mapping if col in raw_df.columns]
    missing_cols = [col for col in column_mapping if col not in raw_df.columns]
    if missing_cols:
        logger.warning(f"Expected columns not found in quote/order data: {missing_cols}")

    prepared_df = raw_df[cols_to_rename].copy()
    prepared_df = prepared_df.rename(columns=column_mapping)

    prepared_df["order_date"] = pd.to_datetime(prepared_df["order_date"], errors="coerce")

    # Add coordinates based on supplier zip code
    prepared_df = _add_coordinates(prepared_df, "delivery_zip_code")

    logger.info(f"Prepared quote/order data shape after rename/select: {prepared_df.shape}")

    quote_lost_data = load_and_prepare_quote_lost_data(date_str)
    quote_lost_data = quote_lost_data[quote_lost_data["order_number"].notna() & quote_lost_data["lost_reason"].notna()]

    logger.info("Merging quote lost data with quote/order data...")

    prepared_df = prepared_df.merge(
        quote_lost_data[["order_number", "lost_reason"]],
        on="order_number",
        how="left",
    )

    logger.info(f"Prepared quote/order data shape after merge: {prepared_df.shape}")

    return prepared_df


def load_and_prepare_quote_lost_data(date_str: str | None = None) -> pd.DataFrame:
    """Loads the raw quote lost export data and renames columns."""

    column_mapping = {
        "Record ID": "record_id",
        "Deal Name": "deal_name",
        "Quote/Order #": "order_number",
        "Quote Lost Reason": "lost_reason",
        "Quote Lost Reason Comment": "lost_reason_comment",
        "Deal Stage": "deal_stage",
        "State/Region": "region",
    }

    logger.info("Loading raw quote lost data...")
    raw_df = load_quote_lost_export(date_str)
    logger.info(f"Raw quote lost data shape: {raw_df.shape}")

    cols_to_rename = [col for col in column_mapping if col in raw_df.columns]
    missing_cols = [col for col in column_mapping if col not in raw_df.columns]
    if missing_cols:
        logger.warning(f"Expected columns not found in quote lost data: {missing_cols}")

    prepared_df = raw_df[cols_to_rename].copy()
    prepared_df = prepared_df.rename(columns=column_mapping)
    logger.info(f"Prepared quote lost data shape after rename/select: {prepared_df.shape}")
    return prepared_df


def load_and_prepare_inventory_data(date_str: str | None = None) -> pd.DataFrame:
    """Loads the raw inventory data and renames columns."""

    column_mapping = {
        "Supplier_id": "supplier_id",
        "Supplier_name": "supplier_name",
        "Supplier_address": "supplier_address",
        "Supplier_region": "supplier_region",
        "Product_id": "product_id",
        "Latin_name": "latin_name",
        "Common_name": "common_name",
        "Container_id": "container_id",
        "Container_name": "container_name",
        "Size_Spec_ids": "size_spec_ids",
        "Size_Specs": "size_specs",
        "size_matching_ids": "size_matching_ids",
        "Available": "available",
        "Price": "price",
        "fee_rate_percentage": "fee_rate_percentage",
        "Net_price": "net_price",
        "Updated_date": "updated_date",
        "seller_updated_days": "seller_updated_days",
    }

    logger.info("Loading raw inventory data...")
    raw_inventory = load_inventory_data(date_str)
    logger.info(f"Raw inventory data shape: {raw_inventory.shape}")

    cols_to_rename = [col for col in column_mapping if col in raw_inventory.columns]
    missing_cols = [col for col in column_mapping if col not in raw_inventory.columns]
    if missing_cols:
        logger.warning(f"Expected columns not found in inventory data: {missing_cols}")

    prepared_df = raw_inventory[cols_to_rename].copy()
    prepared_df = prepared_df.rename(columns=column_mapping)
    logger.info(f"Prepared inventory data shape after rename/select: {prepared_df.shape}")

    prepared_df["updated_date"] = pd.to_datetime(prepared_df["updated_date"], errors="coerce")

    raw_supplier_zip = load_supplier_zip_data().rename(
        columns={
            "Supplier_Zip_Postal_Code": "supplier_zip_code",
            "Supplier Name": "supplier_name",
        }
    )

    unique_supplier_zips = raw_supplier_zip.drop_duplicates(subset=["supplier_name"])

    prepared_df = prepared_df.merge(
        unique_supplier_zips[["supplier_name", "supplier_zip_code"]], on="supplier_name", how="inner"
    )

    prepared_df = _add_coordinates(prepared_df, "supplier_zip_code")

    logger.info(f"Prepared inventory data shape after merge with supplier zip: {prepared_df.shape}")

    return prepared_df
