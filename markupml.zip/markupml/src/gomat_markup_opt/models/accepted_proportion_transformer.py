import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.exceptions import NotFittedError


class AcceptedProportionTransformer(BaseEstimator, TransformerMixin):
    """
    Adds the accepted proportion to the DataFrame based on the buyer region, if
    it's not already present. If the dictionary is not provided or the buyer region
    is not present, it defaults to 0.0.
    """

    accepted_proportion_by_buyer_: dict[str, float] | None

    def __init__(self) -> None:
        self.accepted_proportion_by_buyer_ = None

    def fit(self, X: pd.DataFrame, y: pd.Series | None = None) -> "AcceptedProportionTransformer":
        """
        Learns the last accepted_proportion for each buyer_region from the training data.
        Assumes 'accepted_proportion' and 'buyer_region' columns are present in X.
        """
        if not isinstance(X, pd.DataFrame):
            raise TypeError("Input X must be a pandas DataFrame.")
        if "buyer_region" not in X.columns or "accepted_proportion" not in X.columns:
            raise ValueError(
                "Input DataFrame X must contain 'buyer_region' and 'accepted_proportion' columns for fitting."
            )
        if X["accepted_proportion"].dtype not in [np.float64, np.float32]:
            raise ValueError("The 'accepted_proportion' column must be of type float.")

        self.accepted_proportion_by_buyer_ = X.groupby("buyer_region")["accepted_proportion"].last().to_dict()

        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """
        Adds/updates the 'accepted_proportion' column in X.
        - During training (after fit), it can re-apply or ensure the column based on learned values.
        - During prediction, it uses the learned mapping to impute 'accepted_proportion'.
        """
        if self.accepted_proportion_by_buyer_ is None:
            raise NotFittedError(
                "This AddAcceptedProportion instance is not fitted yet. "
                "Call 'fit' with appropriate arguments before using this estimator."
            )
        if not isinstance(X, pd.DataFrame):
            raise TypeError("Input X must be a pandas DataFrame.")
        if "buyer_region" not in X.columns:
            raise ValueError("Input DataFrame X must contain 'buyer_region' column for transformation.")
        if "accepted_proportion" not in X.columns:
            X["accepted_proportion"] = 0.0

        X_transformed = X.copy()

        mask = X_transformed["accepted_proportion"].isnull()
        X_transformed.loc[mask, "accepted_proportion"] = (
            X_transformed.loc[mask, "buyer_region"]
            .apply(lambda x: self.accepted_proportion_by_buyer_.get(x, 0.0))
            .astype(float)
        )

        return X_transformed
