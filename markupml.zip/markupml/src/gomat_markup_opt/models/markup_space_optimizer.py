import pandas as pd
from sklearn.base import BaseEstimator


class MarkupSpaceOptimizer(BaseEstimator):
    """
    A scikit-learn compatible estimator to determine optimal markup intervals
    for product line items based on historical data.
    """

    groupby_features: list[str]
    default_range: tuple[float, float]
    quantile_low: float
    quantile_high: float
    min_markup: float
    max_markup: float
    minimum_range_size: float
    fitted_data_: pd.DataFrame | None
    seen_classes_: list[any] | None

    def __init__(
        self,
        groupby_features: list[str],
        default_range: tuple[float, float],
        quantile_low: float,
        quantile_high: float,
        min_markup: float,
        max_markup: float,
        minimum_range_size: float,
        **kwargs,
    ) -> None:
        """
        Initializes the MarkupSpaceOptimizer.

        Args:
            groupby_features (list[str]): Columns to group by for interval estimation.
            default_range (tuple[float, float]): Default markup interval if group not seen.
            quantile_low (float): Lower quantile for interval estimation.
            quantile_high (float): Upper quantile for interval estimation.
            min_markup (float): Minimum markup value to enforce.
            max_markup (float): Maximum markup value to enforce.
            minimum_range_size (float): Minimum size of the markup range.
        """
        self.groupby_features = groupby_features
        self.default_range = default_range
        self.quantile_low = quantile_low
        self.quantile_high = quantile_high
        self.min_markup = min_markup
        self.max_markup = max_markup
        self.minimum_range_size = minimum_range_size

        self._validate_parameters()

        self.fitted_data_ = None
        self.seen_classes_ = None

    def _validate_parameters(self) -> None:
        if self.min_markup >= self.max_markup:
            raise ValueError("min_markup must be less than max_markup.")
        if self.quantile_low < 0 or self.quantile_high > 1:
            raise ValueError("quantile_low must be >= 0 and quantile_high must be <= 1.")
        if self.minimum_range_size < 0:
            raise ValueError("minimum_range_size must be non-negative.")

    def fit(self, X: pd.DataFrame, y: pd.Series | None = None) -> "MarkupSpaceOptimizer":
        """
        Fits the optimizer to the training data.

        Args:
            X (pd.DataFrame): Training features.
            y (pd.Series, optional): Target variable (not always required).

        Returns:
            self: The fitted estimator.
        """
        if not isinstance(X, pd.DataFrame):
            raise ValueError("Input data must be a pandas DataFrame.")

        if not all(feature in X.columns for feature in self.groupby_features):
            raise ValueError(f"All groupby features {self.groupby_features} must be present in the input DataFrame.")

        def compute_quantiles(group: pd.Series) -> pd.Series:
            quantile_values = {"low": self.quantile_low, "high": self.quantile_high}
            quantiles = {key: group.quantile(value) for key, value in quantile_values.items()}

            # Ensure the range size is at least the minimum range size
            range_size = quantiles["high"] - quantiles["low"]
            if self.minimum_range_size is not None and range_size < self.minimum_range_size:
                to_add = self.minimum_range_size - range_size
                quantiles["high"] += to_add / 2
                quantiles["low"] -= to_add / 2

            # Ensure the quantiles are within the specified range
            quantiles["low"] = max(quantiles["low"], self.min_markup)
            quantiles["high"] = min(quantiles["high"], self.max_markup)

            return pd.Series(quantiles)

        self.fitted_data_ = X.groupby(self.groupby_features)["markup_rate"].apply(compute_quantiles).unstack().round(2)
        self.seen_classes_ = self.fitted_data_.index.tolist()

        return self

    def predict(self, X: pd.DataFrame) -> pd.DataFrame:
        """
        Predicts optimal markup intervals for the input data.

        Args:
            X (pd.DataFrame): Input features for prediction.

        Returns:
            pd.DataFrame: DataFrame with interval columns (e.g., 'low', 'high').
        """
        if self.fitted_data_ is None or self.seen_classes_ is None:
            raise ValueError(
                "This MarkupSpaceOptimizer instance is not fitted yet. Call 'fit' before using this estimator."
            )

        indexes_to_retrieve = X.set_index(self.groupby_features).index.unique()
        output = pd.DataFrame(index=indexes_to_retrieve, columns=["low", "high"])
        seen_indexes = list(set(indexes_to_retrieve).intersection(self.seen_classes_))
        not_seen_indexes = list(set(indexes_to_retrieve).difference(self.seen_classes_))
        output.loc[seen_indexes] = self.fitted_data_.loc[seen_indexes]
        output.loc[not_seen_indexes] = self.default_range

        processed_data = X.join(output, on=self.groupby_features)
        return processed_data
