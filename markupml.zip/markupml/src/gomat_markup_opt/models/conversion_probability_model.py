import logging

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.calibration import CalibratedClassifierCV
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.exceptions import NotFittedError
from sklearn.model_selection import GridSearchCV, StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import MinMaxScaler, OrdinalEncoder

from .accepted_proportion_transformer import AcceptedProportionTransformer

logger = logging.getLogger(__name__)


OPTIMIZATION_GRID = {
    "classifier__l2_regularization": [0.0, 0.05],
    "classifier__learning_rate": np.linspace(0.01, 0.1, 10),
    "classifier__max_depth": [10,20],
    "classifier__max_features": [0.2, 0.4, 0.6],
    "classifier__max_iter": [200, 300],
    "classifier__max_leaf_nodes": [100, 150],
}

N_CV_SPLITS = 3


class ConversionProbabilityModel(BaseEstimator, ClassifierMixin):
    """
    A machine learning model to predict the probability of a sales quote
    being converted into an order.

    This class encapsulates the preprocessing steps (scaling, encoding)
    and the classifier model within a scikit-learn pipeline.

    It expects data that has already undergone feature engineering and
    augmentation/balancing steps externally.
    """

    numerical_features: list[str]
    categorical_features: list[str]
    random_state: int | None
    monotonic_cst: dict[str, int] | None
    classifier_params: dict[str, any] | None

    pipeline_: Pipeline | None
    best_params_: dict[str, any] | None
    calibrated_model_: CalibratedClassifierCV | None

    feature_names_out_: list[str] | None

    def __init__(
        self,
        numerical_features: list[str],
        categorical_features: list[str],
        random_state: int | None,
        monotonic_cst: dict[str, int] | None = None,
        classifier_params: dict[str, any] | None = None,
    ) -> None:
        """
        Initializes the ConversionProbabilityModel.

        Args:
            random_state (int): Random state for the classifier for reproducibility.
            monotonic_cst (dict or None): Monotonic constraints for the classifier.
                                          Keys are feature names, values are -1, 0, or 1.
            classifier_params (dict or None): Additional parameters for the
                                              HistGradientBoostingClassifier.
        """
        self.numerical_features = numerical_features
        self.categorical_features = categorical_features
        self.random_state = random_state
        self.monotonic_cst = monotonic_cst
        self.classifier_params = classifier_params if classifier_params else {}

        self.pipeline_ = None
        self.feature_names_out_ = None

    def _validate_input(self, X: pd.DataFrame, y: pd.Series | np.ndarray) -> None:
        if not isinstance(X, pd.DataFrame):
            raise ValueError("Input X must be a pandas DataFrame.")
        if not isinstance(y, pd.Series | np.ndarray):
            raise ValueError("Input y must be a pandas Series or numpy array.")
        if X.shape[0] != len(y):
            raise ValueError("Input X and y must have the same number of samples.")

    def fit(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series | np.ndarray,
        X_calib: pd.DataFrame,
        y_calib: pd.Series | np.ndarray,
    ) -> "ConversionProbabilityModel":
        """
        Fits the model pipeline to the training data.

        Args:
            X (pd.DataFrame): Training features. Expected to have undergone
                              feature engineering and augmentation/balancing
                              externally. Columns should include those specified
                              in numerical_features and categorical_features.
            y (pd.Series or np.ndarray): Training target variable (0 or 1).

        Returns:
            self: The fitted estimator.
        """
        self._validate_input(X_train, y_train)
        self._validate_input(X_calib, y_calib)
        if X_train.shape[1] != X_calib.shape[1]:
            raise ValueError("Input X_train and X_calib must have the same number of features.")

        self.pipeline_ = Pipeline(
            steps=[
                ("add_accepted_proportion", AcceptedProportionTransformer()),
                (
                    "preprocessor",
                    ColumnTransformer(
                        transformers=[
                            ("num", MinMaxScaler(), self.numerical_features),
                            (
                                "cat",
                                OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1),
                                self.categorical_features,
                            ),
                        ],
                        remainder="drop",
                    ),
                ),
                (
                    "classifier",
                    HistGradientBoostingClassifier(
                        random_state=self.random_state,
                        monotonic_cst=None,
                        **self.classifier_params,
                    ),
                ),
            ]
        )

        # Fit preprocessor to get output feature names
        preprocessor = self.pipeline_.named_steps["preprocessor"]
        preprocessor.fit(X_train, y_train)
        self.feature_names_out_ = list(preprocessor.get_feature_names_out())

        # Build monotonic constraints if provided
        monotonic_cst_array = None
        if self.monotonic_cst:
            monotonic_cst_array = [0] * len(self.feature_names_out_)
            for feature_name, constraint in self.monotonic_cst.items():
                # Find the transformed feature name(s) corresponding to the original name
                for i, transformed_name in enumerate(self.feature_names_out_):
                    if f"__{feature_name}" in transformed_name:
                        monotonic_cst_array[i] = constraint
                        break

        if monotonic_cst_array is not None:
            self.pipeline_.set_params(classifier__monotonic_cst=monotonic_cst_array)

        logger.info("Running hyperparameter optimization with GridSearchCV...")
        grid_search = GridSearchCV(
            self.pipeline_,
            OPTIMIZATION_GRID,
            cv=StratifiedKFold(n_splits=N_CV_SPLITS, shuffle=True, random_state=self.random_state),
            scoring="neg_brier_score",
            n_jobs=-1,
            verbose=1,
            refit=True,
        )
        grid_search.fit(X_train, y_train)
        self.pipeline_ = grid_search.best_estimator_
        self.best_params_ = grid_search.best_params_

        logger.info("Calibrating model with CalibratedClassifierCV...")
        self.calibrated_model_ = CalibratedClassifierCV(
            estimator=self.pipeline_,
            method="isotonic",
            cv=N_CV_SPLITS,
            ensemble=True,
        )
        self.calibrated_model_.fit(X_calib, y_calib)

        return self

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        """
        Predicts class probabilities for the input data.

        Args:
            X (pd.DataFrame): Input features for prediction. Expected to have
                              undergone the same feature engineering as the
                              training data.

        Returns:
            np.ndarray: Array of shape (n_samples, 2) with probabilities
                        for class 0 and class 1.
        """
        if self.calibrated_model_ is None:
            raise NotFittedError(
                "This ConversionProbabilityModel instance is not fitted yet. "
                "Call 'fit' with appropriate arguments before using this estimator."
            )
        if not isinstance(X, pd.DataFrame):
            raise ValueError("Input X must be a pandas DataFrame.")

        return self.calibrated_model_.predict_proba(X)
