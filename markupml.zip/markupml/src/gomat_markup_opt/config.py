from datetime import date
from typing import Any

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class ConversionModelTrainingSettings(BaseSettings):
    """
    Configuration settings for training the Conversion Probability Model.

    Settings are loaded in the following order of precedence:
    1. Arguments passed to the initializer (used for CLI overrides in scripts).
    2. Environment variables (e.g., GOMAT_RANDOM_STATE).
    3. Values from an .env file (e.g., .env in the project root).
    4. Default values defined in this class.
    """

    model_config = SettingsConfigDict(
        env_prefix="GOMAT_", env_file=".env", extra="ignore", cli_parse_args=True, cli_ignore_unknown_args=True
    )

    test_size: int = Field(
        default=1,
        description="Number of months of data to be used for testing. Data will be taken from the end of the dataset.",
    )
    monotonic_cst: dict[str, int] = Field(
        default_factory=lambda: {"markup_rate": -1, "accepted_proportion": 1},
        description="Monotonic constraints for the model features (e.g., {'feature_name': 1 or -1}).",
    )
    classifier_params: dict[str, Any] = Field(
        default_factory=dict,
        description="Dictionary of parameters to be passed to the classifier during initialization.",
    )
    undersample_ratio: float = Field(
        default=2.0,
        description="Ratio of negative to positive samples after balancing.",
    )
    augment_high_markup_threshold: float = Field(
        default=0.5,
        description="Markup threshold to identify 'accepted high markups'.",
    )
    augment_low_markup_threshold: float = Field(
        default=0.20,
        description="Markup threshold to identify 'rejected low markups'.",
    )
    augment_high_markup_interval: tuple[float, float] = Field(
        default=(0.60, 0.80),
        description="(min, max) markup for synthetic 'rejected low'.",
    )
    augment_low_markup_interval: tuple[float, float] = Field(
        default=(0.20, 0.30),
        description="(min, max) markup for synthetic 'accepted high'.",
    )
    augment_sampling_percentage: float = Field(
        default=0.0,
        description="Percentage of samples to be generated for augmentation.",
    )
    history_cutoff_date: date = Field(
        default=date(2022, 11, 1),
        description="Cutoff date for historical data used in training.",
    )

    random_state: int | None = Field(default=None, description="Random state for reproducibility.")
    evaluate_model_performance: bool = Field(default=True, description="Evaluate model performance after training.")


class MarkupSpaceOptimizerSettings(BaseSettings):
    """
    Configuration settings for training the Markup Space Optimizer.

    Settings are loaded in the following order of precedence:
    1. Arguments passed to the initializer (used for CLI overrides in scripts).
    2. Environment variables (e.g., GOMAT_DEFAULT_RANGE).
    3. Values from an .env file.
    4. Default values defined in this class.
    """

    model_config = SettingsConfigDict(
        env_prefix="GOMAT_", env_file=".env", extra="ignore", cli_parse_args=True, cli_ignore_unknown_args=True
    )

    default_range: tuple[float, float] = Field(
        default=(0.3, 0.36), description="Default markup range for the optimizer."
    )
    quantile_low: float = Field(default=0.1, description="Lower quantile for the markup range.")
    quantile_high: float = Field(default=0.9, description="Upper quantile for the markup range.")
    min_markup: float = Field(default=0.11, description="Minimum allowable markup.")
    max_markup: float = Field(default=0.8, description="Maximum allowable markup.")
    minimum_range_size: float | None = Field(default=0.06, description="Minimum size of the markup range.")
    data_size_months: int = Field(
        default=24,
        description="Number of months of historical data to be used for training the model.",
    )
    evaluate_model_performance: bool = Field(default=True, description="Evaluate model performance after training.")


class MarkupFinderConfig(BaseSettings):
    """
    Configuration settings for the MarkupFinder.

    Settings are loaded in the following order of precedence:
    1. Arguments passed to the initializer (used for CLI overrides in scripts).
    2. Environment variables (e.g., GOMAT_FALLBACK_MARKUP).
    3. Values from an .env file.
    4. Default values defined in this class.
    """

    model_config = SettingsConfigDict(
        env_prefix="GOMAT_", env_file=".env", extra="ignore", cli_parse_args=True, cli_ignore_unknown_args=True
    )

    search_space_size: int = Field(default=100, description="Number of points in the markup search space.")

    conversion_model_version: str = Field(
        default="latest",
        description="Registered version of the conversion model to be used. Use 'latest' for the most recent version.",
    )

    markup_space_model_version: str = Field(
        default="latest",
        description="Registered version of the markup model to be used. Use 'latest' for the most recent version.",
    )
    penalty_factor: float = Field(
        default=0.0,
        ge=0.0,  # Ensure penalty_factor is non-negative
        description="""
            Positive factor to adjust the greediness of the markup suggestion.
            Higher values lead to more conservative suggested markups.
            """,
    )


class AnalysisConfig(BaseSettings):
    """
    Configuration settings for the analysis module.

    Settings are loaded in the following order of precedence:
    1. Arguments passed to the initializer (used for CLI overrides in scripts).
    2. Environment variables (e.g., GOMAT_TEST_SIZE).
    3. Values from an .env file.
    4. Default values defined in this class.
    """

    model_config = SettingsConfigDict(
        env_prefix="GOMAT_", env_file=".env", extra="ignore", cli_parse_args=True, cli_ignore_unknown_args=True
    )

    test_size: int = Field(
        default=1,
        description="Number of months of data to be used. Data will be taken from the end of the dataset.",
    )

    sample_fraction: float | None = Field(
        default=1, description="Fraction of data to sample for analysis. If None, use the entire dataset.", gt=0, le=1
    )

    search_space_size: int = Field(
        default=10,
        description="Number of points in the markup search space.",
    )

    conversion_model_version: str = Field(
        default="latest",
        description="Registered version of the conversion model to be used. Use 'latest' for the most recent version.",
    )

    markup_space_model_version: str = Field(
        default="latest",
        description="Registered version of the markup model to be used. Use 'latest' for the most recent version.",
    )

    random_state: int | None = Field(default=None, description="Random state for reproducibility.")


class InferenceAPISettings(BaseSettings):
    """
    Configuration settings for the Inference API.

    Settings are loaded in the following order of precedence:
    1. Arguments passed to the initializer (used for CLI overrides in scripts).
    2. Environment variables (e.g., GOMAT_PORT).
    3. Values from an .env file.
    4. Default values defined in this class.
    """

    model_config = SettingsConfigDict(
        env_prefix="GOMAT_", env_file=".env", extra="ignore", cli_parse_args=True, cli_ignore_unknown_args=True
    )

    port: int = Field(default=8000, description="Port to run the inference API on.")
