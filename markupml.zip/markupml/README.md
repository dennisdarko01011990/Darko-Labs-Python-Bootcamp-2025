# Gomat Markup Optimization

This project contains scripts for training models and running an inference API related to markup optimization.

- [Gomat Markup Optimization](#gomat-markup-optimization)
  - [Overview 🌐](#overview-)
    - [Code organization](#code-organization)
  - [Configuration ⚙️](#configuration-️)
  - [Usage 🤖](#usage-)
    - [Entry Scripts](#entry-scripts)
      - [1. Train all models](#1-train-all-models)
      - [2. Run analysis](#2-run-analysis)
      - [3. Start Inference API](#3-start-inference-api)
      - [4. Train Conversion Model (Individually)](#4-train-conversion-model-individually)
      - [5. Train Markup Space Optimizer (Individually)](#5-train-markup-space-optimizer-individually)
    - [Expected Input Data](#expected-input-data)
    - [Configuring MLflow Tracking](#configuring-mlflow-tracking)
      - [Set the Tracking URI](#set-the-tracking-uri)
      - [Running the MLflow UI Locally](#running-the-mlflow-ui-locally)
    - [Environment variables](#environment-variables)
  - [Development 👨‍💻](#development-)
    - [Prerequisites](#prerequisites)
    - [Setup](#setup)
      - [Virtual environment](#virtual-environment)
        - [Create conda environment](#create-conda-environment)
        - [Lock dependencies for deployment](#lock-dependencies-for-deployment)
    - [Tests](#tests)
      - [Unit tests](#unit-tests)
      - [Code quality pre-commit hooks](#code-quality-pre-commit-hooks)
    - [Notebooks and experimentations](#notebooks-and-experimentations)

## Overview 🌐

![project overview diagram](docs\pics\overview.png "Project overview diagram")

### Code organization

The project is organized into modules generally representing the different parts of a machine learning model training and inference pipeline. The most important parts are highlighted here:

```
src
└───gomat_markup_opt
    └───data                                  # Data loading and preparation. Ensures uniformity between data sources.
    └───evaluation                            # Evaluation of the models
    └───inference                             # Optimal markup suggestion algorithm and API
    └───models                                # Scikit-learn models and dependencies
    └───preprocessing
    │   └───cleanup.py                        # Remove outliers and/or irrelevant data
    │   └───feature_engineering.py            # Calculate features to help the model
    └───training
    │   └───data_augmentation.py              # Artificially generate new data points using existing data
    │   └───train_conversion_model.py         # Trains the conversion model
    │   └───train_markup_space_optimizer.py   # Trains the markup space optimizer model
    └───visualization
└───scripts                                   # Entry scripts. See `Usage/Entry Scripts` section
```

## Configuration ⚙️

This project uses `pydantic` for configuration management. Settings for different application components are defined in `src/gomat_markup_opt/config.py`.

Configuration values are loaded with the following precedence:
1.  Command-line arguments (where applicable).
2.  Environment variables (e.g., `GOMAT_RANDOM_STATE`).
3.  Values from a `.env` file in the project root.
4.  Default values defined in the settings classes.

The main configuration classes are:
-   `ConversionModelTrainingSettings`: Settings for training the conversion probability model.
-   `MarkupSpaceOptimizerSettings`: Settings for training the markup space optimizer.
-   `MarkupFinderConfig`: Settings for the markup suggestion logic.
-   `AnalysisConfig`: Settings for the analysis script.
-   `InferenceAPISettings`: Settings for the inference API.

Please refer to `src/gomat_markup_opt/config.py` for a detailed list of all configurable parameters.

## Usage 🤖

### Entry Scripts

#### 1. Train all models

This script runs the entire training pipeline: it trains the conversion model, then the markup space optimizer, and finally runs an evaluation.

**How to run:**
```bash
python src/scripts/train_all.py
```

This is the recommended way to train the models.

**Options:**
```
  -h, --help            show this help message and exit
  --test_size int       Number of months of data to be used for
                        testing. Data will be taken from the end of
                        the dataset. (default: 1)
  --monotonic_cst dict[str,int]
                        Monotonic constraints for the model features
                        (e.g., {'feature_name': 1 or -1}).
  --classifier_params dict[str,Any]
                        Dictionary of parameters to be passed to the
                        classifier during initialization.
  --undersample_ratio float
                        Ratio of negative to positive samples after
                        balancing. (default: 2.0)
  --augment_high_markup_threshold float
                        Markup threshold to identify 'accepted high
                        markups'. (default: 0.5)
  --augment_low_markup_threshold float
                        Markup threshold to identify 'rejected low
                        markups'. (default: 0.5)
  --augment_high_markup_interval tuple[float,float]
                        (min, max) markup for synthetic 'rejected
                        low'. (default: (0.35, 0.8))
  --augment_low_markup_interval tuple[float,float]
                        (min, max) markup for synthetic 'accepted
                        high'. (default: (0.05, 0.3))
  --augment_sampling_percentage float
                        Percentage of samples to be generated for
                        augmentation. (default: 0.5)
  --history_cutoff_date date
                        Cutoff date for historical data used in
                        training. (default: 2022-11-01)
  --random_state {int,null}
                        Random state for reproducibility. (default:
                        null)
  --evaluate_model_performance bool
                        Evaluate model performance after training.
                        (default: False)
```

**Example using command-line arguments:**
```bash
python src/scripts/train_all.py --evaluate-model-performance --random-state 42
```

**Example using environment variables:**
```bash
GOMAT_EVALUATE_MODEL_PERFORMANCE=true GOMAT_RANDOM_STATE=42 python src/scripts/train_all.py
```

#### 2. Run greediness analysis

This script runs an analysis using the trained models to suggest markups for historical data and saves the results.

**How to run:**
```bash
python src/scripts/evaluate_greediness.py [OPTIONS]
```

**Options:**
```
  -h, --help            show this help message and exit
  --test_size int       Number of months of data to be used for the test set in analysis. Data will be taken from the end of the dataset. (default: 3)
  --sample_fraction {float,null}
                        Fraction of data to sample for analysis. If
                        None, use the entire dataset. (default: 1)
  --search_space_size int
                        Number of points in the markup search space.
                        (default: 10)
  --conversion_model_version str
                        Registered version of the conversion model
                        to be used. Use 'latest' for the most recent
                        version. (default: latest)
  --markup_space_model_version str
                        Registered version of the markup model to be
                        used. Use 'latest' for the most recent
                        version. (default: latest)
  --random_state {int,null}
                        Random state for reproducibility. (default:
                        null)
```

**Example:**
```bash
python src/scripts/evaluate_greediness.py --sample_fraction 0.5 --test_size 6
```

#### 3. Start Inference API

This script starts the inference API.

**How to run:**
```bash
python src/scripts/start_inference_api.py
```
The API will be available at `http://0.0.0.0:8000` by default. The port can be configured via the `GOMAT_PORT` environment variable.

**Options:**
```
  -h, --help  show this help message and exit
  --port int  Port to run the inference API on. (default: 8000)
```

> **Note:**
> - The two models must have been trained and deployed before using the inference API.

#### 4. Train Conversion Model (Individually)

This script trains only the conversion probability model.

**How to run:**
```bash
python src/scripts/train_conversion_model.py
```

All configuration is now handled via the `ConversionModelTrainingSettings` in `config.py`. You can override settings using command-line arguments (without prefix) or environment variables (prefixed with `GOMAT_`).

**Options:**
```
  -h, --help            show this help message and exit
  --test_size int       Number of months of data to be used for
                        testing. Data will be taken from the end of
                        the dataset. (default: 1)
  --monotonic_cst dict[str,int]
                        Monotonic constraints for the model features
                        (e.g., {'feature_name': 1 or -1}).
  --classifier_params dict[str,Any]
                        Dictionary of parameters to be passed to the
                        classifier during initialization.
  --undersample_ratio float
                        Ratio of negative to positive samples after
                        balancing. (default: 2.0)
  --augment_high_markup_threshold float
                        Markup threshold to identify 'accepted high
                        markups'. (default: 0.5)
  --augment_low_markup_threshold float
                        Markup threshold to identify 'rejected low
                        markups'. (default: 0.5)
  --augment_high_markup_interval tuple[float,float]
                        (min, max) markup for synthetic 'rejected
                        low'. (default: (0.35, 0.8))
  --augment_low_markup_interval tuple[float,float]
                        (min, max) markup for synthetic 'accepted
                        high'. (default: (0.05, 0.3))
  --augment_sampling_percentage float
                        Percentage of samples to be generated for
                        augmentation. (default: 0.5)
  --history_cutoff_date date
                        Cutoff date for historical data used in
                        training. (default: 2022-11-01)
  --random_state {int,null}
                        Random state for reproducibility. (default:
                        null)
  --evaluate_model_performance bool
                        Evaluate model performance after training.
                        (default: False)
```

**Example using command-line arguments:**
```bash
python src/scripts/train_conversion_model.py --evaluate-model-performance --random-state 42
```

**Example using environment variables:**
```bash
GOMAT_EVALUATE_MODEL_PERFORMANCE=true GOMAT_RANDOM_STATE=42 python src/scripts/train_conversion_model.py
```

#### 5. Train Markup Space Optimizer (Individually)

This script trains only the markup space optimizer.

**How to run:**
```bash
python src/scripts/train_markup_space_optimizer.py
```

All configuration is now handled via the `MarkupSpaceOptimizerSettings` in `config.py`. You can override settings using command-line arguments (without prefix) or environment variables (prefixed with `GOMAT_`).

**Options:**
```
  -h, --help            show this help message and exit
  --default_range tuple[float,float]
                        Default markup range for the optimizer.
                        (default: (0.3, 0.36))
  --quantile_low float  Lower quantile for the markup range.
                        (default: 0.1)
  --quantile_high float
                        Upper quantile for the markup range.
                        (default: 0.9)
  --min_markup float    Minimum allowable markup. (default: 0.11)
  --max_markup float    Maximum allowable markup. (default: 0.8)
  --minimum_range_size {float,null}
                        Minimum size of the markup range. (default:
                        0.06)
  --data_size_months int
                        Number of months of historical data to be
                        used for training the model. (default: 24)
  --evaluate_model_performance bool
                        Evaluate model performance after training.
                        (default: False)
```

**Example using command-line arguments:**
```bash
python src/scripts/train_markup_space_optimizer.py --evaluate-model-performance
```

**Example using environment variables:**
```bash
GOMAT_EVALUATE_MODEL_PERFORMANCE=true python src/scripts/train_markup_space_optimizer.py
```

Example:
```bash
python src/scripts/train_markup_space_optimizer.py --evaluate
```

### Expected Input Data

The project expects several input data files in the `data/` directory. These files are used for model training and evaluation. Below is a description of the main expected input files:

- **GoMaterials_Historical_Inventory_*.csv**: Historical inventory data. The filename includes a date (e.g., `GoMaterials_Historical_Inventory_20250225.csv`). Used for inventory analysis and modeling.
    Expected Columns:
    - `Supplier_name`
    - `Supplier_Zip_Postal_Code`
    - `Supplier_region`
    - `Price`
- **Quote_and_Order_Data_*.csv**: Quote and order data, with the date in the filename (e.g., `Quote_and_Order_Data_2025_04_29.csv`). Used for training and evaluating conversion models.
    Expected Columns:
    - `Quote/Order Number`
    - `Seller Price`
    - `Quote/Order Created Date`
    - `Quote/Order Status`
    - `Buyer Company Region`
    - `Delivery Address Zip/Postal Code`
    - `QTY`
    - `Buyer Price`
    - `buyer_company_id`
    - `qto`
    - `Request Purpose`
    - `Plant Category`
- **Quote Lost Export-*.csv**: Exported data of lost quotes, with the date in the filename (e.g., `Quote Lost Export-Feb132025.xlsx - All deals.csv`). Used for analyzing lost opportunities.
    Expected Columns:
    - `Quote/Order #`
    - `Quote Lost Reason`
- **supplier_name_zip_code.csv**: Mapping of supplier names to zip codes. Used for geographic and supplier-based analysis.
    Expected Columns:
    - `Supplier_Zip_Postal_Code`
    - `Supplier Name`

> **Note:**
> - The scripts will look for the latest file matching the expected pattern if a specific date is not provided.
> - The data directory can be changed by setting the `DATA_DIR` environment variable.
> - All input files are expected to be in CSV format unless otherwise noted.

### Configuring MLflow Tracking

This project uses [MLflow](https://mlflow.org/) for experiment tracking. By default, runs are logged to the local `./mlruns` directory. You can also configure MLflow to log to a remote Azure ML instance.

#### Set the Tracking URI

- **Local (default):**
  No action needed. Runs are tracked in `./mlruns`.

- **Remote Azure ML:**
  Set the tracking URI before running scripts:
  ```bash
  export MLFLOW_TRACKING_URI="<your-azure-ml-tracking-uri>"
  ```
  Replace `<your-azure-ml-tracking-uri>` with your Azure ML tracking server URI.

#### Running the MLflow UI Locally

To view and compare runs locally, launch the MLflow UI:
```bash
mlflow ui --backend-store-uri ./mlruns
```
The UI will be available at http://localhost:5000.

### Environment variables

The following environment variables can be used to configure the behavior of the scripts and models. They can be set in your shell or in a `.env` file. An example file (`.env.example`) is provided in the project root directory. It is, however, not mandatory as the default values are usually sufficient for local development.

| Name                                | Description                                                                                      | Default value                               |
| ----------------------------------- | ------------------------------------------------------------------------------------------------ | ------------------------------------------- |
| `DATA_DIR`                          | Path to the folder containing data files loaded by `loading.py`                                  | `data`                                      |
| `MLFLOW_TRACKING_URI`               | MLflow tracking server URI. If not set, it defaults to a local `./mlruns` directory.             | `./mlruns`                                  |
| `GOMAT_PORT`                        | Port to run the inference API on.                                                                | `8000`                                      |
| `GOMAT_TEST_SIZE`                   | Number of months of data for testing.                                                            | `1`                                         |
| `GOMAT_MONOTONIC_CST`               | Monotonic constraints for model features (JSON string, e.g. `'{\"markup_rate\": -1}'`).            | `{\"markup_rate\": -1, \"accepted_proportion\": 1}` |
| `GOMAT_CLASSIFIER_PARAMS`           | Parameters for the classifier (JSON string).                                                     | `{}`                                        |
| `GOMAT_UNDERSAMPLE_RATIO`           | Ratio of negative to positive samples after balancing.                                           | `2.0`                                       |
| `GOMAT_AUGMENT_HIGH_MARKUP_THRESHOLD` | Markup threshold to identify 'accepted high markups'.                                            | `0.50`                                      |
| `GOMAT_AUGMENT_LOW_MARKUP_THRESHOLD`| Markup threshold to identify 'rejected low markups'.                                             | `0.50`                                      |
| `GOMAT_AUGMENT_HIGH_MARKUP_INTERVAL`| (min, max) markup for synthetic 'rejected low' (JSON string).                                    | `(0.35, 0.80)`                              |
| `GOMAT_AUGMENT_LOW_MARKUP_INTERVAL` | (min, max) markup for synthetic 'accepted high' (JSON string).                                   | `(0.05, 0.30)`                              |
| `GOMAT_AUGMENT_SAMPLING_PERCENTAGE` | Percentage of samples to be generated for augmentation.                                          | `0.5`                                       |
| `GOMAT_HISTORY_CUTOFF_DATE`         | Cutoff date for historical data used in training the conversion model.                           | `2022-11-01`                                |
| `GOMAT_RANDOM_STATE`                | Random state for reproducibility.                                                                | `null`                                      |
| `GOMAT_EVALUATE_MODEL_PERFORMANCE`  | Evaluate model performance after training.                                                       | `False`                                     |
| `GOMAT_DEFAULT_RANGE`               | Default markup range for the optimizer (JSON string).                                            | `(0.3, 0.36)`                               |
| `GOMAT_QUANTILE_LOW`                | Lower quantile for the markup range.                                                             | `0.1`                                       |
| `GOMAT_QUANTILE_HIGH`               | Upper quantile for the markup range.                                                             | `0.9`                                       |
| `GOMAT_MIN_MARKUP`                  | Minimum allowable markup.                                                                        | `0.11`                                      |
| `GOMAT_MAX_MARKUP`                  | Maximum allowable markup.                                                                        | `0.8`                                       |
| `GOMAT_MINIMUM_RANGE_SIZE`          | Minimum size of the markup range.                                                                | `0.06`                                      |
| `GOMAT_DATA_SIZE_MONTHS`            | Number of months of historical data for training the markup space optimizer.                     | `24`                                        |
| `GOMAT_SEARCH_SPACE_SIZE`           | Number of points in the markup search space.                                                     | `100` (Inference), `10` (Analysis)          |
| `GOMAT_CONVERSION_MODEL_VERSION`    | Registered version of the conversion model to use.                                               | `latest`                                    |
| `GOMAT_MARKUP_SPACE_MODEL_VERSION`  | Registered version of the markup model to use.                                                   | `latest`                                    |
| `GOMAT_ANALYSIS_CUT_OFF_DATE`       | Cutoff date for analysis data.                                                                   | `2025-03-18`                                |
| `GOMAT_SAMPLE_FRACTION`             | Fraction of data to sample for analysis.                                                         | `1`                                         |
| GOMAT_MARKUP_SPACE_MODEL_VERSION    | Registered version of the markup space model to be used by MarkupFinder.                         | latest              |

> **Note:** For fields expecting complex types (dict, tuple), use JSON strings in the environment variable.

## Development 👨‍💻

### Prerequisites

- conda (https://conda-forge.org/download/)
- Docker (https://docs.docker.com/get-docker/)

### Setup

1. Create and activate the virtual environment (see below)
2. Install pre-commit hooks
   ```
   pre-commit install --install-hooks
   ```

#### Virtual environment

- This project relies on conda for creating and managing virtual environments.
- List Python packages required for production in `envs/environment.yml` and packages required only for development in
  `envs/environment-dev.yml`.
- In order to minimize risks of conflicts between package dependencies, use packages from conda channels whenever
  available.
  Only packages unavailable in conda channels should be installed with pip.
- Package versions must be pinned with conda-lock in order to build the Docker image and ensure reproducibility of
  deployments.

**WARNING: Use the `conda-forge` channel or other open-source channels. Anaconda, Inc. owns the `defaults` channel and requires
a commercial license for distribution.**

##### Create conda environment

- To create a conda environment for development combining both production and development yaml files, use
  ```
  make conda-env
  ```
  which is a shortcut for
  ```
  conda env remove -n gomat_markup_opt
  conda env create -n gomat_markup_opt -f envs/environment.yml
  conda env update -n gomat_markup_opt -f envs/environment-dev.yml
  conda run -n gomat_markup_opt pip install -e .
  ```
- To activate the environment:
  ```
  conda activate gomat_markup_opt
  ```

##### Lock dependencies for deployment

- Package versions must be pinned with conda-lock before deployment in a Docker image in order to ensure reproducibility
  of deployments.
  conda-lock creates a lock file `envs/conda-lock.yml` with compatible dependencies.
- This project has a pre-commit hook checking for changes in `envs/environment.yml` and updating the lock file when
  required.
- The lock file can be generated manually after modifying `envs/environment.yml`, or for updating pinned versions:
  ```
  make conda-lock
  ```
  which is a shortcut for
  ```
  rm -f envs/conda-lock.yml
  conda-lock -p linux-64 -f envs/environment.yml --lockfile envs/conda-lock.yml
  ```

### Tests

#### Unit tests

An automated unit test suite can be run using the following command:

```
pytest
```

#### Code quality pre-commit hooks

Pre-commit hooks and build pipeline steps ensure code consistency across the project. The most important one is `ruff` (https://docs.astral.sh/ruff/), which is a linter and formatter.

### Notebooks and experimentations

The `notebooks` and `scripts` folders are used for experimentations, demos, and various proofs of concept and are not considered _production code_.

## Documentation 📚

This project uses [MkDocs](https://www.mkdocs.org/) for documentation. The documentation source files are in the `docs/` directory.

### Build the documentation

To build the static site:

```bash
make mkdocs-build
```
or directly with MkDocs:
```bash
mkdocs build
```
The generated site will be in the `site/` directory.

### Serve the documentation locally

To serve the documentation locally with live reload:

```bash
make mkdocs-serve
```
or directly with MkDocs:
```bash
mkdocs serve
```
Then open [http://localhost:8000](http://localhost:8000) in your browser.
